import PushNotifications from '@pusher/push-notifications-server';

const beamsClient = new PushNotifications({
    instanceId: process.env.BEAMS_INSTANCE_ID,
    secretKey: process.env.BEAMS_SECRET_KEY,
});

export default async function handler(request, response) {
    // CORS Headers
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    response.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-api-key');

    if (request.method === 'OPTIONS') {
        return response.status(200).end();
    }

    if (request.method !== 'POST') {
        return response.status(405).json({ error: 'Method not allowed' });
    }

    // Verifikasi API Key (mencegah akses tidak sah selain dari GAS)
    const apiKey = request.headers['x-api-key'];
    if (!apiKey || apiKey !== process.env.NOTIFY_API_KEY) {
        return response.status(401).json({ error: 'Unauthorized: Invalid API Key' });
    }

    const { title, body, url, actions, data: extraData } = request.body || {};

    if (!title || !body) {
        return response.status(400).json({ error: 'title and body are required' });
    }

    if (!process.env.BEAMS_INSTANCE_ID || !process.env.BEAMS_SECRET_KEY) {
        return response.status(500).json({ error: 'Server config error: Missing Beams credentials' });
    }

    try {
        const baseUrl = "https://myformulir.vercel.app";
        const iconUrl = `${baseUrl}/icon-192.png`;
        const deepLink = url ? (url.startsWith('http') ? url : `${baseUrl}${url}`) : `${baseUrl}/admin`;

        await beamsClient.publishToUsers(['admin-broadcast'], {
            web: {
                notification: {
                    title: title,
                    body: body,
                    icon: iconUrl,
                    deep_link: deepLink,
                    actions: actions || []
                },
                data: {
                    url: deepLink,
                    ...extraData
                }
            }
        });

        return response.status(200).json({ success: true, message: 'Notification sent to admin.' });
    } catch (error) {
        console.error('Beams Notify Error:', error);
        return response.status(500).json({ error: 'Failed to send notification: ' + error.message });
    }
}
