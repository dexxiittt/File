import PushNotifications from '@pusher/push-notifications-server';

const beamsClient = new PushNotifications({
    instanceId: process.env.BEAMS_INSTANCE_ID,
    secretKey: process.env.BEAMS_SECRET_KEY,
});

export default async function handler(request, response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    response.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

    if (request.method === 'OPTIONS') {
        return response.status(200).end();
    }

    if (request.method !== 'GET') {
        return response.status(405).json({ error: 'Method not allowed' });
    }

    const userId = request.query.user_id;

    if (!userId) {
        return response.status(400).json({ error: 'user_id query param is required' });
    }

    if (!process.env.BEAMS_INSTANCE_ID || !process.env.BEAMS_SECRET_KEY) {
        return response.status(500).json({ error: 'Server config error: Missing Beams credentials' });
    }

    try {
        // Buat token sementara yang memperbolehkan browser ini berlangganan sebagai userId
        const beamsToken = beamsClient.generateToken(userId);
        return response.status(200).json(beamsToken);
    } catch (error) {
        console.error('Beams Auth Error:', error);
        return response.status(500).json({ error: 'Failed to generate Beams auth token: ' + error.message });
    }
}
