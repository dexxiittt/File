import QRCode from 'qrcode';
import fs from 'fs';
import path from 'path';

// UBAH STRING QRIS ANDA DI BAWAH INI
const qrisString = '00020101021126570011ID.DANA.WWW011893600915325013193002092501319300303UMI51440014ID.CO.QRIS.WWW0215ID10254467066790303UMI5204654053033605802ID5905UZNBT6008Karawang61054135263047920';

const outputPath = path.resolve('public', 'qris.png');

QRCode.toFile(outputPath, qrisString, {
    errorCorrectionLevel: 'H',
    margin: 2,
    width: 600,
    color: {
        dark: '#000000',
        light: '#ffffff'
    }
}, function (err) {
    if (err) {
        console.error('Gagal membuat QR Code:', err);
        process.exit(1);
    }
    console.log(`[MYForm Build]  Gambar QRIS berhasil diperbarui di: public/qris.png`);
});
