// Konfigurasi Terpusat untuk Backend Google Apps Script (GAS)

const CONFIG = {
  SPREADSHEET_ID: "MASUKKAN_ID_SPREADSHEET_ANDA_DI_SINI",
  GDRIVE_FOLDER_ID: "MASUKKAN_ID_FOLDER_DRIVE_ANDA_DI_SINI",
  GROQ_API_KEYS: [
    'MASUKKAN_API_KEY_ANDA_DI_SINI',
    'MASUKKAN_API_KEY_ANDA_DI_SINI',
    'MASUKKAN_API_KEY_ANDA_DI_SINI'
  ],
  GROQ_MODELS: [
    'llama-3.3-70b-versatile',
    'llama-3.1-70b-versatile',
    'mixtral-8x7b-32768'
  ]
};
