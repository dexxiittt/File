// ============================================================
// MYForm: CODE TEMPLATE - CUSTOM DATABASE (PENYIMPANAN DATA)
// ============================================================
// File ini HANYA menangani penyimpanan data formulir.
// Autentikasi (Login/Register) tetap dikelola oleh server sistem MYForm.
//
// Langkah Penggunaan:
// 1. Isi SPREADSHEET_ID dan GDRIVE_FOLDER_ID di file Config.gs
// 2. Deploy sebagai "Web App" (Akses: Anyone, Execute As: Me)
// 3. Masukkan URL hasil Deploy di Pengaturan MYForm > Database Kustom
// ============================================================

const FORMS_SHEET = 'forms';

function getSpreadsheet() {
  return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
}

function createJsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// Sanitisasi input dasar (Prevensi XSS)
function sanitize(input) {
  if (Array.isArray(input)) return input.map(sanitize);
  if (input !== null && typeof input === 'object' && !input.base64) {
    const sanitizedObj = {};
    for (let key in input) sanitizedObj[key] = sanitize(input[key]);
    return sanitizedObj;
  }
  if (typeof input !== 'string') return input;
  return input.replace(/<[^>]*>?/gm, '');
}

// Inisialisasi Sheet (Jalankan sekali setelah deploy via menu Run > initSheets)
function initSheets() {
  const ss = getSpreadsheet();
  if (!ss.getSheetByName(FORMS_SHEET)) {
    ss.insertSheet(FORMS_SHEET).appendRow([
      'formId', 'customSlug', 'username', 'title', 'description',
      'fields_schema_json', 'theme', 'backgroundPattern', 'isActive',
      'confirmationMessage', 'gformUrl', 'createdAt', 'userSpreadsheetId', 'userFolderId', 'isQuizMode'
    ]);
  }
}

// =======================
// ROUTER: HTTP POST
// =======================
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    switch (data.action) {
      case 'createForm':       return handleCreateForm(data);
      case 'submitResponse':   return handleSubmitResponse(data);
      case 'getResponses':     return handleGetResponses(data);
      case 'getFormBySlug':    return handleGetFormBySlug(data);
      case 'getCreatorForms':  return handleGetCreatorForms(data);
      case 'toggleFormStatus': return handleToggleFormStatus(data);
      case 'deleteForm':       return handleDeleteForm(data);
      case 'init':
        initSheets();
        return createJsonResponse({ success: true, message: 'Inisialisasi berhasil' });
      default:
        return createJsonResponse({ error: 'Action tidak valid' });
    }
  } catch (error) {
    return createJsonResponse({ success: false, error: error.message || 'Internal Server Error' });
  }
}

// =======================
// HANDLERS
// =======================

function handleCreateForm(data) {
  const {
    customSlug, username, title, description, fields_schema_json,
    theme, backgroundPattern, isActive, confirmationMessage, gformUrl,
    userSpreadsheetId, userFolderId, isQuizMode
  } = data;

  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(FORMS_SHEET);

  // Validasi slug
  if (customSlug) {
    const slugRegex = /^[a-zA-Z0-9\-]+$/;
    if (!slugRegex.test(customSlug)) {
      return createJsonResponse({ success: false, error: 'Slug hanya boleh berisi huruf, angka, dan strip' });
    }
    const existing = sheet.getDataRange().getValues();
    for (let i = 1; i < existing.length; i++) {
      if (existing[i][1] === customSlug) {
        return createJsonResponse({ success: false, error: 'Slug sudah dipakai' });
      }
    }
  }

  const formId = Utilities.getUuid();
  const slugToSave = customSlug || formId;
  const createdAt = new Date().toISOString();

  sheet.appendRow([
    formId, slugToSave, sanitize(username), sanitize(title), sanitize(description),
    fields_schema_json, theme, backgroundPattern, isActive,
    sanitize(confirmationMessage), gformUrl, createdAt, userSpreadsheetId, userFolderId, isQuizMode
  ]);

  // Buat tab respon
  if (!gformUrl || gformUrl.trim() === '') {
    const tabName = `res_${formId}`;
    if (!ss.getSheetByName(tabName)) {
      const newSheet = ss.insertSheet(tabName);
      let headers = ['Timestamp'];
      try {
        if (fields_schema_json) {
          const fields = JSON.parse(fields_schema_json);
          headers = headers.concat(fields.map(f => f.label || f.id));
        }
      } catch (e) {}
      newSheet.appendRow(headers);
    }
  }

  return createJsonResponse({ success: true, formId, customSlug: slugToSave });
}

function handleSubmitResponse(data) {
  const { formId, responses } = data;
  const ss = getSpreadsheet();
  const formsSheet = ss.getSheetByName(FORMS_SHEET);
  const formsData = formsSheet.getDataRange().getValues();

  let form = null;
  for (let i = 1; i < formsData.length; i++) {
    if (formsData[i][0] === formId) {
      form = {
        formId: formsData[i][0],
        fields_schema_json: formsData[i][5],
        isQuizMode: formsData[i][14]
      };
      break;
    }
  }

  if (!form) return createJsonResponse({ success: false, error: 'Form tidak ditemukan.' });

  const sheet = ss.getSheetByName(`res_${formId}`);
  if (!sheet) return createJsonResponse({ success: false, error: 'Tab respon tidak ditemukan.' });

  const sanitizedResponses = sanitize(responses);
  const isQuiz = form.isQuizMode === true || form.isQuizMode === 'TRUE';
  let totalScore = 0;
  let maxPossibleScore = 0;

  const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];

  if (isQuiz) {
    const fields = JSON.parse(form.fields_schema_json || '[]');
    fields.forEach(f => {
      const userAnswer = sanitizedResponses[f.label];
      const correctAnswer = f.correctAnswer;
      const points = parseInt(f.points || 0);
      if (points > 0) {
        maxPossibleScore += points;
        if (correctAnswer !== undefined) {
          if (Array.isArray(correctAnswer)) {
            if (Array.isArray(userAnswer) &&
                correctAnswer.length === userAnswer.length &&
                correctAnswer.every(val => userAnswer.includes(val))) {
              totalScore += points;
            }
          } else if (userAnswer !== undefined && String(userAnswer).trim().toLowerCase() === String(correctAnswer).trim().toLowerCase()) {
            totalScore += points;
          }
        }
      }
    });
  }

  const rowData = [new Date().toISOString()];
  for (let i = 1; i < headers.length; i++) {
    const hName = headers[i];
    if (hName === 'Total Skor') { rowData.push(totalScore); continue; }
    let value = sanitizedResponses[hName];

    // Upload file ke Google Drive
    if (value && typeof value === 'object' && value.base64) {
      try {
        const folder = DriveApp.getFolderById(CONFIG.GDRIVE_FOLDER_ID);
        const parts = value.base64.split(',');
        const base64Data = parts.length > 1 ? parts[1] : parts[0];
        const decoded = Utilities.base64Decode(base64Data);
        const blob = Utilities.newBlob(decoded, value.mimeType, value.fileName);
        const file = folder.createFile(blob);
        file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
        value = file.getUrl();
      } catch (err) {
        value = `Error upload: ${err.message}`;
      }
    }
    rowData.push(value || '');
  }

  sheet.appendRow(rowData);
  return createJsonResponse({
    success: true,
    message: 'Tanggapan berhasil disimpan.',
    score: isQuiz ? totalScore : null,
    maxScore: isQuiz ? maxPossibleScore : null
  });
}

function handleGetResponses(data) {
  const { formId } = data;
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(`res_${formId}`);
  if (!sheet || sheet.getLastRow() < 1) {
    return createJsonResponse({ success: true, responses: [], headers: [] });
  }
  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const responses = [];
  for (let i = 1; i < values.length; i++) {
    const resp = {};
    headers.forEach((h, idx) => { resp[h] = values[i][idx]; });
    responses.push(resp);
  }
  return createJsonResponse({ success: true, changed: true, headers, responses });
}

function handleGetFormBySlug(data) {
  const { customSlug } = data;
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(FORMS_SHEET);
  if (!sheet) return createJsonResponse({ success: false, error: 'Sheet tidak ditemukan' });
  const dataRange = sheet.getDataRange().getValues();
  for (let i = 1; i < dataRange.length; i++) {
    if (dataRange[i][1] === customSlug || dataRange[i][0] === customSlug) {
      return createJsonResponse({
        success: true,
        form: {
          formId: dataRange[i][0], customSlug: dataRange[i][1], username: dataRange[i][2],
          title: dataRange[i][3], description: dataRange[i][4], fields_schema_json: dataRange[i][5],
          theme: dataRange[i][6], backgroundPattern: dataRange[i][7], isActive: dataRange[i][8],
          confirmationMessage: dataRange[i][9], gformUrl: dataRange[i][10],
          userSpreadsheetId: dataRange[i][12], userFolderId: dataRange[i][13], isQuizMode: dataRange[i][14]
        }
      });
    }
  }
  return createJsonResponse({ success: false, error: 'Form tidak ditemukan' });
}

function handleGetCreatorForms(data) {
  const { username } = data;
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(FORMS_SHEET);
  if (!sheet) return createJsonResponse({ success: true, forms: [] });
  const dataRange = sheet.getDataRange().getValues();
  const forms = [];
  for (let i = 1; i < dataRange.length; i++) {
    if (dataRange[i][2] === username) {
      forms.push({
        formId: dataRange[i][0], customSlug: dataRange[i][1],
        title: dataRange[i][3], isActive: dataRange[i][8], createdAt: dataRange[i][11]
      });
    }
  }
  forms.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  return createJsonResponse({ success: true, changed: true, forms });
}

function handleToggleFormStatus(data) {
  const { formId, isActive } = data;
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(FORMS_SHEET);
  const dataRange = sheet.getDataRange().getValues();
  for (let i = 1; i < dataRange.length; i++) {
    if (dataRange[i][0] === formId) {
      sheet.getRange(i + 1, 9).setValue(isActive);
      return createJsonResponse({ success: true });
    }
  }
  return createJsonResponse({ success: false, error: 'Form tidak ditemukan' });
}

function handleDeleteForm(data) {
  const { formId } = data;
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(FORMS_SHEET);
  const dataRange = sheet.getDataRange().getValues();
  for (let i = 1; i < dataRange.length; i++) {
    if (dataRange[i][0] === formId) {
      sheet.deleteRow(i + 1);
      const resSheet = ss.getSheetByName(`res_${formId}`);
      if (resSheet) ss.deleteSheet(resSheet);
      return createJsonResponse({ success: true, message: 'Form berhasil dihapus' });
    }
  }
  return createJsonResponse({ success: false, error: 'Form tidak ditemukan' });
}
