importScripts("https://js.pusher.com/beams/service-worker.js");

/* 
  Form Architect - Service Worker for Native Notifications
  - Pusher Beams: handles background push (tab closed)
  - Interactive Actions: Approve/Reject users directly from notification
*/

let adminCredentials = null;

// ===== MESSAGE LISTENER (Get Credentials from Frontend) =====
self.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SET_ADMIN_CREDENTIALS') {
        adminCredentials = event.data.payload; // { username, token, gasUrl }

        // Persist to Cache Storage to survive SW restarts
        const credsResponse = new Response(JSON.stringify(adminCredentials));
        event.waitUntil(
            caches.open('admin-auth-v1').then(cache => {
                return cache.put('credentials', credsResponse);
            })
        );
        console.log('[SW] Admin credentials updated and persisted');
    }
});

// ===== NOTIFICATION CLICK =====
self.addEventListener('notificationclick', (event) => {
    const action = event.action;
    const notification = event.notification;
    const data = notification.data || {};

    event.waitUntil((async () => {
        // 0. Ensure credentials are loaded from cache if memory is empty
        if (!adminCredentials) {
            try {
                const cache = await caches.open('admin-auth-v1');
                const cachedResponse = await cache.match('credentials');
                if (cachedResponse) {
                    adminCredentials = await cachedResponse.json();
                    console.log('[SW] Credentials restored from cache');
                }
            } catch (e) { console.error('[SW] Cache restore failed', e); }
        }

        const targetUsername = data.targetUsername;
        const gasUrl = data.gasUrl || (adminCredentials ? adminCredentials.gasUrl : null);
        const username = data.username || (adminCredentials ? adminCredentials.username : null);
        const token = data.token || (adminCredentials ? adminCredentials.token : null);
        const url = data.url || '/admin';

        // 1. Klik body notifikasi (bukan tombol aksi)
        if (!action) {
            const clientList = await clients.matchAll({ type: 'window', includeUncontrolled: true });
            for (let i = 0; i < clientList.length; i++) {
                const client = clientList[i];
                if (client.url.includes('/admin') && 'focus' in client) {
                    notification.close();
                    return client.focus();
                }
            }
            if (clients.openWindow) {
                notification.close();
                return clients.openWindow(url);
            }
            notification.close();
            return;
        }

        // 2. Tombol aksi Approve / Reject
        notification.close();

        if (!gasUrl || !username || !token || !targetUsername) {
            console.error('[SW] Missing data for action:', { gasUrl, username, token, targetUsername });
            return;
        }

        const gasAction = action === 'approve' ? 'approveUser' : 'rejectUser';

        try {
            await fetch(gasUrl, {
                method: 'POST',
                mode: 'no-cors',
                headers: { 'Content-Type': 'text/plain;charset=utf-8' },
                body: JSON.stringify({ action: gasAction, username, token, targetUsername })
            });

            // BROADCAST: Beritahu Admin Panel (jika terbuka) untuk menghapus user dari UI
            const bc = new BroadcastChannel('admin_actions');
            bc.postMessage({ type: 'USER_PROCESSED', targetUsername });
            bc.close();

            await self.registration.showNotification('Sistem Diperbarui', {
                body: `User @${targetUsername} telah ${action === 'approve' ? 'disetujui' : 'ditolak'}.`,
                icon: '/icon-192.png',
                tag: 'admin-action-result',
                silent: true
            });
        } catch (err) {
            console.error('[SW] Action failed:', err);
        }
    })());
});
