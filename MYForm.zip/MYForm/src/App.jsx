import React, { Suspense, lazy } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import { useMediaQuery } from './hooks/useMediaQuery';
import { Loader2 } from 'lucide-react';

// Layouts (Diubah menjadi Lazy agar HP tidak mendownload kode PC, dan sebaliknya)
const CreatorDesktopLayout = lazy(() => import('./layouts/CreatorDesktopLayout'));
const CreatorMobileLayout = lazy(() => import('./layouts/CreatorMobileLayout'));
import AuthLayout from './components/AuthLayout';

// Halaman-halaman (Diubah menjadi Lazy Loading untuk Code Splitting)
const Login = lazy(() => import('./pages/Login'));
const Register = lazy(() => import('./pages/Register'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const FormBuilder = lazy(() => import('./pages/FormBuilder'));
const FormResponses = lazy(() => import('./pages/FormResponses'));
const Documentation = lazy(() => import('./pages/Documentation'));
const PublicForm = lazy(() => import('./pages/PublicForm'));
const Settings = lazy(() => import('./pages/Settings'));
const CoffeePage = lazy(() => import('./pages/Coffee'));
const AdminPanel = lazy(() => import('./pages/AdminPanel'));

// Spinner Elegan untuk Jeda Loading Antar Halaman
const GlobalLoader = () => (
    <div className="flex h-full w-full min-h-[60vh] flex-col items-center justify-center space-y-4">
        <Loader2 className="animate-spin h-10 w-10 text-blue-600" />
        <p className="text-gray-400 font-bold uppercase tracking-widest text-xs animate-pulse">Memuat Komponen...</p>
    </div>
);

// Helper Route Component
const ProtectedRoute = ({ children }) => {
    const { user, loading } = useAuth();
    if (loading) return <GlobalLoader />;
    if (!user || !user.username) return <Navigate to="/login" replace />;
    return children;
};

// PublicRoute: Mencegah user yang sudah login mengakses halaman auth
const PublicRoute = ({ children }) => {
    const { user, loading } = useAuth();
    if (loading) return <GlobalLoader />;
    if (user && user.username) return <Navigate to="/" replace />;
    return children;
};

const App = () => {
    const isMobile = useMediaQuery('(max-width: 768px)');
    const CreatorLayout = isMobile ? CreatorMobileLayout : CreatorDesktopLayout;

    return (
        <BrowserRouter>
            <Suspense fallback={<GlobalLoader />}>
                <Routes>
                    {/* Public Auth Routes with Guest Protection */}
                    <Route element={
                        <PublicRoute>
                            <AuthLayout />
                        </PublicRoute>
                    }>
                        <Route path="/login" element={<Login />} />
                        <Route path="/daftar" element={<Register />} />
                    </Route>

                    <Route path="/f/:customSlug" element={<PublicForm />} />

                    <Route path="/" element={
                        <ProtectedRoute>
                            <CreatorLayout />
                        </ProtectedRoute>
                    }>
                        <Route index element={<Dashboard />} />
                        <Route path="builder" element={<FormBuilder />} />
                        <Route path="builder/:formId" element={<FormBuilder />} />
                        <Route path="responses/:formId" element={<FormResponses />} />
                        <Route path="docs" element={<Documentation />} />
                        <Route path="settings" element={<Settings />} />
                        <Route path="coffee" element={<CoffeePage />} />
                        <Route path="admin" element={<AdminPanel />} />
                    </Route>
                </Routes>
            </Suspense>
        </BrowserRouter>
    );
};

export default App;
