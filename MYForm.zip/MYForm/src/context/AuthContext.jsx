import React, { createContext, useContext, useState, useEffect } from 'react';
import { gasRequest } from '../services/sheetsService';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);
    const [googleToken, setGoogleToken] = useState(null);

    // Cek Status Login di localStorage saat load awal (Secure Parse Pattern)
    useEffect(() => {
        const storedUser = localStorage.getItem('formBuilderUser');
        if (storedUser) {
            try {
                const parsedUser = JSON.parse(storedUser);
                // Mencegah JSON.parse set {} yang masuk kategori truthy di Javascript
                if (parsedUser && Object.keys(parsedUser).length > 0) {
                    setUser(parsedUser);
                } else {
                    localStorage.removeItem('formBuilderUser');
                }
            } catch (e) {
                localStorage.removeItem('formBuilderUser');
            }
        }

        const storedToken = localStorage.getItem('googleToken');
        if (storedToken) setGoogleToken(storedToken);

        setLoading(false);
    }, []);

    const login = async (username, password) => {
        const res = await gasRequest('login', { username, password });
        if (res.success) {
            const userData = {
                username: res.username,
                token: res.token,
                isVerified: res.isVerified,
                isAdmin: res.isAdmin,
                expires: res.expires
            };
            setUser(userData);
            localStorage.setItem('formBuilderUser', JSON.stringify(userData));

            // Sync URL Database Kustom dari server (lintas perangkat)
            if (res.customGasUrl) {
                localStorage.setItem('customGasUrl', res.customGasUrl);
            } else {
                localStorage.removeItem('customGasUrl');
            }
        }
        return res;
    };

    const register = async (username, password) => {
        // Register sekarang masuk ke antrean pending (Admin Approval)
        return await gasRequest('register', { username, password });
    };

    // Admin Methods
    const getPendingUsers = async (lastSyncHash = null) => {
        return await gasRequest('getPendingUsers', {
            username: user?.username,
            token: user?.token,
            lastSyncHash
        });
    };

    const approveUser = async (targetUsername) => {
        return await gasRequest('approveUser', {
            username: user?.username,
            token: user?.token,
            targetUsername
        });
    };

    const rejectUser = async (targetUsername) => {
        return await gasRequest('rejectUser', {
            username: user?.username,
            token: user?.token,
            targetUsername
        });
    };

    const getAllUsers = async (lastSyncHash = null) => {
        return await gasRequest('getAllUsers', {
            username: user?.username,
            token: user?.token,
            lastSyncHash
        });
    };

    const updateUserStatus = async (targetUsername, field, value) => {
        return await gasRequest('updateUserStatus', {
            username: user?.username,
            token: user?.token,
            targetUsername,
            field,
            value
        });
    };

    const adminDeleteUser = async (targetUsername) => {
        return await gasRequest('adminDeleteUser', {
            username: user?.username,
            token: user?.token,
            targetUsername
        });
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('formBuilderUser');
        localStorage.removeItem('googleToken');
    };

    const updateGoogleToken = (token) => {
        setGoogleToken(token);
        if (token) {
            localStorage.setItem('googleToken', token);
        } else {
            localStorage.removeItem('googleToken');
        }
    };

    const updateUser = (newUserData) => {
        if (!user) return;
        const updatedUser = { ...user, ...newUserData };
        setUser(updatedUser);
        localStorage.setItem('formBuilderUser', JSON.stringify(updatedUser));
    };

    return (
        <AuthContext.Provider value={{
            user, loading, login, register, logout, googleToken, updateGoogleToken,
            getPendingUsers, approveUser, rejectUser, updateUser,
            getAllUsers, updateUserStatus, adminDeleteUser
        }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
