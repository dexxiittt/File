import { gasRequest } from './sheetsService';

/**
 * Fungsi menembak action generateForm di GAS Node untuk diteruskan ke AI Grok.
 * Akan menghasilkan Promise yang mengembalikan JSON Skema Form.
 */
export const generateFormBlueprint = async (prompt, currentForm = null, username = null) => {
    return await gasRequest('generateForm', { prompt, currentForm, username });
};
