const getApiConfig = (action) => {
    return { url: import.meta.env.VITE_GAS_URL };
};

/**
 * Fungsi utama HTTP Request ke Backend.
 * Mendukung mode Google Apps Script (GAS) dan mode REST API murni.
 */
export const gasRequest = async (action, payload = {}) => {
    try {
        const { url } = getApiConfig(action);
        if (!url) throw new Error("API URL tidak ditemukan. Silakan konfigurasi di Pengaturan.");

        // Ambil token dan username dari localStorage jika ada (Phase 1 Security)
        const storedUser = localStorage.getItem('formBuilderUser');
        let token = null;
        let username = null;
        if (storedUser) {
            try {
                const parsed = JSON.parse(storedUser);
                token = parsed.token;
                username = parsed.username;
            } catch (e) { }
        }

        const fetchOptions = {
            method: "POST",
            body: JSON.stringify({ action, token, username, ...payload }),
            redirect: "follow",
            headers: {
                "Content-Type": "text/plain",
            }
        };

        const response = await fetch(url, fetchOptions);

        // Asumsi API selalu mengembalikan format Content-Type JSON
        const result = await response.json();
        return result;
    } catch (error) {
        console.error(`[GAS Request Error - ${action}]:`, error);
        return { success: false, error: error.message || "Gagal terhubung ke GAS" };
    }
};

/**
 * Helper mengubah objek File menjadi payload base64 JSON
 * Digunakan sebelum file dikirim ke GAS di action submitResponse
 */
export const fileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve({
            base64: reader.result,
            fileName: file.name,
            mimeType: file.type
        });
        reader.onerror = (error) => reject(error);
    });
};

/**
 * Menghasilkan Fingerprint Perangkat (Device ID) semi-unik 
 * Berdasarkan kombinasi User Agent, Resolusi Layar, Bahasa, dan Timezone.
 */
export const getDeviceFingerprint = () => {
    const info = [
        navigator.userAgent,
        window.screen.width,
        window.screen.height,
        navigator.language,
        new Date().getTimezoneOffset()
    ].join('###');

    // Simple FNV-1a Hashing Implementation (32-bit)
    let hash = 0x811c9dc5;
    for (let i = 0; i < info.length; i++) {
        hash ^= info.charCodeAt(i);
        hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
    }
    return (hash >>> 0).toString(16).padStart(8, '0');
};
