import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { gasRequest } from '../services/sheetsService';
import { Eye, List, Plus, Layers, Loader2, Pencil, Copy, Check, Trash2, Database, CheckCircle, QrCode as QrIcon } from 'lucide-react';
import QRCode from 'qrcode';
import ConfirmModal from '../components/ConfirmModal';
import BottomSheet from '../components/BottomSheet';

export default function Dashboard() {
    const { user, googleToken } = useAuth();
    const [forms, setForms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [copiedId, setCopiedId] = useState(null);
    const [confirmModal, setConfirmModal] = useState({ isOpen: false, formId: null });
    const [storageUsed, setStorageUsed] = useState(0);
    const [isDbVerified, setIsDbVerified] = useState(user?.isVerified || false);
    const [qrModal, setQrModal] = useState({ isOpen: false, qrUrl: '', title: '', publicUrl: '' });

    const fetchForms = async () => {
        const cacheKey = `forms_cache_${user.username}`;
        const cachedStr = localStorage.getItem(cacheKey);
        let lastHash = null;

        // 1. Optimistic Load
        if (cachedStr) {
            try {
                const cached = JSON.parse(cachedStr);
                setForms(cached.data || []);
                if (cached.storageUsed !== undefined) setStorageUsed(cached.storageUsed);
                if (cached.isVerified !== undefined) setIsDbVerified(cached.isVerified);
                lastHash = cached.hash;
                setLoading(false);
            } catch (e) {
                console.error("Cache corrupted");
            }
        }

        // 2. Background Fetch (Phase 10: Conditional Sync)
        const res = await gasRequest('getCreatorForms', { username: user.username, lastSyncHash: lastHash });
        if (res.success) {
            if (res.storageUsed !== undefined) setStorageUsed(res.storageUsed);
            if (res.isVerified !== undefined) setIsDbVerified(res.isVerified);
            // 3. Hanya update jika data berubah (res.changed !== false)
            if (res.changed !== false) {
                const newForms = res.forms || [];
                setForms(newForms);
                localStorage.setItem(cacheKey, JSON.stringify({ data: newForms, hash: res.hash, storageUsed: res.storageUsed, isVerified: res.isVerified }));
            }
        }
        setLoading(false);
    };

    useEffect(() => {
        if (user?.username) {
            fetchForms();
        }
    }, [user]);

    const toggleStatus = async (formId, currentStatus) => {
        // Optimistic UI Update & Cache sync
        const updated = forms.map(f => f.formId === formId ? { ...f, isActive: !currentStatus } : f);
        setForms(updated);
        localStorage.setItem(`forms_cache_${user.username}`, JSON.stringify(updated));

        // Background Request ke GAS
        await gasRequest('toggleFormStatus', { formId, isActive: !currentStatus });
    };

    const copyToClipboard = (slug, id) => {
        const url = `${window.location.origin}/f/${slug}`;
        navigator.clipboard.writeText(url);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
    };

    const deleteForm = async () => {
        const { formId } = confirmModal;
        if (!formId) return;

        // Optimistic Update
        const updated = forms.filter(f => f.formId !== formId);
        setForms(updated);
        localStorage.setItem(`forms_cache_${user.username}`, JSON.stringify(updated));

        await gasRequest('deleteForm', { formId });
        setConfirmModal({ isOpen: false, formId: null });
    };

    const handleShowQr = async (slug, title) => {
        const publicUrl = `${window.location.origin}/f/${slug}`;
        try {
            const qrUrl = await QRCode.toDataURL(publicUrl, {
                width: 400,
                margin: 2,
                color: {
                    dark: '#4f46e5', // INDIGO-600
                    light: '#ffffff'
                }
            });
            setQrModal({ isOpen: true, qrUrl, title, publicUrl });
        } catch (err) {
            console.error(err);
        }
    };

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center py-32 space-y-4">
                <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
                <p className="text-gray-500 font-medium tracking-wide">Menyelaraskan Data Formulir...</p>
            </div>
        );
    }

    return (
        <div className="space-y-8 pb-10 font-sans">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between bg-white/60 lg:backdrop-blur-md p-5 sm:p-8 rounded-xl shadow-sm border border-gray-200/60 gap-4">
                <div>
                    <h1 className="text-2xl sm:text-3xl font-black text-gray-900 tracking-tight leading-tight">Dasbor Area</h1>
                    <p className="text-xs sm:text-sm font-medium text-gray-500 mt-1 sm:mt-2">Kelola kuis dan formulir modern Anda dalam satu tempat.</p>
                </div>
                <Link
                    to="/builder"
                    className="inline-flex items-center justify-center px-6 py-3.5 border border-transparent rounded-2xl shadow-md shadow-blue-200 text-sm font-bold text-white bg-blue-600 hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-300 transition-all active:scale-[0.97]"
                >
                    <Plus strokeWidth={2.5} size={18} className="mr-2" /> Rancang Form
                </Link>
            </div>

            {/* Phase 6: Penyimpanan & Data Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-in fade-in slide-in-from-top-4 duration-500">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4">
                    <div className="p-3 bg-indigo-50 text-blue-600 rounded-2xl">
                        <Layers size={20} />
                    </div>
                    <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Formulir</p>
                        <h2 className="text-xl font-black text-gray-900">{forms.length}</h2>
                    </div>
                </div>

                {isDbVerified || googleToken ? (
                    /* User Pro/Verified: 1 kartu gabungan saja */
                    <div className="sm:col-span-2 lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4 border-l-4 border-l-emerald-500">
                        <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl shrink-0">
                            <CheckCircle size={22} />
                        </div>
                        <div>
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Status Akun</p>
                            <h2 className="text-sm font-bold text-emerald-600">
                                Terverifikasi Pro <span className="ml-1.5 text-[10px] font-bold bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full">Kuota &amp; Storage Unlimited</span>
                            </h2>
                        </div>
                    </div>
                ) : (
                    /* User Free: 2 kartu terpisah */
                    <>
                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-4">
                            <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl">
                                <Database size={20} />
                            </div>
                            <div>
                                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Kuota Formulir</p>
                                <h2 className="text-sm font-bold text-gray-700">{forms.length} / 10 <span className="text-[10px] font-medium text-gray-400 ml-1">(Batas Standar)</span></h2>
                            </div>
                        </div>

                        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col justify-center space-y-3">
                            <div className="flex items-center space-x-3">
                                <div className={`p-2.5 rounded-xl ${storageUsed > 90000000 ? 'bg-rose-50 text-rose-600' : 'bg-blue-50 text-blue-600'}`}>
                                    <Database size={18} />
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">File Storage</p>
                                    <h2 className="text-sm font-bold text-gray-800">
                                        {(storageUsed / 1024 / 1024).toFixed(1)} MB <span className="text-[10px] font-medium text-gray-400 ml-1">/ 100 MB</span>
                                    </h2>
                                </div>
                            </div>
                            <div className="w-full bg-gray-100 rounded-full h-1.5 mt-1">
                                <div
                                    className={`h-1.5 rounded-full ${storageUsed > 90000000 ? 'bg-rose-500' : 'bg-blue-500'}`}
                                    style={{ width: `${Math.min(100, (storageUsed / 104857600) * 100)}%` }}
                                ></div>
                            </div>
                        </div>
                    </>
                )}

                <div className="hidden lg:flex bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-2xl shadow-md items-center justify-between text-white relative overflow-hidden group">
                    <div className="relative z-10">
                        <p className="text-[10px] font-black text-white/60 uppercase tracking-widest">Mode Penyimpanan</p>
                        <h2 className="text-sm font-bold">{googleToken ? 'Google Personal' : 'GAS Cloud Terpusat'}</h2>
                    </div>
                    <Database size={40} className="absolute -right-2 -bottom-2 text-white/10 group-hover:scale-110 transition-transform" />
                </div>
            </div>
            {forms.length === 0 ? (
                <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-16 text-center border border-gray-200/50 border-dashed flex flex-col items-center justify-center animate-in fade-in duration-700">
                    <div className="bg-indigo-50 p-6 rounded-full mb-6 relative">
                        <Layers size={48} className="text-indigo-400 relative z-10" />
                        <div className="absolute inset-0 bg-indigo-200/50 rounded-full blur-xl z-0"></div>
                    </div>
                    <h3 className="text-xl font-bold text-gray-800 mb-2">Area Kosong</h3>
                    <p className="text-gray-500 font-medium mb-6 max-w-sm">Anda belum memiliki formulir satupun. Anda bisa merakit yang pertama sekarang menggunakan bantuan AI.</p>
                    <Link to="/builder" className="text-blue-600 font-bold hover:underline underline-offset-4 decoration-2">Mulai Buat Formulir Pertama</Link>
                </div>
            ) : (
                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
                    {forms.map(form => (
                        <div key={form.formId} className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 sm:p-6 flex flex-col hover:shadow-xl hover:border-gray-200 transition-all group overflow-hidden">
                            <div className="flex justify-between items-start mb-5">
                                <h3 className="text-lg font-bold text-gray-900 line-clamp-2 leading-snug group-hover:text-blue-600 transition-colors" title={form.title}>
                                    {form.title || 'Formulir Tanpa Judul'}
                                </h3>
                                <div className="flex items-center space-x-2 shrink-0 ml-3">
                                    <button
                                        onClick={() => setConfirmModal({ isOpen: true, formId: form.formId })}
                                        className="p-1.5 text-gray-300 hover:text-rose-500 transition-colors bg-gray-50 hover:bg-rose-50 rounded-lg border border-gray-100"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                    <button
                                        onClick={() => toggleStatus(form.formId, form.isActive)}
                                        className={`relative inline-flex h-7 w-12 items-center rounded-full transition-colors ${form.isActive ? 'bg-emerald-500 shadow-inner' : 'bg-gray-200'}`}
                                    >
                                        <span className={`inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform ${form.isActive ? 'translate-x-6' : 'translate-x-1'}`} />
                                    </button>
                                </div>
                            </div>

                            <div className="bg-gray-50 rounded-2xl p-3.5 mb-6 flex-1 text-sm border border-gray-100 flex items-center justify-between group/link relative overflow-hidden">
                                <div className="truncate flex-1 min-w-0 pr-2">
                                    <span className="text-gray-400 block mb-1 font-bold text-[9px] uppercase tracking-wider">Tautan Publik</span>
                                    <p className="font-mono text-gray-500 font-bold break-all sm:truncate text-[10px] leading-tight">
                                        {window.location.origin}/f/{form.customSlug}
                                    </p>
                                </div>
                                <button
                                    onClick={() => handleShowQr(form.customSlug, form.title)}
                                    className="shrink-0 p-2.5 bg-indigo-50 text-indigo-600 rounded-xl hover:bg-indigo-100 transition-all shadow-sm border border-indigo-100"
                                    title="Tampilkan QR Code"
                                >
                                    <QrIcon size={16} />
                                </button>
                                <button
                                    onClick={() => copyToClipboard(form.customSlug, form.formId)}
                                    className={`shrink-0 p-2.5 rounded-xl transition-all ${copiedId === form.formId ? 'bg-emerald-100 text-emerald-600' : 'bg-white text-gray-400 hover:text-blue-600 shadow-sm border border-gray-100'}`}
                                    title="Salin Tautan"
                                >
                                    {copiedId === form.formId ? <Check size={14} /> : <Copy size={16} />}
                                </button>
                            </div>

                            <div className="flex flex-wrap gap-2 mt-auto relative z-10">
                                <Link
                                    to={`/builder/${form.formId}`}
                                    className="flex-1 flex items-center justify-center space-x-1 sm:space-x-2 px-2 py-3 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-xl text-[10px] sm:text-xs font-bold transition-all border border-amber-100/50"
                                >
                                    <Pencil size={14} strokeWidth={2.5} /> <span>Edit</span>
                                </Link>
                                <Link
                                    to={`/f/${form.customSlug}`}
                                    target="_blank"
                                    className="flex-1 flex items-center justify-center space-x-1 sm:space-x-2 px-2 py-3 bg-white hover:bg-gray-50 text-gray-700 rounded-xl text-[10px] sm:text-xs font-bold transition-all border border-gray-200 hover:border-gray-300"
                                >
                                    <Eye size={14} strokeWidth={2.5} /> <span>Lihat</span>
                                </Link>
                                <Link
                                    to={`/responses/${form.formId}`}
                                    className="flex-1 flex items-center justify-center space-x-1 sm:space-x-2 px-2 py-3 bg-indigo-50 hover:bg-blue-100 text-blue-700 rounded-xl text-[10px] sm:text-xs font-bold transition-all border border-indigo-200/50"
                                >
                                    <List size={14} strokeWidth={2.5} /> <span>Data</span>
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            <ConfirmModal
                isOpen={confirmModal.isOpen}
                onClose={() => setConfirmModal({ isOpen: false, formId: null })}
                onConfirm={deleteForm}
                title="Hapus Formulir Selamanya?"
                message="Apakah Anda yakin ingin menghapus formulir ini selamanya? Seluruh data tanggapan juga akan ikut terhapus."
                confirmText="Hapus Permanen"
                type="danger"
            />

            {/* QR Code Bottom Sheet */}
            <BottomSheet
                isOpen={qrModal.isOpen}
                onClose={() => setQrModal({ ...qrModal, isOpen: false })}
                title="Pindai Formulir"
            >
                <div className="flex flex-col items-center py-6 space-y-6">
                    <div className="bg-white p-6 rounded-3xl shadow-xl border border-gray-100 relative group">
                        <img src={qrModal.qrUrl} alt="QR Code" className="w-56 h-56 transition-transform group-hover:scale-105" />
                        <div className="absolute inset-0 bg-indigo-500/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-3xl pointer-events-none" />
                    </div>
                    <div className="text-center space-y-2 px-4">
                        <h3 className="text-lg font-black text-gray-900 leading-tight line-clamp-2 max-w-xs mx-auto">
                            {qrModal.title || 'Formulir Tanpa Judul'}
                        </h3>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em]">Pindai untuk mulai mengisi</p>
                    </div>
                    <div className="w-full space-y-3 pt-4 border-t border-gray-50">
                        <a
                            href={qrModal.qrUrl}
                            download={`QR-${qrModal.title || 'Form'}.png`}
                            className="w-full flex items-center justify-center gap-2 bg-indigo-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-indigo-100 hover:bg-indigo-700 active:scale-95 transition-all"
                        >
                            Unduh Kode QR
                        </a>
                        <button
                            onClick={() => {
                                navigator.clipboard.writeText(qrModal.publicUrl);
                                alert("Tautan disalin!");
                            }}
                            className="w-full py-4 text-gray-400 font-black text-xs uppercase tracking-widest hover:text-indigo-600 transition-colors"
                        >
                            Salin Tautan Publik
                        </button>
                    </div>
                </div>
            </BottomSheet>
        </div>
    );
}
