import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Layers, Mail, Lock, User, ShieldCheck, ArrowRight, CheckCircle2, XCircle, RefreshCw, Eye, EyeOff } from 'lucide-react';
import Pusher from 'pusher-js';

export default function Register() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);
    const [status, setStatus] = useState('pending'); // 'pending' | 'approved' | 'rejected'
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const { register } = useAuth();
    const navigate = useNavigate();

    useEffect(() => {
        if (!isSuccess || status !== 'pending') return;

        const pusher = new Pusher(import.meta.env.VITE_PUSHER_KEY || '0302a51d1ad8ee4a2dc6', {
            cluster: import.meta.env.VITE_PUSHER_CLUSTER || 'ap1'
        });

        const channel = pusher.subscribe(`user-channel-${username}`);

        channel.bind('account-approved', () => {
            setStatus('approved');
            // Optional: Auto redirect after few seconds or stay for success message
        });

        channel.bind('account-rejected', () => {
            setStatus('rejected');
        });

        return () => {
            channel.unbind_all();
            channel.unsubscribe();
            pusher.disconnect();
        };
    }, [isSuccess, username, status]);

    const handleRegisterRequest = async (e) => {
        e.preventDefault();
        setError('');

        if (password !== confirmPassword) {
            return setError('Konfirmasi kata sandi tidak cocok.');
        }
        if (password.length < 6) {
            return setError('Kata sandi minimal 6 karakter.');
        }

        setLoading(true);
        const res = await register(username, password);

        if (res.success) {
            setIsSuccess(true);
            setLoading(false);
        } else {
            setLoading(false);
            setError(res.error || 'Terjadi kesalahan saat memproses data.');
        }
    };

    if (isSuccess) {
        return (
            <div className="w-full text-center">
                <div className="flex justify-center mb-6">
                    {status === 'pending' && (
                        <div className="bg-emerald-100 p-4 rounded-full text-emerald-600 lg:shadow-lg lg:shadow-emerald-100">
                            <ShieldCheck size={48} />
                        </div>
                    )}
                    {status === 'approved' && (
                        <div className="bg-blue-100 p-4 rounded-full text-blue-600 animate-in zoom-in duration-500 lg:shadow-lg lg:shadow-blue-100">
                            <CheckCircle2 size={48} />
                        </div>
                    )}
                    {status === 'rejected' && (
                        <div className="bg-red-100 p-4 rounded-full text-red-600 animate-in zoom-in duration-500 lg:shadow-lg lg:shadow-red-100">
                            <XCircle size={48} />
                        </div>
                    )}
                </div>

                {status === 'pending' && (
                    <>
                        <h2 className="text-2xl font-black text-gray-900 mb-4 tracking-tight">Pendaftaran Terkirim!</h2>
                        <p className="text-gray-500 font-medium leading-relaxed mb-8 text-sm px-2">
                            Terima kasih telah mendaftar. Akun Anda saat ini sedang dalam antrean untuk <strong className="text-blue-600">disetujui oleh Admin</strong>.
                        </p>
                        <div className="flex items-center justify-center gap-2 mb-8 bg-emerald-50 py-3 rounded-2xl border border-emerald-100 animate-pulse">
                            <RefreshCw size={14} className="text-emerald-500 animate-spin" />
                            <span className="text-[10px] font-black text-emerald-700 uppercase tracking-widest">Menunggu Persetujuan</span>
                        </div>
                    </>
                )}

                {status === 'approved' && (
                    <>
                        <h2 className="text-2xl font-black text-blue-600 mb-4 tracking-tight">Akun Aktif!</h2>
                        <p className="text-gray-500 font-medium leading-relaxed mb-8 text-sm px-2">
                            Selamat! Admin baru saja <strong className="text-blue-600">menyetujui</strong> pendaftaran Anda. Akun @{username} kini sudah aktif dan siap digunakan.
                        </p>
                    </>
                )}

                {status === 'rejected' && (
                    <>
                        <h2 className="text-2xl font-black text-red-600 mb-4 tracking-tight">Pendaftaran Ditolak</h2>
                        <p className="text-gray-500 font-medium leading-relaxed mb-8 text-sm px-2">
                            Mohon maaf, pendaftaran akun Anda tidak disetujui oleh Admin dan telah dihapus dari antrean.
                        </p>
                    </>
                )}

                <button
                    onClick={() => navigate('/login')}
                    className={`w-full py-4 text-xs font-black uppercase tracking-widest text-white rounded-2xl lg:shadow-xl transition-all flex items-center justify-center gap-2 active:scale-95 ${status === 'rejected' ? 'bg-gray-800 lg:shadow-gray-200' : 'bg-blue-600 lg:shadow-blue-200 hover:bg-blue-700'
                        }`}
                >
                    {status === 'approved' ? 'Mulai Sekarang' : 'Kembali ke Login'} <ArrowRight size={18} />
                </button>
            </div>
        );
    }

    return (
        <div className="w-full">
            <form className="space-y-6" onSubmit={handleRegisterRequest}>
                {error && (
                    <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-2xl text-sm font-medium animate-in fade-in zoom-in-95 duration-200">
                        {error}
                    </div>
                )}
                <div>
                    <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2 uppercase tracking-widest text-[10px] mb-2 px-1">
                        <User size={12} className="text-gray-400" /> USERNAME
                    </label>
                    <div className="mt-1">
                        <input
                            type="text"
                            required
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="appearance-none block w-full px-4 py-4 bg-white border border-gray-200 rounded-2xl lg:shadow-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 sm:text-sm transition-all font-medium"
                            placeholder="Username unik..."
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2 uppercase tracking-widest text-[10px] mb-2 px-1">
                        <Lock size={12} className="text-gray-400" /> KATA SANDI
                    </label>
                    <div className="mt-1 relative group">
                        <input
                            type={showPassword ? "text" : "password"}
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="appearance-none block w-full px-4 py-4 pr-12 bg-white border border-gray-200 rounded-2xl lg:shadow-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 sm:text-sm transition-all font-medium"
                            placeholder="••••••••"
                        />
                        <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute inset-y-0 right-0 pr-4 flex items-center justify-center text-gray-400 hover:text-blue-600 transition-colors focus:outline-none"
                        >
                            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-semibold text-gray-700 flex items-center gap-2 uppercase tracking-widest text-[10px] mb-2 px-1">
                        <ShieldCheck size={12} className="text-gray-400" /> KONFIRMASI KATA SANDI
                    </label>
                    <div className="mt-1 relative group">
                        <input
                            type={showConfirmPassword ? "text" : "password"}
                            required
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            className="appearance-none block w-full px-4 py-4 pr-12 bg-white border border-gray-200 rounded-2xl lg:shadow-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 sm:text-sm transition-all font-medium"
                            placeholder="••••••••"
                        />
                        <button
                            type="button"
                            onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                            className="absolute inset-y-0 right-0 pr-4 flex items-center justify-center text-gray-400 hover:text-blue-600 transition-colors focus:outline-none"
                        >
                            {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                    </div>
                </div>

                <div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex justify-center py-4 px-4 border border-transparent rounded-2xl lg:shadow-xl lg:shadow-blue-200 text-xs font-black uppercase tracking-widest text-white bg-blue-600 hover:bg-blue-700 active:scale-[0.98] outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 disabled:lg:shadow-none transition-all"
                    >
                        {loading ? 'Mengirim Data...' : 'Daftar Sekarang'}
                    </button>
                </div>
            </form>

            <div className="mt-10 text-center text-xs border-t border-gray-100 pt-6">
                <span className="text-gray-400 font-bold uppercase tracking-widest">Sudah punya akun? </span>
                <Link to="/login" className="font-black text-blue-600 hover:underline underline-offset-4 transition-all">
                    Masuk di sini
                </Link>
            </div>
        </div>
    );
}

