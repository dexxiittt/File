import React from 'react';
import { Coffee, Heart, Smartphone, CreditCard, Copy, Check, Layers } from 'lucide-react';

const CoffeePage = () => {
    return (
        <div className="max-w-4xl mx-auto space-y-8 pb-10 font-sans animate-in fade-in slide-in-from-bottom-4 duration-200 texture-noise relative">
            <div className="absolute inset-0 pattern-grid opacity-[0.08] pointer-events-none rounded-[3rem]"></div>
            {/* Header Hero */}
            <div className="relative overflow-hidden bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-8 sm:p-12 text-white shadow-2xl shadow-blue-200">
                <div className="absolute inset-0 pattern-polkadot opacity-[0.1] pointer-events-none"></div>
                <div className="relative z-10">
                    <div className="inline-flex items-center px-4 py-2 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold tracking-widest uppercase mb-6 border border-white/30">
                        <Coffee size={14} className="mr-2" /> Support Developer
                    </div>
                    <h1 className="text-3xl sm:text-5xl font-black mb-6 leading-tight">
                        Secangkir Kopi untuk <br />
                        <span className="text-blue-200">Kreativitas Tanpa Batas</span>
                    </h1>
                    <p className="text-blue-100 text-sm sm:text-lg max-w-xl font-medium leading-relaxed">
                        Terima kasih telah menggunakan MYForm Architect. Dukungan Anda sangat berarti untuk membantu biaya operasional server dan pengembangan fitur-fitur AI masa depan agar tetap bisa dinikmati semua orang.
                    </p>
                </div>

                {/* Decorative Elements */}
                <div className="absolute top-0 right-0 w-64 h-64 bg-white/20 rounded-full -mr-20 -mt-20"></div>
                <div className="absolute bottom-0 left-0 w-32 h-32 bg-blue-400/30 rounded-full -ml-10 -mb-10"></div>
                <Coffee size={250} className="absolute -right-16 -bottom-16 text-white/[0.07] rotate-12" />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
                <div className="space-y-6">
                    {/* Left Column: Why? and Note */}
                    <div className="bg-white/70 backdrop-blur-md p-8 rounded-xl border border-gray-100 shadow-sm">
                        <h2 className="text-xl font-black text-gray-900 mb-6 flex items-center">
                            <Heart className="text-rose-500 mr-2" fill="currentColor" /> Kenapa Mendukung?
                        </h2>
                        <div className="space-y-6">
                            {[
                                { title: 'Server AI 24/7', desc: 'Menjaga mesin cerdas tetap hidup untuk merakit formulir Anda.' },
                                { title: 'Inovasi Fitur', desc: 'Bantu kami meriset fitur-fitur baru yang lebih canggih dan cepat.' },
                                { title: 'Tanpa Iklan', desc: 'Menjaga pengalaman pengguna tetap bersih, premium, dan profesional.' }
                            ].map((item, i) => (
                                <div key={i} className="flex items-start space-x-4">
                                    <div className="w-2 h-2 rounded-full bg-indigo-600 mt-2 shrink-0"></div>
                                    <div>
                                        <h3 className="font-bold text-gray-800 text-base">{item.title}</h3>
                                        <p className="text-sm text-gray-500 font-medium leading-relaxed">{item.desc}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-xl border border-amber-100">
                        <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest mb-2 flex items-center">
                            <Check size={12} className="mr-1" /> Note
                        </p>
                        <p className="text-sm text-amber-900/80 font-bold leading-relaxed italic">
                            "Berapapun yang Anda berikan, sangat berarti bagi kami. Terima kasih orang baik!"
                        </p>
                    </div>
                </div>

                <div className="space-y-6">
                    {/* Right Column: QRIS */}
                    <div className="bg-indigo-50/50 p-8 rounded-2xl border border-blue-100 text-center flex flex-col items-center justify-center">
                        <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-4">
                            <Smartphone className="text-indigo-600" size={32} />
                        </div>
                        <h3 className="text-lg font-black text-gray-900 mb-2">QRIS Terintegrasi UZNBT</h3>
                        <p className="text-xs text-gray-500 font-medium mb-6 leading-relaxed">Scan QR Code ini menggunakan semua aplikasi pembayaran berbasis QRIS (DANA, OVO, GoPay, BCA Mobile, dll).</p>

                        {/* QR Code */}
                        <div className="bg-white p-4 sm:p-6 rounded-2xl shadow-sm inline-block relative border border-gray-100 min-w-[200px] min-h-[200px] flex items-center justify-center">
                            <div className="relative">
                                <img src="/qris.png" alt="QRIS UZNBT" className="w-64 sm:w-80 h-64 sm:h-80 object-contain" />
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <div className="bg-white p-0.5 sm:p-1 rounded-xl shadow-lg flex items-center justify-center border-2 border-white min-w-[28px] min-h-[28px] sm:min-w-[36px] sm:min-h-[36px]">
                                        <div className="bg-gradient-to-br from-blue-600 to-blue-600 w-full h-full rounded-lg flex items-center justify-center p-1 sm:p-1.5">
                                            <Layers className="text-white w-3 h-3 sm:w-4 sm:h-4" strokeWidth={3} />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CoffeePage;
