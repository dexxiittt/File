import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { gasRequest } from '../services/sheetsService';
import { User, Shield, Lock, Database, LogOut, Check, AlertCircle, Globe, Activity, Zap, Eye, EyeOff } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import ConfirmModal from '../components/ConfirmModal';
import BottomSheet from '../components/BottomSheet';

export default function Settings() {
    const { user, logout, googleToken, updateGoogleToken, updateUser } = useAuth();
    const navigate = useNavigate();
    const [stats, setStats] = useState({ formCount: 0 });
    const [serviceEmail, setServiceEmail] = useState('');
    const [loading, setLoading] = useState(true);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [dbType] = useState('drive');

    // State untuk Modals Ganti Password & Username
    const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
    const [isUsernameModalOpen, setIsUsernameModalOpen] = useState(false);
    const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);

    // Fitur Ganti Username
    const [currentPasswordForUser, setCurrentPasswordForUser] = useState('');
    const [newUsername, setNewUsername] = useState('');
    const [isChangingUsername, setIsChangingUsername] = useState(false);

    // Fitur Ganti Password
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmNewPassword, setConfirmNewPassword] = useState('');
    const [isChangingPassword, setIsChangingPassword] = useState(false);

    // Visibility States
    const [showCurrentPasswordForUser, setShowCurrentPasswordForUser] = useState(false);
    const [showCurrentPassword, setShowCurrentPassword] = useState(false);
    const [showNewPassword, setShowNewPassword] = useState(false);
    const [showConfirmNewPassword, setShowConfirmNewPassword] = useState(false);

    // Fitur Notifikasi Admin Native
    const [adminNotifyEnabled, setAdminNotifyEnabled] = useState(localStorage.getItem('admin_notifications_enabled') === 'true');
    const [isNotifyPrePromptOpen, setIsNotifyPrePromptOpen] = useState(false);
    const [permissionStatus, setPermissionStatus] = useState(Notification.permission);

    const handleToggleAdminNotify = () => {
        if (!adminNotifyEnabled) {
            setIsNotifyPrePromptOpen(true);
        } else {
            setAdminNotifyEnabled(false);
            localStorage.setItem('admin_notifications_enabled', 'false');
        }
    };

    const confirmNotificationPermission = async () => {
        setIsNotifyPrePromptOpen(false);
        if (!('Notification' in window)) {
            alert("Browser Anda tidak mendukung notifikasi native.");
            return;
        }
        const permission = await Notification.requestPermission();
        setPermissionStatus(permission);
        if (permission === 'granted') {
            setAdminNotifyEnabled(true);
            localStorage.setItem('admin_notifications_enabled', 'true');
        }
    };

    const handleChangeUsername = async () => {
        const trimmed = newUsername.trim();
        if (!trimmed || !currentPasswordForUser) { alert("Semua kolom harus diisi!"); return; }
        if (trimmed === user?.username) { alert("Username tidak berubah."); return; }
        setIsChangingUsername(true);
        const res = await gasRequest('updateProfile', { username: user?.username, currentPassword: currentPasswordForUser, newUsername: trimmed });
        setIsChangingUsername(false);
        if (res.success) {
            alert("Username berhasil diperbarui!");
            updateUser({ username: res.newUsername });
            setNewUsername(''); setCurrentPasswordForUser(''); setIsUsernameModalOpen(false);
        } else { alert("Gagal merubah username: " + res.error); }
    };

    const handleChangePassword = async () => {
        if (!currentPassword || !newPassword || !confirmNewPassword) { alert("Semua kolom harus diisi!"); return; }
        if (newPassword !== confirmNewPassword) { alert("Konfirmasi kata sandi baru tidak cocok!"); return; }
        if (newPassword.length < 6) { alert("Kata sandi baru minimal 6 karakter."); return; }
        setIsChangingPassword(true);
        const res = await gasRequest('updateProfile', { username: user?.username, currentPassword: currentPassword, newPassword: newPassword });
        setIsChangingPassword(false);
        if (res.success) {
            alert("Kata sandi berhasil diperbarui!");
            setCurrentPassword(''); setNewPassword(''); setConfirmNewPassword(''); setIsPasswordModalOpen(false);
        } else { alert("Gagal merubah sandi: " + res.error); }
    };

    useEffect(() => {
        const fetchData = async () => {
            const cacheKey = `settings_cache_${user?.username}`;
            const cachedStr = localStorage.getItem(cacheKey);
            if (cachedStr) {
                try {
                    const cached = JSON.parse(cachedStr);
                    setStats({ formCount: cached.formCount || 0 });
                    setServiceEmail(cached.serviceEmail || '');
                    setLoading(false);
                } catch (e) { console.error("Settings cache corrupted"); }
            }
            const [formRes, infoRes] = await Promise.all([
                gasRequest('getCreatorForms', { username: user?.username }),
                gasRequest('getSystemInfo', { username: user?.username })
            ]);
            const newData = {
                formCount: (formRes && formRes.success) ? (formRes.forms?.length || 0) : 0,
                serviceEmail: (infoRes && infoRes.success) ? infoRes.serviceEmail : ''
            };
            if (JSON.stringify(newData) !== cachedStr) {
                if (formRes?.success) setStats({ formCount: newData.formCount });
                if (infoRes?.success) setServiceEmail(newData.serviceEmail);
                localStorage.setItem(cacheKey, JSON.stringify(newData));
            }
            setLoading(false);
        };
        if (user?.username) fetchData();
    }, [user]);

    const handleLogout = () => { logout(); navigate('/login'); };

    const handleDeleteAccount = async () => {
        setIsDeleteModalOpen(false); setLoading(true);
        const res = await gasRequest('deleteAccount', { username: user?.username });
        if (res.success) { logout(); navigate('/login'); }
        else { alert('Gagal menghapus akun: ' + res.error); setLoading(false); }
    };

    const connectGoogle = () => {
        const CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
        if (!window.google) { alert("Google Library belum dimuat. Silakan muat ulang halaman."); return; }
        const client = window.google.accounts.oauth2.initTokenClient({
            client_id: CLIENT_ID,
            scope: 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.file',
            callback: (response) => { if (response.access_token) updateGoogleToken(response.access_token); },
        });
        client.requestAccessToken();
    };

    const rotateGoogleToken = () => { updateGoogleToken(null); setTimeout(connectGoogle, 100); };

    return (
        <>
            <div className="max-w-4xl mx-auto space-y-8 pb-10 font-sans">
                {/* Header */}
                <div className="bg-white/60 lg:backdrop-blur-md p-6 sm:p-8 rounded-xl shadow-sm border border-gray-200/60">
                    <h1 className="text-3xl font-black text-gray-900 tracking-tight">Pengaturan Akun</h1>
                    <p className="text-sm font-medium text-gray-500 mt-2">Kelola identitas dan preferensi penyimpanan data Anda.</p>
                </div>

                {/* Grid Utama */}
                <div className="grid gap-6 md:grid-cols-2 items-start">
                    {/* Akun & Keamanan */}
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 space-y-6 animate-in fade-in duration-500">
                        <div>
                            <div className="flex items-center space-x-3 text-gray-900 font-bold border-b border-gray-50 pb-4 mb-4">
                                <Shield size={20} className="text-indigo-600" />
                                <span>Akun &amp; Keamanan</span>
                            </div>

                            <div className="flex gap-4 mb-2">
                                <div className="flex-1 p-3 bg-gray-50 rounded-xl border border-gray-100">
                                    <p className="text-[9px] uppercase tracking-widest font-black text-gray-400 mb-0.5">Username</p>
                                    <p className="font-bold text-gray-800 text-sm truncate">{user?.username || 'Memuat...'}</p>
                                </div>
                                <div className="flex-1 p-3 bg-gray-50 rounded-xl border border-gray-100 flex flex-col justify-center items-start">
                                    <p className="text-[9px] uppercase tracking-widest font-black text-gray-400 mb-0.5">Status</p>
                                    <div className="flex items-center gap-1.5">
                                        <p className={`font-bold text-sm truncate ${user?.isVerified ? 'text-emerald-600' : 'text-amber-600'}`}>
                                            {user?.isVerified ? 'Terverifikasi' : 'Peninjauan'}
                                        </p>
                                        {user?.isVerified && <Check size={14} className="text-emerald-500" />}
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-3">
                            <div onClick={() => setIsUsernameModalOpen(true)} className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between group cursor-pointer hover:bg-white hover:border-indigo-100 transition-all">
                                <div>
                                    <h4 className="text-xs font-black text-gray-800 uppercase tracking-tighter group-hover:text-indigo-600 transition-colors text-left">Ubah Username</h4>
                                    <p className="text-[9px] text-gray-400 text-left">Ganti identitas login Anda.</p>
                                </div>
                                <div className="bg-white p-1.5 rounded-lg border border-gray-100 text-gray-400 group-hover:text-indigo-600 group-hover:border-indigo-100 transition-all">
                                    <User size={14} />
                                </div>
                            </div>
                            <div onClick={() => setIsPasswordModalOpen(true)} className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between group cursor-pointer hover:bg-white hover:border-indigo-100 transition-all">
                                <div>
                                    <h4 className="text-xs font-black text-gray-800 uppercase tracking-tighter group-hover:text-indigo-600 transition-colors text-left">Ubah Kata Sandi</h4>
                                    <p className="text-[9px] text-gray-400 text-left">Perbarui kredensial keamanan.</p>
                                </div>
                                <div className="bg-white p-1.5 rounded-lg border border-gray-100 text-gray-400 group-hover:text-indigo-600 group-hover:border-indigo-100 transition-all">
                                    <Lock size={14} />
                                </div>
                            </div>
                            <div onClick={() => setIsLogoutModalOpen(true)} className="p-3 bg-gray-50 rounded-xl border border-gray-100 flex items-center justify-between group cursor-pointer hover:bg-rose-50 hover:border-rose-100 transition-all">
                                <div>
                                    <h4 className="text-xs font-black text-gray-800 group-hover:text-rose-600 transition-colors text-left uppercase tracking-tighter">Keluar Sesi</h4>
                                    <p className="text-[9px] text-gray-400 text-left">Hapus token akses lokal.</p>
                                </div>
                                <div className="bg-white p-1.5 rounded-lg border border-gray-100 text-gray-400 group-hover:text-rose-600 group-hover:border-rose-100 transition-all">
                                    <LogOut size={14} />
                                </div>
                            </div>

                            {user?.isAdmin && (
                                <div className="p-3 bg-indigo-50/20 rounded-xl border border-indigo-100/30 flex items-center justify-between group hover:bg-white hover:border-indigo-100 transition-all">
                                    <div>
                                        <h4 className="text-xs font-black text-indigo-900 uppercase tracking-tighter group-hover:text-indigo-600 transition-colors text-left font-sans">Notifikasi Push</h4>
                                        <p className="text-[9px] text-gray-400 text-left">Update registrasi baru.</p>
                                    </div>
                                    <button
                                        onClick={handleToggleAdminNotify}
                                        className={`w-10 h-5 rounded-full transition-colors relative flex-shrink-0 ${adminNotifyEnabled ? 'bg-indigo-600 shadow-sm shadow-indigo-100' : 'bg-gray-300'}`}
                                    >
                                        <div className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform shadow-sm ${adminNotifyEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Penyimpanan & Data */}
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 space-y-6 animate-in fade-in duration-500 delay-100">
                        <div className="flex items-center space-x-3 text-gray-900 font-bold border-b border-gray-50 pb-4">
                            <Database size={20} className="text-indigo-600" />
                            <span>Penyimpanan &amp; Data</span>
                        </div>
                        <div className="p-5 bg-gradient-to-br from-indigo-50/50 to-white rounded-2xl border border-indigo-100/50 shadow-sm">
                            <div className="flex justify-between items-center mb-4">
                                <div className="flex flex-col">
                                    <span className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Total Formulir</span>
                                    <div className="flex items-center gap-2">
                                        {(user?.isVerified || googleToken) ? (
                                            <span className="px-2 py-0.5 bg-indigo-600 text-white text-[9px] font-black rounded-md uppercase tracking-tighter flex items-center gap-1 shadow-sm shadow-indigo-100">
                                                <Zap size={10} /> Unlimited
                                            </span>
                                        ) : (
                                            <span className="text-[10px] text-gray-500 font-bold">Standard Plan</span>
                                        )}
                                    </div>
                                </div>
                                <div className="text-right">
                                    <span className="text-3xl font-black text-indigo-600 tabular-nums leading-none">
                                        {loading ? '...' : stats.formCount}
                                    </span>
                                    {!(user?.isVerified || googleToken) && (
                                        <span className="text-sm font-bold text-gray-300 ml-1">/ 10</span>
                                    )}
                                </div>
                            </div>
                            <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden relative border border-gray-50">
                                <div
                                    className={`h-full rounded-full transition-all duration-1000 ${(user?.isVerified || googleToken) ? 'bg-gradient-to-r from-indigo-500 via-purple-500 to-indigo-600 bg-[length:200%_auto] animate-[gradient_3s_ease_infinite] w-full' : 'bg-indigo-600'}`}
                                    style={{ width: (user?.isVerified || googleToken) ? '100%' : `${Math.min(100, (stats.formCount / 10) * 100)}%` }}
                                ></div>
                            </div>
                            <p className="text-[9px] text-gray-400 mt-3 font-medium flex items-center gap-1 leading-relaxed">
                                <Activity size={10} className="text-indigo-300" />
                                Data dikelola secara hibrida untuk performa maksimal.
                            </p>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-center">
                                <p className="text-[9px] uppercase font-black text-gray-400 mb-1">Database</p>
                                <p className="text-[10px] font-bold text-gray-700">GAS Cloud</p>
                            </div>
                            <div className="p-3 bg-gray-50 rounded-xl border border-gray-100 text-center">
                                <p className="text-[9px] uppercase font-black text-gray-400 mb-1">Koneksi API</p>
                                <p className="text-[10px] font-bold text-emerald-600">Terpantau</p>
                            </div>
                        </div>
                    </div>

                    {/* Metode Penyimpanan Data (Drive Only) */}
                    <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 space-y-6 md:col-span-2 animate-in fade-in duration-500 delay-200">
                        <div className="flex items-center justify-between border-b border-gray-50 pb-4">
                            <div className="flex items-center space-x-3 text-gray-900 font-bold">
                                <Database size={20} className="text-indigo-600" />
                                <span>Metode Penyimpanan Data</span>
                            </div>
                            <Link
                                to={`/docs#drive`}
                                className="text-[10px] font-black uppercase tracking-widest text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100 transition-all hover:scale-105 active:scale-95"
                            >
                                Panduan Google Drive
                            </Link>
                        </div>

                        <div className="p-5 rounded-2xl border transition-all animate-in fade-in duration-300 bg-emerald-50 border-emerald-100">
                            <div className="flex justify-between items-start mb-4">
                                <div>
                                    <h4 className={`text-sm font-black ${googleToken ? 'text-emerald-700' : 'text-gray-800'} mb-1`}>
                                        {googleToken ? 'Terhubung ke Google Drive' : 'Penyimpanan Google Drive'}
                                    </h4>
                                    <p className="text-[11px] text-gray-500 leading-relaxed max-w-[280px]">
                                        {googleToken ? 'Seluruh data formulir dan file tersimpan aman di Google Drive pribadi Anda.' : 'Aktifkan integrasi Google Drive untuk menyimpan data langsung ke Spreadsheet milik Anda.'}
                                    </p>
                                </div>
                                <div className={`p-2 rounded-xl border ${googleToken ? 'bg-white text-emerald-500 border-emerald-100' : 'bg-white text-gray-300 border-gray-100'}`}>
                                    <Globe size={18} />
                                </div>
                            </div>
                            {googleToken ? (
                                <button onClick={rotateGoogleToken} className="w-full py-2.5 bg-white border border-emerald-200 text-emerald-600 rounded-xl text-[10px] font-black uppercase tracking-wider hover:bg-emerald-50 transition-all mb-3 text-center">
                                    Putuskan / Ganti Akun Google
                                </button>
                            ) : (
                                <button onClick={connectGoogle} className="w-full py-2.5 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-wider hover:bg-emerald-700 transition-all shadow-md shadow-emerald-100 mb-0">
                                    Hubungkan Akun Google
                                </button>
                            )}
                            {googleToken && (
                                <div className="p-3 bg-white/50 border border-gray-100 rounded-xl text-[10px] text-gray-500 font-medium leading-tight animate-in slide-in-from-top-2">
                                    <div className="flex items-center gap-1.5 mb-1.5 text-gray-600 font-bold uppercase tracking-tighter">
                                        <Shield size={10} /> <span>PENTING</span>
                                    </div>
                                    Agar sistem bisa menulis respons ke Sheet Anda, pastikan Sheet tersebut dibagikan (Share) secara publik atau khusus ke sistem email:
                                    <code className="block mt-1 p-1.5 bg-white border border-gray-100 rounded text-indigo-600 break-all select-all font-mono font-bold">{serviceEmail || 'Memuat sistem email...'}</code>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Zona Bahaya */}
                <div className="bg-rose-50 rounded-2xl p-6 shadow-sm border border-rose-100 overflow-hidden relative">
                    <div className="absolute -top-4 -right-4 text-rose-100/30">
                        <AlertCircle size={120} strokeWidth={1} />
                    </div>
                    <div className="flex items-center space-x-3 text-rose-900 font-bold border-b border-rose-100 pb-4 mb-6">
                        <AlertCircle size={20} className="text-rose-600" />
                        <span>Zona Bahaya</span>
                    </div>
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-5 bg-white/80 backdrop-blur-sm rounded-2xl border border-rose-200 shadow-sm relative z-10">
                        <div className="text-center sm:text-left">
                            <h4 className="text-sm font-black text-rose-600 mb-1">Hapus Akun Selamanya</h4>
                            <p className="text-[11px] text-gray-500 leading-relaxed max-w-sm">Tindakan ini permanen. Seluruh data form dan respon akan hilang selamanya.</p>
                        </div>
                        <button onClick={() => setIsDeleteModalOpen(true)} disabled={loading} className="w-full sm:w-auto px-6 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black transition-all active:scale-95 disabled:opacity-50">
                            Hapus Akun
                        </button>
                    </div>
                </div>
            </div>

            <ConfirmModal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleDeleteAccount}
                title="Hapus Akun Selamanya?"
                message="PERINGATAN KERAS: Menghapus akun akan menghapus SELURUH formulir dan SELURUH data tanggapan Anda secara permanen. Tindakan ini tidak dapat dibatalkan."
                confirmText="Hapus Akun & Data"
                type="danger"
            />

            {/* Modal Ganti Username */}
            <BottomSheet isOpen={isUsernameModalOpen} onClose={() => setIsUsernameModalOpen(false)} title="Ubah Username">
                <p className="text-xs text-gray-500 mb-6 font-medium leading-relaxed">Silakan masukkan username baru dan kata sandi saat ini untuk konfirmasi.</p>
                <div className="space-y-4">
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-2">Username Baru</label>
                        <input type="text" placeholder="Contoh: Budi2" value={newUsername} onChange={e => setNewUsername(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-indigo-400 transition-all font-medium" />
                    </div>
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-2">Kata Sandi Saat Ini</label>
                        <div className="relative group">
                            <input type={showCurrentPasswordForUser ? "text" : "password"} placeholder="••••••••" value={currentPasswordForUser} onChange={e => setCurrentPasswordForUser(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 pr-12 text-sm outline-none focus:ring-2 focus:ring-indigo-400 transition-all font-medium" />
                            <button type="button" onClick={() => setShowCurrentPasswordForUser(!showCurrentPasswordForUser)} className="absolute inset-y-0 right-0 pr-4 flex items-center justify-center text-gray-400 hover:text-indigo-600 transition-colors focus:outline-none">
                                {showCurrentPasswordForUser ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>
                    </div>
                </div>
                <div className="flex gap-3 mt-8">
                    <button onClick={() => setIsUsernameModalOpen(false)} className="flex-1 px-4 py-3 bg-gray-100 text-gray-600 rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-gray-200 transition-all active:scale-95">Batal</button>
                    <button onClick={handleChangeUsername} disabled={isChangingUsername} className="flex-1 px-4 py-3 bg-indigo-600 text-white rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-md active:scale-95 disabled:opacity-50">{isChangingUsername ? 'Menyimpan...' : 'Simpan'}</button>
                </div>
            </BottomSheet>

            {/* Modal Ganti Password */}
            <BottomSheet isOpen={isPasswordModalOpen} onClose={() => setIsPasswordModalOpen(false)} title="Ubah Kata Sandi">
                <p className="text-xs text-gray-500 mb-6 font-medium leading-relaxed">Perbarui tingkat keamanan akun Anda.</p>
                <div className="space-y-4">
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-2">Kata Sandi Saat Ini</label>
                        <div className="relative group">
                            <input type={showCurrentPassword ? "text" : "password"} placeholder="••••••••" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 pr-12 text-sm outline-none focus:ring-2 focus:ring-indigo-400 transition-all font-medium" />
                            <button type="button" onClick={() => setShowCurrentPassword(!showCurrentPassword)} className="absolute inset-y-0 right-0 pr-4 flex items-center justify-center text-gray-400 hover:text-indigo-600 transition-colors focus:outline-none">
                                {showCurrentPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>
                    </div>
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-2">Kata Sandi Baru</label>
                        <div className="relative group">
                            <input type={showNewPassword ? "text" : "password"} placeholder="••••••••" value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 pr-12 text-sm outline-none focus:ring-2 focus:ring-indigo-400 transition-all font-medium" />
                            <button type="button" onClick={() => setShowNewPassword(!showNewPassword)} className="absolute inset-y-0 right-0 pr-4 flex items-center justify-center text-gray-400 hover:text-indigo-600 transition-colors focus:outline-none">
                                {showNewPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>
                    </div>
                    <div>
                        <label className="block text-[10px] font-black uppercase tracking-widest text-gray-500 mb-2">Konfirmasi Kata Sandi Baru</label>
                        <div className="relative group">
                            <input type={showConfirmNewPassword ? "text" : "password"} placeholder="••••••••" value={confirmNewPassword} onChange={e => setConfirmNewPassword(e.target.value)} className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 pr-12 text-sm outline-none focus:ring-2 focus:ring-indigo-400 transition-all font-medium" />
                            <button type="button" onClick={() => setShowConfirmNewPassword(!showConfirmNewPassword)} className="absolute inset-y-0 right-0 pr-4 flex items-center justify-center text-gray-400 hover:text-indigo-600 transition-colors focus:outline-none">
                                {showConfirmNewPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                            </button>
                        </div>
                    </div>
                </div>
                <div className="flex gap-3 mt-8">
                    <button onClick={() => setIsPasswordModalOpen(false)} className="flex-1 px-4 py-3 bg-gray-100 text-gray-600 rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-gray-200 transition-all active:scale-95">Batal</button>
                    <button onClick={handleChangePassword} disabled={isChangingPassword} className="flex-1 px-4 py-3 bg-rose-600 text-white rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all shadow-md active:scale-95 disabled:opacity-50">{isChangingPassword ? 'Menyimpan...' : 'Ubah'}</button>
                </div>
            </BottomSheet>

            {/* Modal Konfirmasi Logout */}
            <BottomSheet isOpen={isLogoutModalOpen} onClose={() => setIsLogoutModalOpen(false)} title="Konfirmasi Keluar">
                <p className="text-sm text-gray-500 mb-6 font-medium leading-relaxed">
                    Apakah Anda yakin ingin keluar dari sesi saat ini? Anda membutuhkan username dan kata sandi untuk masuk kembali.
                </p>
                <div className="flex gap-3 mt-4">
                    <button onClick={() => setIsLogoutModalOpen(false)} className="flex-1 px-4 py-3 bg-gray-100 text-gray-600 rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-gray-200 transition-all active:scale-95">Batal</button>
                    <button onClick={handleLogout} className="flex-1 px-4 py-3 bg-rose-600 text-white rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all shadow-md active:scale-95">Ya, Keluar</button>
                </div>
            </BottomSheet>
            {/* Modal Pre-Prompt Notifikasi */}
            <BottomSheet isOpen={isNotifyPrePromptOpen} onClose={() => setIsNotifyPrePromptOpen(false)} title="Aktifkan Notifikasi Admin?">
                <div className="flex flex-col items-center text-center py-4">
                    <div className="w-20 h-20 bg-indigo-50 rounded-full flex items-center justify-center mb-6">
                        <Activity size={40} className="text-indigo-600" />
                    </div>
                    <p className="text-sm text-gray-600 font-medium leading-relaxed mb-6">
                        Dapatkan pemberitahuan instan saat ada pendaftar baru yang menunggu persetujuan Anda, bahkan saat Anda tidak sedang membuka browser.
                    </p>
                    <div className="w-full space-y-3">
                        <button
                            onClick={confirmNotificationPermission}
                            className="w-full py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-indigo-700 transition-all shadow-lg active:scale-95"
                        >
                            Izinkan & Aktifkan
                        </button>
                        <button
                            onClick={() => setIsNotifyPrePromptOpen(false)}
                            className="w-full py-4 bg-gray-50 text-gray-400 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-100 transition-all active:scale-95"
                        >
                            Mungkin Nanti
                        </button>
                    </div>
                </div>
            </BottomSheet>
        </>
    );
}
