import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { gasRequest } from '../services/sheetsService';
import { ArrowLeft, Table2, Download, ExternalLink, Loader2 } from 'lucide-react';

export default function FormResponses() {
    const { formId } = useParams();
    const [responses, setResponses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [viewMode, setViewMode] = useState('table'); // 'table' or 'insights'

    const handleDownloadCSV = () => {
        if (responses.length === 0) return;
        const headers = Object.keys(responses[0]);
        const csvRows = [
            headers.join(','),
            ...responses.map(row =>
                headers.map(h => {
                    let cell = row[h] === null || row[h] === undefined ? '' : row[h];
                    cell = cell.toString().replace(/"/g, '""');
                    return `"${cell}"`;
                }).join(',')
            )
        ];
        const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `Respon_Form_${formId}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const calculateInsights = () => {
        if (responses.length === 0) return [];
        const headers = Object.keys(responses[0]).filter(h => h !== 'Timestamp' && h !== 'Respondent Username');
        const insights = headers.map(header => {
            const counts = {};
            let totalValid = 0;
            responses.forEach(row => {
                const val = row[header];
                if (val !== undefined && val !== null && val !== '') {
                    counts[val] = (counts[val] || 0) + 1;
                    totalValid++;
                }
            });

            // Hanya tampilkan sebagai grafik jika itu "Choice" (unik <= 15 atau total sedikit)
            const uniqueCount = Object.keys(counts).length;
            if (uniqueCount > 0 && uniqueCount <= 15) {
                return {
                    header,
                    total: totalValid,
                    options: Object.entries(counts)
                        .map(([label, count]) => ({ label, count, percent: (count / totalValid * 100).toFixed(1) }))
                        .sort((a, b) => b.count - a.count)
                };
            }
            return null;
        }).filter(Boolean);
        return insights;
    };

    useEffect(() => {
        const fetchResponses = async () => {
            const cacheKey = `responses_cache_${formId}`;
            const cachedStr = localStorage.getItem(cacheKey);
            let lastHash = null;

            // 1. Optimistic Load
            if (cachedStr) {
                try {
                    const cached = JSON.parse(cachedStr);
                    setResponses(cached.data || []);
                    lastHash = cached.hash;
                    setLoading(false);
                } catch (e) {
                    console.error("Cache corrupted");
                }
            }

            // 2. Background Fetch (Phase 10: Conditional Sync)
            const res = await gasRequest('getResponses', { formId, lastSyncHash: lastHash });
            if (res.success) {
                // 3. Update if data changed
                if (res.changed !== false) {
                    const newResponses = res.responses || [];
                    setResponses(newResponses);
                    localStorage.setItem(cacheKey, JSON.stringify({ data: newResponses, hash: res.hash }));
                }
            }
            setLoading(false);
        };
        fetchResponses();
    }, [formId]);

    if (loading) return (
        <div className="flex flex-col items-center justify-center py-40">
            <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mb-4" />
            <p className="text-gray-500 font-bold uppercase tracking-widest text-sm">Menarik Data Spreadsheet...</p>
        </div>
    );

    const headers = responses.length > 0 ? Object.keys(responses[0]) : [];

    return (
        <div className="space-y-6 max-w-[95vw] mx-auto font-sans">
            <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-6 mb-8 mt-2">
                <Link to="/" className="w-max p-3 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 bg-white rounded-2xl shadow-sm border border-gray-200 transition-all hover:-translate-x-1">
                    <ArrowLeft size={24} strokeWidth={2.5} />
                </Link>
                <div>
                    <h1 className="text-3xl font-black text-gray-900 tracking-tight">Koleksi Tanggapan</h1>
                    <div className="flex items-center gap-3">
                        <p className="text-sm font-semibold text-gray-500 mt-1 flex items-center bg-gray-100 w-max px-3 py-1 rounded-lg">
                            Total <span className="mx-1.5 px-2 py-0.5 bg-indigo-600 text-white rounded text-xs">{responses.length}</span> Entri
                        </p>
                        {responses.length > 0 && (
                            <div className="flex bg-gray-100 p-1 rounded-xl">
                                <button
                                    onClick={() => setViewMode('table')}
                                    className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'table' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                                >
                                    Tabel
                                </button>
                                <button
                                    onClick={() => setViewMode('insights')}
                                    className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${viewMode === 'insights' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                                >
                                    Grafik
                                </button>
                            </div>
                        )}
                        {responses.length > 0 && (
                            <button
                                onClick={handleDownloadCSV}
                                className="flex items-center space-x-2 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-black uppercase tracking-widest transition-all shadow-md shadow-emerald-100 active:scale-95 mt-1"
                            >
                                <Download size={14} strokeWidth={3} />
                                <span>Unduh CSV</span>
                            </button>
                        )}
                    </div>
                </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 overflow-hidden">
                {responses.length === 0 ? (
                    <div className="p-20 text-center text-gray-500 flex flex-col items-center bg-gray-50/50">
                        <div className="bg-white p-6 rounded-full shadow-inner border border-gray-100 mb-6">
                            <Table2 size={64} className="text-gray-300" strokeWidth={1.5} />
                        </div>
                        <h3 className="text-2xl font-bold text-gray-800 mb-2">Tabel Bersih</h3>
                        <p className="font-medium text-gray-500">Tampaknya belum ada yang merespon form ini. Bagikan tautan ke responden Anda!</p>
                    </div>
                ) : viewMode === 'table' ? (
                    <div className="overflow-x-auto max-h-[75vh] custom-scrollbar rounded-b-3xl">
                        <table className="w-full text-left text-gray-700 whitespace-nowrap">
                            <thead className="text-[11px] uppercase tracking-wider font-black text-gray-500 bg-gray-50/80 backdrop-blur-md sticky top-0 shadow-sm z-10 border-b border-gray-200">
                                <tr>
                                    {headers.map((h, i) => (
                                        <th key={i} className="px-6 py-5 whitespace-nowrap">{h}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {responses.map((row, i) => (
                                    <tr key={i} className="bg-white hover:bg-indigo-50/30 transition-colors group">
                                        {headers.map((h, j) => {
                                            const v = row[h];
                                            const isLink = typeof v === 'string' && v.startsWith('http');
                                            return (
                                                <td key={j} className="px-6 py-4 text-sm font-medium">
                                                    {isLink ? (
                                                        <a href={v} target="_blank" rel="noopener noreferrer" className="inline-flex items-center space-x-2 text-indigo-600 hover:text-indigo-800 font-bold bg-indigo-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors border border-blue-100">
                                                            <ExternalLink size={16} /> <span>Akses File</span>
                                                        </a>
                                                    ) : (
                                                        <span className="block max-w-sm truncate text-gray-800" title={v}>{v || '-'}</span>
                                                    )}
                                                </td>
                                            );
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div className="p-6 sm:p-10 bg-gray-50/30 space-y-8 max-h-[75vh] overflow-y-auto custom-scrollbar">
                        {calculateInsights().length === 0 ? (
                            <div className="py-20 text-center">
                                <p className="text-gray-400 font-bold uppercase tracking-widest text-sm">Tidak ada data pilihan ganda untuk divisualisasikan.</p>
                            </div>
                        ) : (
                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                                {calculateInsights().map((insight, idx) => (
                                    <div key={idx} className="bg-white p-6 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col hover:shadow-md transition-shadow">
                                        <h3 className="text-sm font-black text-gray-900 mb-6 leading-tight border-b border-gray-50 pb-4">{insight.header}</h3>
                                        <div className="space-y-5">
                                            {insight.options.map((opt, oIdx) => (
                                                <div key={oIdx} className="space-y-1.5">
                                                    <div className="flex justify-between text-[11px] font-bold uppercase tracking-wider text-gray-500 mb-1 px-1">
                                                        <span className="truncate max-w-[70%]">{opt.label}</span>
                                                        <span className="text-indigo-600">{opt.percent}% ({opt.count})</span>
                                                    </div>
                                                    <div className="w-full h-3 bg-gray-100 rounded-full overflow-hidden flex">
                                                        <div
                                                            className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-1000 ease-out"
                                                            style={{ width: `${opt.percent}%` }}
                                                        />
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="mt-6 pt-4 border-t border-gray-50 flex justify-between items-center text-[10px] font-black text-gray-400 uppercase tracking-widest px-1">
                                            <span>Basispas data</span>
                                            <span>{insight.total} Respon</span>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
