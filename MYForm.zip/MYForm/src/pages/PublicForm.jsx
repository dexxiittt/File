import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import PublicLayout from '../layouts/PublicLayout';
import { gasRequest, fileToBase64, getDeviceFingerprint } from '../services/sheetsService';
import { UploadCloud, CheckCircle, AlertCircle, Loader2, Zap, X, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const PATTERNS = [
    { label: 'None', value: 'none', className: '' },
    { label: 'Dots', value: 'dots', className: 'pattern-polkadot' },
    { label: 'Grid', value: 'grid', className: 'pattern-grid' },
    { label: 'Waves', value: 'waves', className: 'pattern-waves' },
    { label: 'Zigzag', value: 'zigzag', className: 'pattern-zigzag' }
];

export default function PublicForm() {
    const { customSlug } = useParams();
    const navigate = useNavigate();
    const { user } = useAuth();

    const [form, setForm] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const [responses, setResponses] = useState({});
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [alreadySubmittedLocal, setAlreadySubmittedLocal] = useState(false);
    const [quizResult, setQuizResult] = useState(null);
    const [currentPage, setCurrentPage] = useState(0);

    const fields = useMemo(() => {
        if (!form || !form.fields_schema_json) return [];
        try {
            return JSON.parse(form.fields_schema_json);
        } catch (e) {
            return [];
        }
    }, [form]);

    const pages = useMemo(() => {
        if (!fields || fields.length === 0) return [[]];
        const grouped = [[]];
        fields.forEach(field => {
            if (field.type === 'Page Break') {
                if (grouped[grouped.length - 1].length > 0) {
                    grouped.push([]);
                }
            } else {
                grouped[grouped.length - 1].push(field);
            }
        });
        return grouped.filter(p => p.length > 0);
    }, [fields]);

    const validateField = (field, value) => {
        if (!field.validation) return null;
        const { min, max, maxLength } = field.validation;

        if (field.type === 'Number' && value !== '') {
            const n = Number(value);
            if (min !== null && n < min) return `Nilai minimum adalah ${min}`;
            if (max !== null && n > max) return `Nilai maksimum adalah ${max}`;
        }

        if ((field.type === 'Short Text' || field.type === 'Paragraph') && value) {
            if (maxLength && value.length > maxLength) return `Maksimal ${maxLength} karakter (saat ini ${value.length})`;
        }

        return null;
    };

    const isFieldVisible = (field, allFields) => {
        if (!field.logic || !field.logic.fieldId) return true;

        const sourceField = allFields.find(f => f.id === field.logic.fieldId);
        if (!sourceField) return true;

        const sourceValue = responses[sourceField.label];
        const targetValue = field.logic.value;
        const operator = field.logic.operator || 'equals';

        let isMatch = false;
        const sVal = sourceValue?.toString() || '';
        const tVal = targetValue?.toString() || '';

        if (operator === 'equals') {
            isMatch = sVal === tVal;
        } else if (operator === 'not_equals') {
            isMatch = sVal !== tVal;
        } else if (operator === 'contains') {
            isMatch = sVal.toLowerCase().includes(tVal.toLowerCase());
        }

        if (!isMatch) return false;
        return isFieldVisible(sourceField, allFields);
    };

    useEffect(() => {
        const fetchForm = async () => {
            const res = await gasRequest('getFormBySlug', { customSlug });
            if (res.success && res.form) {
                setForm(res.form);
                if (res.form.limitOneResponse) {
                    if (localStorage.getItem(`myform_submitted_${res.form.formId}`)) {
                        setAlreadySubmittedLocal(true);
                    }
                }
            } else {
                setError('Formulir tidak ditemukan atau tautan salah.');
            }
            setLoading(false);
        };
        fetchForm();
    }, [customSlug]);

    const handleChange = (label, value, field) => {
        setResponses(prev => ({ ...prev, [label]: value }));
        if (field) {
            const error = validateField(field, value);
            setErrors(prev => ({ ...prev, [field.id]: error }));
        }
    };

    const handleFileChange = async (label, e, field) => {
        const file = e.target.files[0];
        if (file) {
            // Cek batasan custom kreator
            if (field.limitFileSize) {
                const maxNum = field.maxFileSize || 10;
                const unit = field.maxFileSizeUnit || 'MB';
                const multiplier = unit === 'MB' ? 1048576 : 1024;
                const maxBytes = maxNum * multiplier;

                if (file.size > maxBytes) {
                    setResponses(prev => ({ ...prev, [label]: '' })); // Set kosong agar ditangkap validator wajib
                    setErrors(prev => ({ ...prev, [field.id]: `Ukuran file melebihi batas maksimal (${maxNum} ${unit})` }));
                    e.target.value = null; // Reset input secara visual
                    return;
                }
            }

            try {
                const base64Data = await fileToBase64(file);
                // Langsung update state, lewati validateField bawaan karena itu bukan untuk file
                setResponses(prev => ({ ...prev, [label]: base64Data }));
                setErrors(prev => ({ ...prev, [field.id]: null }));
            } catch (err) {
                alert('Gagal membaca file.');
            }
        }
    };

    const handleCheckboxChange = (label, option, checked, field) => {
        const currentList = responses[label] || [];
        let newList;
        if (checked) newList = [...currentList, option];
        else newList = currentList.filter(o => o !== option);
        handleChange(label, newList, field);
    };

    const validateCurrentPage = () => {
        const currentPageFields = pages[currentPage] || [];
        let hasError = false;
        const newErrors = { ...errors };

        currentPageFields.forEach(field => {
            if (isFieldVisible(field, fields)) {
                const value = responses[field.label];
                // Check required
                if (field.required && (value === undefined || value === '' || (Array.isArray(value) && value.length === 0))) {
                    newErrors[field.id] = 'Kolom ini wajib diisi';
                    hasError = true;
                }
                // Check custom validation (Number, max length etc)
                const validationError = validateField(field, value);
                if (validationError) {
                    newErrors[field.id] = validationError;
                    hasError = true;
                }
            }
        });

        setErrors(newErrors);
        return !hasError;
    };

    const nextStep = () => {
        if (validateCurrentPage()) {
            setCurrentPage(prev => prev + 1);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            // Find the first error element and scroll to it
            const firstErrorId = Object.keys(errors).find(id => errors[id]);
            if (firstErrorId) {
                const el = document.getElementById(firstErrorId);
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
        }
    };

    const prevStep = () => {
        setCurrentPage(prev => Math.max(0, prev - 1));
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleSubmit = async (e) => {
        if (e) e.preventDefault();

        // Final full validation check
        if (!validateCurrentPage()) return;

        setSubmitting(true);

        // Jika form adalah hasil Impor Native (punya Action URL GForm)
        if (form.gformUrl && form.gformUrl.includes('formResponse')) {
            try {
                const params = new URLSearchParams();

                fields.forEach(field => {
                    const value = responses[field.label];
                    if (value !== undefined && value !== null && value !== '') {
                        if (Array.isArray(value)) {
                            value.forEach(v => params.append(field.id, v));
                        } else {
                            params.append(field.id, value);
                        }
                    }
                });

                await fetch(form.gformUrl, {
                    method: 'POST',
                    mode: 'no-cors',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: params.toString()
                });

                setSubmitting(false);
                setSubmitted(true);
                window.scrollTo({ top: 0, behavior: 'smooth' });
            } catch (err) {
                setSubmitting(false);
                alert('Terkendala koneksi: Gagal meneruskan ke Google Forms.');
            }
            return;
        }

        const payload = {
            formId: form.formId,
            responses,
            submitterUsername: user?.username || null,
            submitterToken: user?.token || null,
            fingerprint: getDeviceFingerprint()
        };

        const res = await gasRequest('submitResponse', payload);
        setSubmitting(false);

        if (res.success) {
            if (res.score !== null) {
                setQuizResult({ score: res.score, maxScore: res.maxScore });
            }
            if (form.limitOneResponse) {
                localStorage.setItem(`myform_submitted_${form.formId}`, 'true');
            }
            setSubmitted(true);
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            alert(res.error || 'Terjadi kesalahan sistem saat mengirim tanggapan.');
        }
    };

    if (loading) {
        return (
            <div className="h-screen w-screen flex flex-col items-center justify-center font-sans tracking-wider text-gray-400 bg-gray-50">
                <Loader2 size={48} className="animate-spin text-indigo-500 mb-4" />
                <p className="font-semibold uppercase text-sm">Menghubungkan Database...</p>
            </div>
        );
    }

    if (error) {
        return (
            <div className="h-screen w-screen flex items-center justify-center font-sans bg-gray-50">
                <div className="bg-white border border-rose-200 text-rose-600 p-10 rounded-2xl shadow-2xl flex flex-col items-center text-center max-w-md mx-4 animate-in zoom-in-95">
                    <AlertCircle size={64} className="mb-4 text-rose-400" />
                    <h2 className="text-2xl font-black mb-2 text-gray-900">Hilang Jejak</h2>
                    <p className="text-gray-500 font-medium leading-relaxed">{error}</p>
                </div>
            </div>
        );
    }

    return (
        <PublicLayout theme={form.theme} pattern={form.backgroundPattern}>
            {!form.isActive ? (
                <div className="bg-white/90 lg:backdrop-blur-xl p-12 rounded-2xl shadow-2xl border border-gray-100 text-center flex flex-col items-center">
                    <div className="bg-gray-100 p-4 rounded-full mb-6 text-gray-400">
                        <AlertCircle size={48} />
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 mb-3 tracking-tight">Formulir Tertutup</h2>
                    <p className="text-gray-600 font-medium leading-relaxed max-w-sm">Mohon maaf, <strong>{form.title}</strong> tidak lagi menerima tanggapan baru pada saat ini.</p>
                </div>
            ) : form.requireLogin && !user ? (
                <div className="bg-white/90 lg:backdrop-blur-xl p-12 rounded-2xl shadow-2xl border border-gray-100 text-center flex flex-col items-center animate-in zoom-in duration-500">
                    <div className="bg-rose-50 p-4 rounded-full mb-6 text-rose-500">
                        <Lock size={48} />
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 mb-3 tracking-tight">Wajib Login</h2>
                    <p className="text-gray-600 font-medium leading-relaxed max-w-sm mb-8">
                        Kreator menyetel formulir ini sebagai privat. Anda harus terdaftar dan memiliki akun untuk melanjutkan pengisian.
                    </p>
                    <button onClick={() => navigate('/login')} className="px-8 py-4 bg-gray-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-rose-600 transition-all active:scale-95 shadow-lg">
                        Login Sekarang
                    </button>
                    <p className="text-xs text-gray-400 mt-6 font-bold uppercase tracking-widest">
                        MYForm Secure Auth
                    </p>
                </div>
            ) : form.limitOneResponse && alreadySubmittedLocal && !user ? (
                <div className="bg-white/90 lg:backdrop-blur-xl p-12 rounded-2xl shadow-2xl border border-gray-100 text-center flex flex-col items-center animate-in zoom-in duration-500">
                    <div className="bg-indigo-50 p-4 rounded-full mb-6 text-indigo-500">
                        <CheckCircle size={48} />
                    </div>
                    <h2 className="text-3xl font-black text-gray-900 mb-3 tracking-tight">Kuesioner Selesai</h2>
                    <p className="text-gray-600 font-medium leading-relaxed max-w-sm mb-8">
                        Anda sudah pernah mengisi formulir ini sebelumnya. Formulir ini membatasi 1 tanggapan per responden.
                    </p>
                    <button onClick={() => window.location.reload()} className="px-8 py-3 bg-gray-100 text-gray-500 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-gray-200 transition-all">
                        Perbarui Halaman
                    </button>
                </div>
            ) : submitted ? (
                <div className="bg-white/90 lg:backdrop-blur-xl p-12 rounded-2xl shadow-2xl border border-gray-100 text-center flex flex-col items-center animate-in zoom-in duration-500">
                    {quizResult ? (
                        <div className="mb-8 relative">
                            <div className="w-48 h-48 rounded-full border-8 border-gray-100 flex flex-col items-center justify-center relative overflow-hidden bg-white shadow-inner">
                                <div className="absolute bottom-0 left-0 w-full bg-indigo-500 transition-all duration-1000" style={{ height: `${(quizResult.score / quizResult.maxScore) * 100}%`, opacity: 0.1 }}></div>
                                <span className="text-5xl font-black text-gray-900 leading-none">{quizResult.score}</span>
                                <div className="h-0.5 w-12 bg-gray-200 my-2"></div>
                                <span className="text-xl font-bold text-gray-400">{quizResult.maxScore}</span>
                            </div>
                            <div className="absolute -top-2 -right-2 bg-orange-500 text-white p-3 rounded-2xl shadow-lg border-4 border-white">
                                <Zap size={24} />
                            </div>
                        </div>
                    ) : (
                        <div className="bg-emerald-50 p-4 rounded-full mb-6">
                            <CheckCircle size={64} className="text-emerald-500" />
                        </div>
                    )}

                    <h2 className="text-3xl font-black text-gray-900 mb-3 tracking-tight">
                        {quizResult ? 'Hasil Kuis Anda' : 'Berhasil Terkirim'}
                    </h2>

                    <p className="text-gray-600 font-medium leading-relaxed max-w-sm mb-8">
                        {quizResult
                            ? `Selamat! Anda berhasil menyelesaikan kuis ini dengan skor ${quizResult.score} dari ${quizResult.maxScore} poin.`
                            : (form.confirmationMessage || 'Tanggapan Anda telah dicatat.')}
                    </p>

                    {quizResult && (
                        <button onClick={() => window.location.reload()} className="px-8 py-3 bg-gray-900 text-white rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-indigo-600 transition-all active:scale-95 shadow-lg">
                            Coba Lagi
                        </button>
                    )}
                </div>

            ) : form.gformUrl && (!form.fields_schema_json || form.fields_schema_json === '[]') ? (
                <div className="bg-white/90 lg:backdrop-blur-md w-full rounded-2xl shadow-2xl overflow-hidden border border-white/40 ring-1 ring-black/5" style={{ minHeight: '85vh' }}>
                    <iframe
                        src={form.gformUrl.includes('?') ? `${form.gformUrl}&embedded=true` : `${form.gformUrl}?embedded=true`}
                        width="100%"
                        height="100%"
                        className="border-none min-h-[85vh] w-full"
                        title={form.title}
                    >Sedang Merender...</iframe>
                </div>
            ) : (
                <div className="max-w-3xl mx-auto">
                    <div
                        className="bg-white rounded-[3rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] border border-gray-100 p-8 sm:p-16 relative overflow-hidden transition-all duration-700 hover:shadow-[0_48px_96px_-24px_rgba(0,0,0,0.15)]"
                    >
                        <div className="h-4 w-full bg-gradient-to-r from-indigo-600 via-indigo-600 to-purple-600"></div>
                        <div className={`p-10 sm:p-16 border-b border-gray-100 bg-white relative overflow-hidden text-center ${PATTERNS.find(p => p.value === form.backgroundPattern)?.className || ''}`}>
                            {/* Decorative circles */}
                            <div className="absolute top-[-100px] right-[-100px] w-64 h-64 bg-indigo-50/50 rounded-full blur-3xl -z-10"></div>
                            <div className="absolute bottom-[-100px] left-[-100px] w-64 h-64 bg-indigo-50/50 rounded-full blur-3xl -z-10"></div>

                            <h1 className="text-5xl font-black text-gray-900 mb-6 tracking-tight leading-[1.1]">{form.title}</h1>
                            {form.description && (
                                <p className="text-xl font-medium text-gray-500 whitespace-pre-line max-w-2xl mx-auto leading-relaxed italic">
                                    "{form.description}"
                                </p>
                            )}

                        </div>

                        {/* Progress Bar Sticky */}
                        <div className="sticky top-0 z-50 bg-white/80 lg:backdrop-blur-md border-b border-gray-100 shadow-sm overflow-hidden">
                            {(() => {
                                const visibleQuestions = fields.filter(f => f.type !== 'Section Header' && f.type !== 'Page Break' && isFieldVisible(f, fields));
                                if (visibleQuestions.length === 0) return null;

                                const answeredCount = visibleQuestions.filter(f => {
                                    const val = responses[f.label];
                                    if (Array.isArray(val)) return val.length > 0;
                                    return val !== undefined && val !== '';
                                }).length;

                                // If multi-page, show page progress too? Or just total field progress.
                                // Google Forms shows per-page progress (Page X of Y).
                                const progressPercent = Math.min(100, (answeredCount / visibleQuestions.length) * 100);

                                return (
                                    <div className="relative h-2 w-full bg-gray-100">
                                        <div
                                            className="absolute top-0 left-0 h-full bg-indigo-600 transition-all duration-700 ease-out rounded-r-full shadow-[0_0_10px_rgba(37,99,235,0.4)]"
                                            style={{ width: `${progressPercent}%` }}
                                        ></div>
                                        <div className="absolute top-3 right-4 flex items-center gap-2">
                                            {pages.length > 1 && (
                                                <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest bg-gray-100 px-2 py-0.5 rounded-full">
                                                    Halaman {currentPage + 1} dari {pages.length}
                                                </span>
                                            )}
                                            <div className="text-[10px] font-black text-indigo-700 uppercase tracking-widest bg-indigo-50 px-2 py-0.5 rounded-full border border-blue-100">
                                                Progres Total: {Math.round(progressPercent)}%
                                            </div>
                                        </div>
                                    </div>
                                );
                            })()}
                        </div>

                        <div className="p-8 sm:p-12 space-y-8 bg-gray-50/50">
                            {pages[currentPage]?.filter(field => isFieldVisible(field, fields)).map((field) => (
                                field.type === 'Section Header' ? (
                                    <div key={field.id} className="pt-10 pb-4 first:pt-4">
                                        <h2 className="text-3xl font-black text-gray-900 tracking-tight">{field.label}</h2>
                                        {field.helpText && <p className="text-gray-500 font-bold mt-2 text-lg leading-relaxed">{field.helpText}</p>}
                                        <div className="h-1.5 w-20 bg-indigo-600 rounded-full mt-4 shadow-sm shadow-blue-200"></div>
                                    </div>
                                ) : (
                                    <div id={field.id} key={field.id} className="bg-white p-8 sm:p-10 rounded-2xl border border-gray-100 shadow-[0_4px_20px_rgba(0,0,0,0.03)] focus-within:shadow-[0_20px_40px_rgba(37,99,235,0.08)] focus-within:border-blue-400 focus-within:ring-4 focus-within:ring-blue-100/50 transition-all duration-500 animate-in slide-in-from-bottom-8">
                                        <label className="block text-2xl font-black text-gray-900 mb-3 tracking-tight">
                                            {field.label} {field.required && <span className="text-red-500 ml-1 font-normal opacity-50">*</span>}
                                        </label>
                                        {field.helpText && <p className="text-base font-semibold text-gray-400 mb-6 italic">{field.helpText}</p>}

                                        <div className="mt-4">
                                            {field.type === 'Short Text' && (
                                                <input type="text" required={field.required} value={responses[field.label] || ''} onChange={e => handleChange(field.label, e.target.value, field)} className={`w-full border-b-2 outline-none py-2 bg-transparent text-lg font-medium transition-colors ${errors[field.id] ? 'border-rose-500 text-rose-900 focus:border-rose-600' : 'border-gray-200 focus:border-indigo-600 text-gray-800'}`} placeholder="Ketik jawaban singkat..." />
                                            )}
                                            {field.type === 'Paragraph' && (
                                                <textarea required={field.required} value={responses[field.label] || ''} onChange={e => handleChange(field.label, e.target.value, field)} rows="3" className={`w-full border-2 rounded-xl outline-none p-4 text-lg font-medium transition-colors resize-y ${errors[field.id] ? 'border-rose-300 bg-rose-50/30 text-rose-900 focus:border-rose-500 focus:ring-rose-100' : 'border-gray-200 focus:ring-4 focus:ring-blue-100/50 focus:border-indigo-500 text-gray-800'}`} placeholder="Uraikan jawaban Anda secara detail..."></textarea>
                                            )}
                                            {field.type === 'Email' && (
                                                <input type="email" required={field.required} value={responses[field.label] || ''} onChange={e => handleChange(field.label, e.target.value, field)} className={`w-full border-b-2 outline-none py-2 bg-transparent text-lg font-medium transition-colors ${errors[field.id] ? 'border-rose-500 text-rose-900' : 'border-gray-200 focus:border-indigo-600 text-gray-800'}`} placeholder="alamat@email.com" />
                                            )}
                                            {field.type === 'Number' && (
                                                <input type="number" required={field.required} value={responses[field.label] || ''} onChange={e => handleChange(field.label, e.target.value, field)} className={`w-full border-b-2 outline-none py-2 bg-transparent text-lg font-medium transition-colors ${errors[field.id] ? 'border-rose-500 text-rose-900' : 'border-gray-200 focus:border-indigo-600 text-gray-800'}`} placeholder="1234..." />
                                            )}
                                            {field.type === 'Multiple Choice' && (
                                                <div className="grid gap-3 pt-2">
                                                    {field.options?.map((opt, i) => {
                                                        const isSelected = responses[field.label] === opt;
                                                        return (
                                                            <label key={i} className={`flex items-center space-x-4 cursor-pointer group p-4 rounded-2xl border-2 transition-all duration-300 ${isSelected ? 'bg-indigo-50/50 border-blue-400 shadow-[0_8px_20px_rgba(37,99,235,0.08)] translate-x-1' : 'bg-gray-50/50 border-transparent hover:bg-gray-100/50 hover:border-gray-200'}`}>
                                                                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${isSelected ? 'bg-indigo-600 border-indigo-600 scale-110 shadow-sm' : 'bg-white border-gray-300'}`}>
                                                                    {isSelected && <div className="w-2.5 h-2.5 bg-white rounded-full animate-in zoom-in-50"></div>}
                                                                </div>
                                                                <input type="radio" name={field.id} value={opt} checked={isSelected} required={field.required} onChange={e => handleChange(field.label, e.target.value, field)} className="hidden" />
                                                                <span className={`text-lg font-bold transition-colors ${isSelected ? 'text-indigo-700' : 'text-gray-600'}`}>{opt}</span>
                                                            </label>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                            {field.type === 'Checkboxes' && (
                                                <div className="grid gap-3 pt-2">
                                                    {field.options?.map((opt, i) => {
                                                        const isChecked = (responses[field.label] || []).includes(opt);
                                                        return (
                                                            <label key={i} className={`flex items-center space-x-4 cursor-pointer group p-4 rounded-2xl border-2 transition-all duration-300 ${isChecked ? 'bg-indigo-50/50 border-blue-400 shadow-[0_8px_20px_rgba(37,99,235,0.08)] translate-x-1' : 'bg-gray-50/50 border-transparent hover:bg-gray-100/50 hover:border-gray-200'}`}>
                                                                <div className={`w-6 h-6 rounded-lg border-2 flex items-center justify-center transition-all ${isChecked ? 'bg-indigo-600 border-indigo-600 scale-110 shadow-sm' : 'bg-white border-gray-300'}`}>
                                                                    {isChecked && <svg className="w-4 h-4 text-white animate-in zoom-in-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="4" d="M5 13l4 4L19 7"></path></svg>}
                                                                </div>
                                                                <input type="checkbox" checked={isChecked} onChange={e => handleCheckboxChange(field.label, opt, e.target.checked, field)} className="hidden" />
                                                                <span className={`text-lg font-bold transition-colors ${isChecked ? 'text-indigo-700' : 'text-gray-600'}`}>{opt}</span>
                                                            </label>
                                                        );
                                                    })}
                                                </div>
                                            )}
                                            {field.type === 'Dropdown' && (
                                                <div className="relative group sm:max-w-md">
                                                    <select required={field.required} value={responses[field.label] || ''} onChange={e => handleChange(field.label, e.target.value, field)} className="w-full border-2 border-gray-100 rounded-2xl focus:ring-[6px] focus:ring-blue-100 focus:border-indigo-500 outline-none p-4 bg-gray-50/50 text-lg font-bold text-gray-800 transition-all appearance-none cursor-pointer group-hover:bg-white pr-12">
                                                        <option value="">Pilih Opsi...</option>
                                                        {field.options?.map((opt, i) => <option key={i} value={opt}>{opt}</option>)}
                                                    </select>
                                                    <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                                                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M19 9l-7 7-7-7"></path></svg>
                                                    </div>
                                                </div>
                                            )}
                                            {field.type === 'Date' && (
                                                <input type="date" required={field.required} value={responses[field.label] || ''} onChange={e => handleChange(field.label, e.target.value, field)} className="sm:max-w-md border-2 border-gray-100 rounded-2xl focus:ring-[6px] focus:ring-blue-100 focus:border-indigo-500 outline-none p-4 w-full bg-gray-50/50 text-lg font-bold text-gray-800 transition-all cursor-pointer hover:bg-white" />
                                            )}
                                            {field.type === 'Linear Scale' && (() => {
                                                const min = field.scaleMin ?? 1;
                                                const max = field.scaleMax ?? 5;
                                                const steps = Array.from({ length: max - min + 1 }, (_, i) => min + i);
                                                const selected = responses[field.label];
                                                return (
                                                    <div className="pt-2">
                                                        {(field.scaleLowLabel || field.scaleHighLabel) && (
                                                            <div className="flex justify-between text-sm font-semibold text-gray-500 mb-3 px-1">
                                                                <span>{field.scaleLowLabel || ''}</span>
                                                                <span>{field.scaleHighLabel || ''}</span>
                                                            </div>
                                                        )}
                                                        <div className="flex items-center gap-3 flex-wrap">
                                                            {steps.map(n => (
                                                                <button
                                                                    key={n}
                                                                    type="button"
                                                                    onClick={() => handleChange(field.label, n, field)}
                                                                    className={`w-14 h-14 rounded-2xl border-2 font-black text-xl transition-all duration-300 ${selected === n
                                                                        ? 'bg-indigo-600 border-indigo-600 text-white scale-110 shadow-[0_10px_25px_rgba(37,99,235,0.4)] rotate-3'
                                                                        : 'border-gray-100 bg-gray-50/50 text-gray-400 hover:border-blue-300 hover:text-indigo-600 hover:bg-white hover:-translate-y-1'
                                                                        }`}
                                                                >
                                                                    {n}
                                                                </button>
                                                            ))}
                                                        </div>
                                                        {field.required && (
                                                            <input type="text" required readOnly value={selected ?? ''} className="sr-only" />
                                                        )}
                                                    </div>
                                                );
                                            })()}
                                            {field.type === 'Time' && (
                                                <input type="time" required={field.required} value={responses[field.label] || ''} onChange={e => handleChange(field.label, e.target.value, field)} className="sm:max-w-md border-2 border-gray-100 rounded-2xl focus:ring-[6px] focus:ring-blue-100 focus:border-indigo-500 outline-none p-4 w-full bg-gray-50/50 text-lg font-bold text-gray-800 transition-all cursor-pointer hover:bg-white" />
                                            )}
                                            {field.type === 'File Upload' && (
                                                <div className="w-full mt-2">
                                                    {responses[field.label] && responses[field.label].fileName ? (
                                                        <div className="flex items-center justify-between p-4 bg-indigo-50 border-2 border-indigo-200 rounded-2xl animate-in fade-in zoom-in-95 group/file">
                                                            <div className="flex items-center gap-4 overflow-hidden">
                                                                <div className="p-3 bg-white rounded-xl text-indigo-600 shadow-[0_4px_10px_rgba(99,102,241,0.1)] shrink-0 group-hover/file:scale-105 transition-transform">
                                                                    <UploadCloud size={24} />
                                                                </div>
                                                                <div className="truncate">
                                                                    <p className="text-sm font-black text-gray-900 truncate mb-0.5">{responses[field.label].fileName}</p>
                                                                    <p className="text-[10px] font-black tracking-widest text-indigo-500 uppercase">File Siap Dikirim</p>
                                                                </div>
                                                            </div>
                                                            <button
                                                                type="button"
                                                                onClick={() => {
                                                                    setResponses(prev => ({ ...prev, [field.label]: '' }));
                                                                    setErrors(prev => ({ ...prev, [field.id]: null }));
                                                                }}
                                                                className="shrink-0 p-2.5 text-rose-400 hover:text-white hover:bg-rose-500 rounded-xl transition-all hover:shadow-lg shadow-rose-200"
                                                                title="Batal Unggah File Ini"
                                                            >
                                                                <X size={20} strokeWidth={2.5} />
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <label className={`flex flex-col items-center justify-center w-full h-40 border-2 border-dashed rounded-2xl cursor-pointer transition-all ${errors[field.id] ? 'border-rose-400 bg-rose-50/30' : 'border-gray-300 bg-gray-50/80 hover:bg-indigo-50 hover:border-blue-400'}`}>
                                                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                                                <UploadCloud size={40} className={`${errors[field.id] ? 'text-rose-400' : 'text-gray-400'} mb-3 group-hover:text-indigo-500 transition-all`} />
                                                                <p className="mb-2 text-base text-gray-600 font-medium"><span className={`font-bold ${errors[field.id] ? 'text-rose-600' : 'text-indigo-600'}`}>Jelajahi File</span> atau drag & drop</p>
                                                                <p className="text-sm font-semibold text-gray-400 px-4 bg-white rounded-lg py-1 border border-gray-200 shadow-sm max-w-[200px] truncate text-center">
                                                                    Drive Sinkronisasi Aktif
                                                                </p>
                                                            </div>
                                                            <input type="file" className="hidden" required={field.required && !responses[field.label]} onChange={(e) => handleFileChange(field.label, e, field)} />
                                                        </label>
                                                    )}
                                                </div>
                                            )}

                                            {/* Error Display */}
                                            {errors[field.id] && (
                                                <div className="mt-3 flex items-center gap-1.5 text-rose-500 font-bold text-xs animate-in slide-in-from-top-1 bg-rose-50/50 py-1.5 px-3 rounded-lg border border-rose-100 w-max">
                                                    <AlertCircle size={14} />
                                                    {errors[field.id]}
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                )
                            ))}

                            <div className="pt-10 flex flex-col sm:flex-row gap-4 items-center justify-between">
                                <div className="flex gap-4 w-full sm:w-auto">
                                    {currentPage > 0 && (
                                        <button
                                            type="button"
                                            onClick={prevStep}
                                            className="flex-1 sm:flex-none px-8 py-4 border-2 border-gray-200 text-gray-600 font-black rounded-2xl hover:bg-gray-100 transition-all flex items-center justify-center gap-2"
                                        >
                                            Kembali
                                        </button>
                                    )}

                                    {currentPage < pages.length - 1 ? (
                                        <button
                                            type="button"
                                            onClick={nextStep}
                                            className="flex-1 sm:flex-none px-12 py-4 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl shadow-lg hover:-translate-y-1 transition-all flex items-center justify-center gap-2"
                                        >
                                            Berikutnya
                                        </button>
                                    ) : (
                                        <button
                                            type="button"
                                            onClick={handleSubmit}
                                            disabled={submitting}
                                            className="flex-1 sm:w-auto px-12 py-5 bg-gradient-to-br from-gray-900 to-black hover:from-indigo-600 hover:to-indigo-700 text-white font-black rounded-2xl shadow-[0_20px_40px_rgba(0,0,0,0.2)] hover:shadow-[0_20px_40px_rgba(37,99,235,0.3)] hover:-translate-y-1.5 transition-all duration-500 disabled:opacity-50 disabled:transform-none flex items-center justify-center gap-4 group"
                                        >
                                            {submitting ? (
                                                <>
                                                    <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                                                    <span>Mentransfer...</span>
                                                </>
                                            ) : (
                                                <>
                                                    <span>Kirim Tanggapan</span>
                                                    <CheckCircle size={24} className="group-hover:scale-125 transition-transform" />
                                                </>
                                            )}
                                        </button>
                                    )}
                                </div>

                                {pages.length > 1 && (
                                    <p className="text-sm font-bold text-gray-400 bg-gray-100/50 px-4 py-2 rounded-full border border-gray-200">
                                        Langkah {currentPage + 1} dari {pages.length}
                                    </p>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )
            }

            <div className="mt-12 text-center pb-20">
                <p className="text-gray-400 font-bold text-sm tracking-widest uppercase flex items-center justify-center gap-3">
                    <span>Diberdayakan oleh</span>
                    <span className="bg-gradient-to-r from-indigo-600 to-indigo-600 bg-clip-text text-transparent font-black text-xl tracking-tighter">MYForm Architect</span>
                </p>
            </div>
        </PublicLayout >
    );
}
