import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import Pusher from 'pusher-js';
import {
    Users, CheckCircle, XCircle, Clock, Search,
    ShieldAlert, ArrowLeft, RefreshCw, Mail, User as UserIcon
} from 'lucide-react';
import ConfirmModal from '../components/ConfirmModal';

export default function AdminPanel() {
    const {
        user, getPendingUsers, approveUser, rejectUser,
        getAllUsers, updateUserStatus, adminDeleteUser
    } = useAuth();

    const [activeTab, setActiveTab] = useState('pending'); // 'pending' or 'users'

    // Cache-First Initialization
    const [pendingUsers, setPendingUsers] = useState(() => {
        try {
            const cached = JSON.parse(localStorage.getItem('admin_pending_cache') || '[]');
            return Array.isArray(cached) ? cached : [];
        } catch (e) { return []; }
    });
    const [allUsers, setAllUsers] = useState(() => {
        try {
            const cached = JSON.parse(localStorage.getItem('admin_users_cache') || '[]');
            return Array.isArray(cached) ? cached : [];
        } catch (e) { return []; }
    });

    const [loading, setLoading] = useState(() => {
        // Hanya tunjukkan loading utama jika cache benar-benar kosong
        return pendingUsers.length === 0 && allUsers.length === 0;
    });
    const [actionLoading, setActionLoading] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [isPolling, setIsPolling] = useState(false);
    const [modalConfig, setModalConfig] = useState({ isOpen: false });
    const navigate = useNavigate();

    // Store hashes for efficient sync
    const pendingHashRef = useRef(null);
    const allUsersHashRef = useRef(null);

    const fetchUsers = async (isSilent = false) => {
        if (!user?.isAdmin) return;

        // Jika sudah ada data di cache, jangan tampilkan spinner utama (Gunakan polling/silent sync)
        const hasCache = (activeTab === 'pending' ? (pendingUsers?.length > 0) : (allUsers?.length > 0));

        if (!isSilent && !hasCache) setLoading(true);
        else setIsPolling(true);

        try {
            if (activeTab === 'pending') {
                const res = await getPendingUsers(pendingHashRef.current);
                if (res && res.success) {
                    if (res.changed) {
                        const users = Array.isArray(res.users) ? res.users : [];
                        setPendingUsers(users);
                        pendingHashRef.current = res.hash;
                        localStorage.setItem('admin_pending_cache', JSON.stringify(users));
                    }
                }
            } else {
                const res = await getAllUsers(allUsersHashRef.current);
                if (res && res.success) {
                    if (res.changed) {
                        const users = Array.isArray(res.users) ? res.users : [];
                        setAllUsers(users);
                        allUsersHashRef.current = res.hash;
                        localStorage.setItem('admin_users_cache', JSON.stringify(users));
                    }
                }
            }
        } catch (e) {
            console.error("Fetch admin data failed:", e);
        }

        setLoading(false);
        setIsPolling(false);
    };

    useEffect(() => {
        if (!user || !user.isAdmin) {
            navigate('/');
            return;
        }

        // Selalu lakukan sync di latar belakang saat tab berubah atau mount
        fetchUsers(true);
    }, [user, navigate, activeTab]);

    // Pusher Real-time Integration
    useEffect(() => {
        if (!user?.isAdmin) return;

        let pusher = null;
        let channel = null;

        try {
            pusher = new Pusher(import.meta.env.VITE_PUSHER_KEY || '0302a51d1ad8ee4a2dc6', {
                cluster: import.meta.env.VITE_PUSHER_CLUSTER || 'ap1'
            });

            channel = pusher.subscribe('admin-channel');
            channel.bind('new-registration', () => {
                if (activeTab === 'pending') fetchUsers(true);
            });
        } catch (error) {
            console.error('[Pusher Debug] Initialization failed:', error);
        }

        return () => {
            if (channel) {
                channel.unbind_all();
                pusher.unsubscribe('admin-channel');
            }
            if (pusher) pusher.disconnect();
        };
    }, [user, activeTab]);

    // Listen for actions from Service Worker (Real-time Sync)
    useEffect(() => {
        const bc = new BroadcastChannel('admin_actions');
        bc.onmessage = (event) => {
            if (event.data.type === 'USER_PROCESSED') {
                const target = event.data.targetUsername;
                setPendingUsers(prev => {
                    const updated = prev.filter(u => String(u.username) !== String(target));
                    localStorage.setItem('admin_pending_cache', JSON.stringify(updated));
                    return updated;
                });
            }
        };
        return () => bc.close();
    }, []);

    const handleApprove = (targetUsername) => {
        setModalConfig({
            isOpen: true,
            title: 'Setujui Pendaftaran?',
            message: `Apakah Anda yakin ingin menyetujui pendaftaran dari @${targetUsername}?`,
            confirmText: 'Ya, Setujui',
            type: 'success',
            onConfirm: async () => {
                setModalConfig({ isOpen: false });

                // OPTIMISTIC UPDATE: Langsung hapus dari UI & Cache
                const updated = pendingUsers.filter(u => String(u.username) !== String(targetUsername));
                setPendingUsers(updated);
                localStorage.setItem('admin_pending_cache', JSON.stringify(updated));

                // Kirim perintah ke GAS di latar belakang
                try {
                    const res = await approveUser(targetUsername);
                    if (!res.success) {
                        // Jika gagal, tampilkan pesan tapi tidak perlu rollback (karena Admin bisa refresh)
                        console.error('GAS Approval failed:', res.error);
                        alert(`Gagal menyetujui @${targetUsername}: ${res.error}`);
                    }
                } catch (e) {
                    console.error('Network error during approval:', e);
                }
            }
        });
    };

    const handleReject = (targetUsername) => {
        setModalConfig({
            isOpen: true,
            title: 'Tolak Pendaftaran?',
            message: `Hapus antrean pendaftaran untuk @${targetUsername}?`,
            confirmText: 'Ya, Tolak',
            type: 'danger',
            onConfirm: async () => {
                setModalConfig({ isOpen: false });

                // OPTIMISTIC UPDATE: Langsung hapus dari UI & Cache
                const updated = pendingUsers.filter(u => String(u.username) !== String(targetUsername));
                setPendingUsers(updated);
                localStorage.setItem('admin_pending_cache', JSON.stringify(updated));

                // Kirim perintah ke GAS di latar belakang
                try {
                    const res = await rejectUser(targetUsername);
                    if (!res.success) {
                        console.error('GAS Rejection failed:', res.error);
                        alert(`Gagal menolak @${targetUsername}: ${res.error}`);
                    }
                } catch (e) {
                    console.error('Network error during rejection:', e);
                }
            }
        });
    };

    const handleToggleStatus = (targetUsername, field, currentValue) => {
        const label = field === 'isAdmin' ? 'Admin' : 'Pro';
        const newValue = !currentValue;

        setModalConfig({
            isOpen: true,
            title: `Ubah Status ${label}?`,
            message: `Apakah Anda yakin ingin mengubah status ${label} @${targetUsername} menjadi ${newValue ? 'AKTIF' : 'NON-AKTIF'}?`,
            confirmText: 'Ya, Ubah',
            type: 'warning',
            onConfirm: async () => {
                setModalConfig({ isOpen: false });

                // OPTIMISTIC UPDATE
                const updated = allUsers.map(u => String(u.username) === String(targetUsername) ? { ...u, [field]: newValue } : u);
                setAllUsers(updated);
                localStorage.setItem('admin_users_cache', JSON.stringify(updated));

                try {
                    const res = await updateUserStatus(targetUsername, field, newValue);
                    if (!res.success) {
                        alert(res.error || 'Gagal mengubah status.');
                    }
                } catch (e) {
                    console.error('Update status failed:', e);
                }
            }
        });
    };

    const handleDeleteUser = (targetUsername) => {
        setModalConfig({
            isOpen: true,
            title: 'Hapus User Permanen?',
            message: `Tindakan ini akan menghapus akun @${targetUsername} BESERTA SELURUH FORMULIR DAN DATA RESPONNYA secara permanen. Tindakan ini tidak dapat dibatalkan!`,
            confirmText: 'Ya, Hapus Semua',
            type: 'danger',
            onConfirm: async () => {
                setModalConfig({ isOpen: false });

                // OPTIMISTIC UPDATE
                const updated = allUsers.filter(u => String(u.username) !== String(targetUsername));
                setAllUsers(updated);
                localStorage.setItem('admin_users_cache', JSON.stringify(updated));

                try {
                    const res = await adminDeleteUser(targetUsername);
                    if (!res.success) {
                        alert(res.error || 'Gagal menghapus user.');
                    }
                } catch (e) {
                    console.error('Delete user failed:', e);
                }
            }
        });
    };

    const currentData = activeTab === 'pending' ? pendingUsers : allUsers;
    const filteredData = (Array.isArray(currentData) ? currentData : [])
        .filter(u => {
            if (!u || !u.username) return false;
            const uname = String(u.username).toLowerCase();
            return uname.includes(String(searchTerm).toLowerCase());
        });

    if (loading && filteredData.length === 0) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="flex flex-col items-center gap-4">
                    <RefreshCw className="animate-spin text-indigo-600" size={48} />
                    <p className="text-gray-500 font-bold animate-pulse text-sm">Memuat Data...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8 font-sans">
            <div className="max-w-6xl mx-auto">
                {/* Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => navigate('/')}
                            className="hidden lg:flex p-3 bg-white border border-gray-100 rounded-2xl text-gray-400 hover:text-gray-600 hover:border-gray-200 transition-all shadow-sm group"
                        >
                            <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
                        </button>
                        <div>
                            <h1 className="text-3xl font-black text-gray-900 tracking-tight flex items-center gap-3">
                                Admin Panel
                                {isPolling && <RefreshCw size={20} className="animate-spin text-indigo-400 ml-1" />}
                                <span className="bg-indigo-600 text-[10px] text-white px-2 py-0.5 rounded-full uppercase tracking-widest font-black">Control</span>
                            </h1>
                            <p className="text-sm text-gray-500 font-medium mt-1">Kelola pendaftaran dan status pengguna platform.</p>
                        </div>
                    </div>

                    <div className="flex flex-col sm:flex-row items-center gap-4">
                        <div className="relative group min-w-[300px]">
                            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-indigo-500 transition-colors" size={18} />
                            <input
                                type="text"
                                placeholder="Cari username..."
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                className="w-full pl-12 pr-4 py-3 bg-white border border-gray-100 rounded-2xl shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100 focus:border-blue-400 transition-all text-sm font-medium"
                            />
                        </div>
                    </div>
                </div>

                {/* Tab Switcher */}
                <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-gray-100 w-fit mb-8">
                    <button
                        onClick={() => setActiveTab('pending')}
                        className={`px-6 py-2 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${activeTab === 'pending' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        <Clock size={16} />
                        Antrean ({pendingUsers.length})
                    </button>
                    <button
                        onClick={() => setActiveTab('users')}
                        className={`px-6 py-2 rounded-xl text-sm font-black transition-all flex items-center gap-2 ${activeTab === 'users' ? 'bg-indigo-600 text-white shadow-lg' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        <Users size={16} />
                        Daftar User ({allUsers.length})
                    </button>
                </div>

                {/* Main Content */}
                <div className="bg-white rounded-[2rem] shadow-xl shadow-gray-200/50 border border-gray-100 overflow-hidden">
                    {filteredData.length === 0 ? (
                        <div className="py-24 flex flex-col items-center text-center px-6">
                            <div className="bg-gray-50 p-8 rounded-full mb-6">
                                {activeTab === 'pending' ? <Clock size={64} className="text-gray-300" /> : <Users size={64} className="text-gray-300" />}
                            </div>
                            <h3 className="text-xl font-black text-gray-900 mb-2">Tidak Ada Data</h3>
                            <p className="text-sm text-gray-500 font-medium max-w-xs">
                                {activeTab === 'pending' ? 'Tidak ada pendaftaran baru yang menunggu.' : 'Belum ada user yang terdaftar di sistem.'}
                            </p>
                        </div>
                    ) : (
                        <div className="overflow-x-auto">
                            <table className="w-full text-left border-collapse">
                                <thead>
                                    <tr className="bg-gray-50/50 border-b border-gray-100">
                                        <th className="px-8 py-5 text-xs font-black text-gray-400 uppercase tracking-widest">User</th>
                                        {activeTab === 'pending' ? (
                                            <th className="px-8 py-5 text-xs font-black text-gray-400 uppercase tracking-widest text-right">Aksi Persetujuan</th>
                                        ) : (
                                            <>
                                                <th className="px-8 py-5 text-xs font-black text-gray-400 uppercase tracking-widest">Status</th>
                                                <th className="px-8 py-5 text-xs font-black text-gray-400 uppercase tracking-widest">Storage</th>
                                                <th className="px-8 py-5 text-xs font-black text-gray-400 uppercase tracking-widest text-right">Kontrol Akses</th>
                                            </>
                                        )}
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-50">
                                    {filteredData.map((u) => (
                                        <tr key={u.username} className="hover:bg-indigo-50/10 transition-colors group">
                                            <td className="px-8 py-6">
                                                <div className="flex items-center gap-4">
                                                    <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 p-3 rounded-2xl shadow-lg shadow-blue-100">
                                                        <UserIcon className="text-white" size={18} />
                                                    </div>
                                                    <div>
                                                        <div className="font-black text-gray-900 text-lg">@{u.username}</div>
                                                        {activeTab === 'pending' && <div className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">Mendaftar: {new Date(u.createdAt).toLocaleDateString()}</div>}
                                                    </div>
                                                </div>
                                            </td>

                                            {activeTab === 'pending' ? (
                                                <td className="px-8 py-6">
                                                    <div className="flex items-center justify-end gap-3">
                                                        <button
                                                            disabled={actionLoading === u.username}
                                                            onClick={() => handleReject(u.username)}
                                                            className="px-6 py-2.5 rounded-2xl border border-red-100 text-red-600 font-bold text-xs hover:bg-red-50 hover:border-red-200 transition-all flex items-center gap-2"
                                                        >
                                                            {actionLoading === u.username ? <RefreshCw size={14} className="animate-spin" /> : <XCircle size={16} />}
                                                            Tolak
                                                        </button>
                                                        <button
                                                            disabled={actionLoading === u.username}
                                                            onClick={() => handleApprove(u.username)}
                                                            className="px-6 py-2.5 bg-emerald-600 text-white font-bold text-xs rounded-2xl shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all flex items-center gap-2"
                                                        >
                                                            {actionLoading === u.username ? <RefreshCw size={14} className="animate-spin" /> : <CheckCircle size={16} />}
                                                            Setujui
                                                        </button>
                                                    </div>
                                                </td>
                                            ) : (
                                                <>
                                                    <td className="px-8 py-6">
                                                        <div className="flex flex-wrap gap-2">
                                                            {u.isAdmin ? (
                                                                <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Admin</span>
                                                            ) : (
                                                                <span className="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">User</span>
                                                            )}
                                                            {u.isVerified ? (
                                                                <span className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">PRO / AI</span>
                                                            ) : (
                                                                <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">Basic</span>
                                                            )}
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-6">
                                                        <div className="text-xs font-bold text-gray-600">{(u.storageUsed / 1024 / 1024).toFixed(2)} MB</div>
                                                        <div className="w-24 h-1 bg-gray-100 rounded-full mt-1.5 overflow-hidden">
                                                            <div
                                                                className="h-full bg-indigo-500"
                                                                style={{ width: `${Math.min((u.storageUsed / 104857600) * 100, 100)}%` }}
                                                            />
                                                        </div>
                                                    </td>
                                                    <td className="px-8 py-6">
                                                        <div className="flex items-center justify-end gap-2">
                                                            <button
                                                                onClick={() => handleToggleStatus(u.username, 'isVerified', u.isVerified)}
                                                                className={`p-2 rounded-xl transition-all shadow-sm ${u.isVerified ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-white text-gray-300 border border-gray-50'}`}
                                                                title="Toggle Pro Status"
                                                            >
                                                                <CheckCircle size={18} />
                                                            </button>
                                                            <button
                                                                onClick={() => handleToggleStatus(u.username, 'isAdmin', u.isAdmin)}
                                                                className={`p-2 rounded-xl transition-all shadow-sm ${u.isAdmin ? 'bg-indigo-50 text-indigo-600 border border-indigo-100' : 'bg-white text-gray-300 border border-gray-50'}`}
                                                                title="Toggle Admin Status"
                                                            >
                                                                <ShieldAlert size={18} />
                                                            </button>
                                                            <button
                                                                onClick={() => handleDeleteUser(u.username)}
                                                                className="p-2 bg-red-50 text-red-500 border border-red-100 rounded-xl hover:bg-red-100 transition-all shadow-sm ml-2"
                                                                title="Hapus Akun Permanen"
                                                            >
                                                                <XCircle size={18} />
                                                            </button>
                                                        </div>
                                                    </td>
                                                </>
                                            )}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>

                {/* Footer Tip */}
                <div className="mt-8 p-6 bg-indigo-50/50 rounded-3xl border border-blue-100/50 flex items-start gap-4">
                    <ShieldAlert className="text-indigo-600 shrink-0" size={20} />
                    <div>
                        <h4 className="text-sm font-black text-blue-900 mb-1">Keamanan Administrator</h4>
                        <p className="text-xs text-indigo-800/70 font-medium leading-relaxed">
                            {activeTab === 'pending'
                                ? "Pastikan identitas pendaftar valid sebelum menyetujui akses ke platform builder."
                                : "Berikan status PRO hanya kepada user terpercaya. Mengaktifkan status Admin akan memberikan akses penuh ke panel kontrol ini."
                            }
                        </p>
                    </div>
                </div>
            </div>

            <ConfirmModal
                isOpen={modalConfig.isOpen}
                onClose={() => setModalConfig({ isOpen: false })}
                onConfirm={modalConfig.onConfirm}
                title={modalConfig.title}
                message={modalConfig.message}
                confirmText={modalConfig.confirmText}
                type={modalConfig.type}
            />
        </div>
    );
}
