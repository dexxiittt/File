import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Sparkles, Link as LinkIcon, ShieldCheck, Zap, Code, Copy, Check, Pencil, Layers, Coffee, Database, Download, ExternalLink, Globe } from 'lucide-react';

export default function Documentation() {
    const [copied, setCopied] = useState(false);
    const [exampleView, setExampleView] = useState('json'); // 'json' | 'preview'
    const [previewPage, setPreviewPage] = useState(2); // 1 | 2 | 3

    useEffect(() => {
        if (window.location.hash) {
            const el = document.querySelector(window.location.hash);
            if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
        }
    }, []);

    const AI_PROMPT = `Saya menggunakan platform form builder yang menerima format JSON berikut:
{
  "title": "string — Judul formulir",
  "description": "string — Deskripsi tambahan",
  "theme": "blue | purple | green | rose | orange | dark",
  "backgroundPattern": "none | grid | polkadot | waves | zigzag",
  "successMessage": "string — Pesan setelah submit",
  "fields": [
    {
      "id": "string — ID unik (misal: f_nama)",
      "type": "Short Text | Paragraph | Email | Number | Multiple Choice | Checkboxes | Dropdown | Linear Scale | Section Header | Date | Time | File Upload | Page Break",
      "label": "string — Pertanyaan",
      "required": boolean — Wajib diisi?,
      "helpText": "string — Petunjuk kecil (opsional)",
      "options": ["string[] — Daftar opsi untuk Choice/Check/Drop"],
      "scaleMin": number — Default 1,
      "scaleMax": number — Default 5,
      "validation": { 
        "maxLength": number — Maks karater,
        "min": number — Angka minimum,
        "max": number — Angka maksimum 
      },
      "logic": { 
        "fieldId": "string — ID pertanyaan asal", 
        "operator": "equals | not_equals | contains", 
        "value": "string — Jawaban pemicu" 
      }
    }
  ]
}

Tolong buatkan JSON formulir untuk: [DESKRIPSIKAN KEBUTUHAN FORM ANDA DI SINI]

Pastikan output adalah JSON valid murni tanpa markdown atau penjelasan tambahan.`;

    const handleCopy = () => {
        navigator.clipboard.writeText(AI_PROMPT);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    return (
        <div className="max-w-4xl mx-auto pb-16 font-sans">
            <div className="bg-white/60 backdrop-blur-md p-8 sm:p-10 rounded-2xl shadow-sm border border-gray-200/60 mb-8">
                <div className="flex items-center space-x-4 mb-4">
                    <div className="bg-indigo-600 text-white p-3 rounded-2xl shadow-lg shadow-blue-200">
                        <BookOpen size={32} strokeWidth={2.5} />
                    </div>
                    <div>
                        <h1 className="text-3xl font-black text-gray-900 tracking-tight">Dokumentasi Panduan</h1>
                        <p className="text-sm font-medium text-gray-500 mt-1">Pelajari cara memaksimalkan MYForm Web Builder dengan fitur AI, Multi-Page, dan Integrasi Hybrid.</p>
                    </div>
                </div>
            </div>

            <div className="space-y-6">
                {/* Bagian 1: Pengenalan */}
                <section className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-3 text-indigo-600 mb-4">
                        <Zap size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">1. Konsep Dasar</h2>
                    </div>
                    <p className="text-gray-600 font-medium leading-relaxed mb-4">
                        MYForm adalah pembuat formulir modern bersenjata <strong>Kecerdasan Buatan (AI)</strong>.
                        Platform ini dirancang untuk kecepatan tinggi dan fleksibilitas tanpa batas dalam merancang formulir multi-halaman yang cantik.
                    </p>
                    <div className="grid sm:grid-cols-2 gap-4">
                        <div className="bg-indigo-50/50 p-5 rounded-2xl border border-blue-100 text-sm font-medium text-indigo-800">
                            <strong>AI Powered:</strong> Buat skema form kompleks hanya dengan satu kalimat perintah.
                        </div>
                        <div className="bg-indigo-50/50 p-5 rounded-2xl border border-indigo-100 text-sm font-medium text-indigo-800">
                            <strong>Hybrid Mode:</strong> Sinkronkan langsung dengan Google Forms untuk keamanan database maksimal.
                        </div>
                    </div>
                </section>

                {/* Bagian 2: Multi-Page & Editing */}
                <section className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-3 text-amber-600 mb-4">
                        <Layers size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">2. Dasar Multi-Halaman & Editing</h2>
                    </div>

                    <div className="space-y-6">
                        <div className="grid sm:grid-cols-2 gap-6">
                            <div>
                                <h3 className="text-lg font-bold text-gray-800 mb-2 flex items-center gap-2">
                                    <span className="bg-amber-100 text-amber-600 p-1 rounded-md"><Pencil size={16} /></span>
                                    Edit & Kelola
                                </h3>
                                <p className="text-gray-600 font-medium text-sm leading-relaxed">
                                    Klik tombol <strong className="text-gray-900 font-bold">Edit</strong> di Dashboard untuk memuat skema. Anda bisa mengubah <strong className="text-gray-900 font-bold">Custom Slug</strong> (URL unik) dan mematikan form sementara via toggle <strong className="text-gray-900 font-bold">Tanggapan Terbuka</strong>.
                                </p>
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-gray-800 mb-2 flex items-center gap-2">
                                    <span className="bg-blue-100 text-indigo-600 p-1 rounded-md"><Check size={16} /></span>
                                    Pesan Konfirmasi
                                </h3>
                                <p className="text-gray-600 font-medium text-sm leading-relaxed">
                                    Atur pesan terimakasih kustom yang muncul setelah responden menekan tombol kirim. Gunakan kalimat yang personal dan informatif.
                                </p>
                            </div>
                        </div>

                        <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200">
                            <h3 className="font-bold text-gray-800 mb-3 ml-1">Sistem Page Break (Pagination)</h3>
                            <p className="text-gray-600 font-medium text-sm leading-relaxed mb-4">
                                Bagilah formulir panjang menjadi beberapa tahap untuk meningkatkan kenyamanan responden:
                            </p>
                            <ul className="grid sm:grid-cols-3 gap-4">
                                <li className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                                    <div className="bg-blue-100 text-indigo-600 font-bold w-6 h-6 rounded-full flex items-center justify-center mb-2 text-xs">1</div>
                                    <p className="text-xs font-bold text-gray-700 leading-snug">Tambahkan kolom tipe "Page Break" di posisi pemisah.</p>
                                </li>
                                <li className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                                    <div className="bg-blue-100 text-indigo-600 font-bold w-6 h-6 rounded-full flex items-center justify-center mb-2 text-xs">2</div>
                                    <p className="text-xs font-bold text-gray-700 leading-snug">Responden melihat tombol linear navigasi otomatis.</p>
                                </li>
                                <li className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                                    <div className="bg-blue-100 text-indigo-600 font-bold w-6 h-6 rounded-full flex items-center justify-center mb-2 text-xs">3</div>
                                    <p className="text-xs font-bold text-gray-700 leading-snug">Validasi input berjalan per-halaman secara *real-time*.</p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>

                {/* Bagian 3: Tipe Pertanyaan */}
                <section className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-3 text-indigo-600 mb-4">
                        <Layers size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">3. Tipe Pertanyaan & Elemen Form</h2>
                    </div>
                    <p className="text-gray-600 font-medium leading-relaxed mb-6">
                        MYForm menyediakan banyak tipe pertanyaan dan elemen layout yang siap pakai untuk memenuhi berbagai kebutuhan pengumpulan data:
                    </p>

                    <div className="grid sm:grid-cols-2 gap-4">
                        <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 hover:border-blue-200 transition-colors">
                            <h4 className="font-bold text-gray-800 text-sm mb-1 flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-indigo-500"></div>Teks Singkat & Paragraf</h4>
                            <p className="text-xs text-gray-600 font-medium leading-relaxed"><strong>Short Text:</strong> Jawaban pendek 1 baris (contoh: Nama, Asal).<br /><strong>Paragraph:</strong> Jawaban panjang esai (contoh: Alasan, Alamat lengkap).</p>
                        </div>
                        <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 hover:border-indigo-200 transition-colors">
                            <h4 className="font-bold text-gray-800 text-sm mb-1 flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-indigo-500"></div>Pilihan (Multiple/Single)</h4>
                            <p className="text-xs text-gray-600 font-medium leading-relaxed"><strong>Multiple Choice:</strong> Pilih satu opsi yang paling tepat.<br /><strong>Checkboxes:</strong> Pilih lebih dari satu opsi sekaligus.<br /><strong>Dropdown:</strong> Pilih satu opsi dalam bentuk menu lipat yang ringkas.</p>
                        </div>
                        <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 hover:border-purple-200 transition-colors">
                            <h4 className="font-bold text-gray-800 text-sm mb-1 flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-purple-500"></div>Data Spesifik</h4>
                            <p className="text-xs text-gray-600 font-medium leading-relaxed"><strong>Email:</strong> Memvalidasi format alamat email otomatis.<br /><strong>Number:</strong> Hanya menerima input angka.<br /><strong>Date & Time:</strong> Pemilih tanggal / kalender dan pemilih waktu harian.</p>
                        </div>
                        <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 hover:border-rose-200 transition-colors">
                            <h4 className="font-bold text-gray-800 text-sm mb-1 flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-rose-500"></div>Skala & Unggah</h4>
                            <p className="text-xs text-gray-600 font-medium leading-relaxed"><strong>Linear Scale:</strong> Memberikan skala nilai batas 1-N (cocok untuk survei kepuasan).<br /><strong>File Upload:</strong> Responden mengupload gambar/dokumen langsung aman ke Google Drive Anda.</p>
                        </div>
                        <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 sm:col-span-2 hover:border-emerald-200 transition-colors">
                            <h4 className="font-bold text-gray-800 text-sm mb-1 flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500"></div>Elemen Tata Letak</h4>
                            <p className="text-xs text-gray-600 font-medium leading-relaxed"><strong>Section Header:</strong> Membuat sub-judul yang menonjol untuk memisahkan konteks area formulir.<br /><strong>Page Break:</strong> Memotong form menjadi beberapa halaman, mencegah terjadinya beban / pusing informasi (Information Overload) pada sisi responden.</p>
                        </div>
                    </div>
                </section>

                {/* Bagian 4: Impor GForm Hybrid */}
                <section id="hybrid" className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 scroll-mt-8">
                    <div className="flex items-center space-x-3 text-green-600 mb-4">
                        <LinkIcon size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">4. Mode Sinkronisasi GForm (Hybrid)</h2>
                    </div>
                    <p className="text-gray-600 font-medium leading-relaxed mb-4">
                        Sinkronkan <strong>Google Formulir</strong> Anda menjadi Web Kustom dengan dua mode cerdas:
                    </p>
                    <div className="space-y-4">
                        <div className="bg-gray-50 border border-gray-200 p-5 rounded-2xl">
                            <h3 className="font-bold text-gray-800 mb-1">A. Mode Native (Custom Penuh)</h3>
                            <p className="text-xs text-gray-500 font-bold uppercase tracking-widest mb-2">Terbaik untuk: Teks, Pilihan Ganda, Dropdown</p>
                            <p className="text-sm text-gray-600 font-medium leading-relaxed">
                                Seluruh pertanyaan diekstrak ke sistem MYForm. Anda bebas mengganti tema dan pola. Data submit akan tetap masuk ke Google Forms orisinil Anda.
                            </p>
                        </div>
                        <div className="bg-emerald-50 border border-emerald-100 p-5 rounded-2xl">
                            <h3 className="font-bold text-emerald-900 mb-1">B. Mode Embed (Iframe Murni)</h3>
                            <p className="text-xs text-emerald-600 font-bold uppercase tracking-widest mb-2">Terbaik untuk: Form dengan Upload File</p>
                            <p className="text-sm text-emerald-800 font-medium leading-relaxed flex items-start gap-2">
                                <ShieldCheck size={18} className="shrink-0 text-emerald-500 mt-0.5" />
                                Aktif otomatis jika form memiliki isian "Upload File". Hal ini demi menjaga keamanan autentikasi Google dan fungsionalitas browser saat mengunggah dokumen.
                            </p>
                        </div>
                    </div>
                </section>

                {/* Bagian 5: Koneksi Google Drive & Sheets */}
                <section id="drive" className="bg-gradient-to-br from-emerald-50 to-white p-8 rounded-2xl shadow-sm border border-emerald-100 scroll-mt-8">
                    <div className="flex items-center space-x-3 text-emerald-600 mb-4">
                        <Globe size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">5. Koneksi Personal Google Drive & Sheets</h2>
                    </div>
                    <p className="text-gray-600 font-medium leading-relaxed mb-6">
                        Metode ini memungkinkan Anda untuk menyimpan data secara mandiri tanpa melalui database MYForm. Seluruh respon dan file yang diunggah akan masuk langsung ke akun Google Drive dan Spreadsheet Anda sendiri.
                    </p>
                    <div className="space-y-4">
                        <div className="bg-white p-5 rounded-2xl border border-emerald-100 shadow-sm flex items-start gap-4">
                            <div className="bg-emerald-100 p-2 rounded-xl text-emerald-600 shrink-0"><Check size={20} /></div>
                            <div>
                                <h4 className="text-sm font-bold text-emerald-900 mb-1">Langkah 1: Hubungkan Akun</h4>
                                <p className="text-xs text-emerald-800 leading-relaxed font-medium">Buka menu <strong>Setelan</strong>, pilih tab <strong>Google Drive</strong>, lalu klik tombol <strong>Hubungkan Akun Google</strong>.</p>
                            </div>
                        </div>
                        <div className="bg-indigo-50 p-5 rounded-2xl border border-indigo-100 shadow-sm flex items-start gap-4">
                            <div className="bg-indigo-100 p-2 rounded-xl text-indigo-600 shrink-0"><ShieldCheck size={20} /></div>
                            <div>
                                <h4 className="text-sm font-bold text-indigo-900 mb-1">Langkah 2: Berikan Akses (Editor)</h4>
                                <p className="text-xs text-indigo-800 leading-relaxed font-medium">
                                    Setelah terhubung, sistem akan memberikan alamat <strong>Email Sistem</strong>. Anda wajib membagikan (Share) Google Sheet target Anda ke email tersebut dengan akses sebagai <strong>Editor</strong>.
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                {/* Bagian 6: Mode Template JSON */}
                <section id="json" className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 scroll-mt-8">
                    <div className="flex items-center space-x-3 text-emerald-600 mb-4">
                        <Code size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">6. Mode Template .JSON (Pro)</h2>
                    </div>

                    <h3 className="text-lg font-bold text-gray-800 mb-3 ml-1">Dasar Properti Global</h3>
                    <div className="overflow-x-auto rounded-2xl border border-gray-100 mb-8">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50 text-left">
                                <tr>
                                    <th className="px-4 py-3 font-bold text-gray-700 w-1/4">Key</th>
                                    <th className="px-4 py-3 font-bold text-gray-700 w-1/4">Tipe</th>
                                    <th className="px-4 py-3 font-bold text-gray-700">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 font-medium text-gray-600">
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">title</td>
                                    <td className="px-4 py-3 text-indigo-600">String</td>
                                    <td className="px-4 py-3">Judul utama formulir.</td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">description</td>
                                    <td className="px-4 py-3 text-indigo-600">String</td>
                                    <td className="px-4 py-3">Penjelasan singkat di bawah judul.</td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">theme</td>
                                    <td className="px-4 py-3 text-indigo-600">Enum</td>
                                    <td className="px-4 py-3">Pilihan: <code className="text-rose-600">blue, purple, green, rose, orange, dark</code>.</td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">backgroundPattern</td>
                                    <td className="px-4 py-3 text-indigo-600">Enum</td>
                                    <td className="px-4 py-3">Pilihan: <code className="text-rose-600">none, grid, polkadot, waves, zigzag</code>.</td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">successMessage</td>
                                    <td className="px-4 py-3 text-indigo-600">String</td>
                                    <td className="px-4 py-3">Pesan yang muncul setelah pengiriman berhasil.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <h3 className="text-lg font-bold text-gray-800 mb-3 ml-1">Detail Properti Per-Field</h3>
                    <div className="overflow-x-auto rounded-2xl border border-gray-100 mb-8">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50 text-left">
                                <tr>
                                    <th className="px-4 py-3 font-bold text-gray-700 w-1/4">Properti</th>
                                    <th className="px-4 py-3 font-bold text-gray-700 w-1/4">Tipe</th>
                                    <th className="px-4 py-3 font-bold text-gray-700">Keterangan</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 font-medium text-gray-600">
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">id</td>
                                    <td className="px-4 py-3 text-indigo-600">String</td>
                                    <td className="px-4 py-3">ID unik (Tanpa spasi) untuk rekaman data & Logika.</td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">type</td>
                                    <td className="px-4 py-3 text-indigo-600">Enum</td>
                                    <td className="px-4 py-3 text-xs leading-relaxed">
                                        Short Text, Paragraph, Email, Number, Multiple Choice, Checkboxes, Dropdown, Linear Scale, Section Header, Page Break, Date, Time, File Upload.
                                    </td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">label</td>
                                    <td className="px-4 py-3 text-indigo-600">String</td>
                                    <td className="px-4 py-3">Teks pertanyaan yang tampil di layar.</td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">options</td>
                                    <td className="px-4 py-3 text-indigo-600">Array</td>
                                    <td className="px-4 py-3">Gunakan array string <code className="text-rose-600">["A", "B"]</code> untuk tipe Choice.</td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">validation</td>
                                    <td className="px-4 py-3 text-indigo-600">Object</td>
                                    <td className="px-4 py-3 text-xs">
                                        <code className="text-indigo-600">maxLength</code> (Text),
                                        <code className="text-indigo-600">min/max</code> (Number).
                                    </td>
                                </tr>
                                <tr>
                                    <td className="px-4 py-3 font-bold text-gray-900">logic</td>
                                    <td className="px-4 py-3 text-indigo-600">Object</td>
                                    <td className="px-4 py-3">Syarat visibilitas berdasarkan ID pertanyaan lain.</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div className="grid sm:grid-cols-2 gap-6 mb-8">
                        <div className="bg-amber-50/50 p-6 rounded-2xl border border-amber-100">
                            <div className="flex items-center gap-2 mb-2 text-amber-700 font-bold">
                                <ShieldCheck size={18} />
                                <h4>Alur Logika (Jump Logic)</h4>
                            </div>
                            <p className="text-xs text-amber-800 leading-relaxed font-medium">
                                Tampilkan pertanyaan hanya jika syarat tertentu terpenuhi dari pertanyaan sebelumnya.
                            </p>
                            <div className="bg-white p-3 rounded-xl mt-3 text-[10px] font-mono border border-amber-100 shadow-sm overflow-hidden">
                                "logic": &#123;<br />
                                &nbsp;&nbsp;"fieldId": "ID_PERTANYAAN_ASAL",<br />
                                &nbsp;&nbsp;"operator": "equals | not_equals | contains",<br />
                                &nbsp;&nbsp;"value": "Target Jawaban"<br />
                                &#125;
                            </div>
                        </div>
                        <div className="bg-indigo-50/50 p-6 rounded-2xl border border-indigo-100">
                            <div className="flex items-center gap-2 mb-2 text-indigo-700 font-bold">
                                <Sparkles size={18} />
                                <h4>Tema & Visual</h4>
                            </div>
                            <p className="text-xs text-indigo-800 leading-relaxed font-medium">
                                Sesuaikan palet warna dan pola latar belakang untuk branding yang kuat.
                            </p>
                            <div className="bg-white p-3 rounded-xl mt-3 text-[10px] font-mono border border-indigo-100 shadow-sm overflow-hidden">
                                "theme": "blue | purple | green | rose | orange | dark",<br />
                                "backgroundPattern": "none | grid | polkadot | waves | zigzag"
                            </div>
                        </div>
                    </div>

                    <div className="flex items-center justify-between mb-3">
                        <h3 className="text-lg font-bold text-gray-800">Contoh JSON Multi-Halaman</h3>
                        <div className="flex p-1 bg-gray-100 rounded-xl border border-gray-200">
                            <button
                                onClick={() => setExampleView('json')}
                                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${exampleView === 'json' ? 'bg-gray-900 text-emerald-400 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                            >JSON</button>
                            <button
                                onClick={() => setExampleView('preview')}
                                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${exampleView === 'preview' ? 'bg-white text-indigo-700 shadow-sm border border-gray-100' : 'text-gray-500 hover:text-gray-700'}`}
                            >Preview</button>
                        </div>
                    </div>

                    {exampleView === 'json' ? (
                        <div className="bg-gray-900 rounded-2xl p-5 overflow-x-auto">
                            <pre className="text-sm text-emerald-300 font-mono whitespace-pre">{`{
  "title": "Pengumpulan Tugas: Literasi Digital",
  "theme": "blue",
  "backgroundPattern": "grid",
  "fields": [
    { "type": "Section Header", "label": "Identitas", "helpText": "Halaman 1: Data Mahasiswa" },
    { 
      "id": "m_nim", 
      "type": "Number", 
      "label": "NIM Mahasiswa", 
      "required": true,
      "validation": { "min": 200000, "max": 299999 } 
    },
    { "id": "m_nama", "type": "Short Text", "label": "Nama Lengkap", "required": true },
    { "type": "Page Break", "label": "Detail Tugas" },
    { "type": "Section Header", "label": "Tugas", "helpText": "Halaman 2: Pengarsipan" },
    { "id": "t_topik", "type": "Short Text", "label": "Judul / Topik Tugas", "required": true },
    { 
      "id": "t_tipe", 
      "type": "Multiple Choice", 
      "label": "Metode Pengerjaan", 
      "options": ["Individu", "Kelompok"],
      "required": true 
    },
    { "type": "Page Break", "label": "Refleksi Akhir" },
    { 
      "id": "eval_scale", 
      "type": "Linear Scale", 
      "label": "Seberapa sulit kuis ini bagi Anda?", 
      "scaleMin": 1, 
      "scaleMax": 5 
    },
    { "id": "eval_teks", "type": "Paragraph", "label": "Tantangan Terbesar Anda?" }
  ]
}`}</pre>
                        </div>
                    ) : (
                        <div className="border border-gray-200 rounded-xl overflow-hidden bg-gray-50/50 p-1 shadow-inner animate-in zoom-in-95 duration-500">
                            <div className="bg-white rounded-[1.8rem] shadow-sm border border-gray-100 overflow-hidden">
                                {/* Progress Bar Mini */}
                                <div className="h-1.5 w-full bg-gray-100 relative">
                                    <div
                                        className="absolute left-0 top-0 h-full bg-indigo-600 rounded-r-full shadow-sm transition-all duration-500"
                                        style={{ width: `${(previewPage / 3) * 100}%` }}
                                    ></div>
                                </div>
                                <div className="p-6 text-center border-b border-gray-50">
                                    <h4 className="text-xl font-black text-gray-900 leading-tight">Formulir Survey</h4>
                                    <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase tracking-widest leading-none">Halaman {previewPage} dari 3</p>
                                </div>

                                <div className="p-6 space-y-4">
                                    {previewPage === 1 && (
                                        <div className="space-y-4 border-l-2 border-indigo-500 pl-4 py-1 animate-in slide-in-from-right-4 duration-300">
                                            <div className="bg-gray-100 p-4 rounded-xl border border-gray-100 italic text-gray-500 text-xs font-bold font-mono">"Halaman 1: Data Mahasiswa"</div>
                                            <div>
                                                <p className="font-bold text-gray-900 text-xs mb-2">NIM Mahasiswa <span className="text-red-500">*</span></p>
                                                <div className="border-b-2 border-blue-100 pb-1 text-indigo-600 text-[11px] font-black tracking-widest leading-none">230192837</div>
                                            </div>
                                            <div>
                                                <p className="font-bold text-gray-900 text-xs mb-2">Nama Lengkap <span className="text-red-500">*</span></p>
                                                <div className="border-b border-gray-200 pb-1 text-gray-400 text-[10px] font-medium leading-none">Andi Wijaya</div>
                                            </div>
                                        </div>
                                    )}

                                    {previewPage === 2 && (
                                        <div className="space-y-4 border-l-2 border-indigo-500 pl-4 py-1 animate-in slide-in-from-right-4 duration-300">
                                            <div className="bg-gray-100 p-4 rounded-xl border border-gray-100 italic text-gray-500 text-xs font-bold font-mono">"Halaman 2: Pengarsipan"</div>
                                            <div>
                                                <p className="font-bold text-gray-900 text-xs mb-2">Judul / Topik Tugas <span className="text-red-500">*</span></p>
                                                <div className="border-b border-gray-200 pb-1 text-gray-400 text-[10px] font-medium leading-none">Dampak AI bagi Literasi Media</div>
                                            </div>
                                            <div>
                                                <p className="font-bold text-gray-900 text-xs mb-2">Metode Pengerjaan <span className="text-red-500">*</span></p>
                                                <div className="flex gap-2">
                                                    <div className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-[10px] font-bold shadow-md shadow-indigo-100">Individu</div>
                                                    <div className="px-3 py-1.5 rounded-lg bg-gray-50 text-gray-400 text-[10px] font-bold border border-gray-100">Kelompok</div>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {previewPage === 3 && (
                                        <div className="space-y-4 border-l-2 border-emerald-500 pl-4 py-1 animate-in slide-in-from-right-4 duration-300">
                                            <div className="bg-gray-100 p-4 rounded-xl border border-gray-100 italic text-gray-500 text-xs font-bold font-mono">"Halaman 3: Refleksi"</div>
                                            <div className="bg-gray-50 p-4 rounded-2xl border border-gray-100 shadow-sm text-left">
                                                <p className="font-bold text-gray-900 text-[10px] mb-3 uppercase tracking-tighter">Seberapa sulit kuis ini bagi Anda?</p>
                                                <div className="flex justify-between items-center px-1">
                                                    {[1, 2, 3, 4, 5].map(v => (
                                                        <div key={v} className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold border-2 transition-all ${v === 2 ? 'bg-indigo-600 border-indigo-600 text-white shadow-md scale-110' : 'bg-white border-gray-100 text-gray-400'}`}>
                                                            {v}
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                            <div>
                                                <p className="font-bold text-gray-900 text-xs mb-2">Tantangan Terbesar Anda?</p>
                                                <div className="border border-gray-200 rounded-lg p-3 h-12 text-gray-300 text-[9px] font-medium leading-relaxed">Mencari sumber referensi primer...</div>
                                            </div>
                                        </div>
                                    )}

                                    <div className="flex gap-4 pt-2">
                                        {previewPage > 1 ? (
                                            <button
                                                onClick={() => setPreviewPage(prev => prev - 1)}
                                                className="flex-1 px-4 py-3 bg-white border border-gray-200 rounded-xl text-[10px] font-black text-gray-500 text-center uppercase tracking-widest shadow-sm hover:bg-gray-50 active:scale-95 transition-all"
                                            >KEMBALI</button>
                                        ) : (
                                            <div className="flex-1"></div>
                                        )}

                                        {previewPage < 3 ? (
                                            <button
                                                onClick={() => setPreviewPage(prev => prev + 1)}
                                                className="flex-1 px-4 py-3 bg-indigo-600 rounded-xl text-[10px] font-black text-white text-center uppercase tracking-widest shadow-lg shadow-blue-100 hover:bg-indigo-700 active:scale-95 transition-all"
                                            >BERIKUTNYA</button>
                                        ) : (
                                            <button
                                                onClick={() => { alert('Tanggapan Berhasil Dikirim (Mockup)'); setPreviewPage(1); }}
                                                className="flex-1 px-4 py-3 bg-gray-900 rounded-xl text-[10px] font-black text-emerald-400 text-center uppercase tracking-widest shadow-lg shadow-gray-200 hover:bg-black active:scale-95 transition-all"
                                            >KIRIM FORM</button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    <h3 className="text-lg font-bold text-gray-800 mt-8 mb-3">Copy-Paste Prompt AI</h3>
                    <div className="relative bg-gray-900 rounded-2xl p-5 overflow-x-auto">
                        <button
                            onClick={handleCopy}
                            className={`absolute top-4 right-4 flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition-all ${copied ? 'bg-emerald-500 text-white' : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
                        >
                            {copied ? <><Check size={14} /> Tersalin!</> : <><Copy size={14} /> Salin</>}
                        </button>
                        <pre className="text-sm text-yellow-200 font-mono whitespace-pre-wrap pr-20 leading-relaxed text-xs">{AI_PROMPT}</pre>
                    </div>
                </section>

                {/* Bagian 7: Keamanan & Database */}
                <section className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-3 text-orange-600 mb-4">
                        <ShieldCheck size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">7. Keamanan & Database</h2>
                    </div>
                    <p className="text-gray-600 font-medium leading-relaxed">
                        Data formulir Anda secara default dikelola oleh <strong className="text-gray-900 font-bold">Google Apps Script (GAS)</strong> sistem. Kami mengedepankan privasi: kunci API dan database <em>spreadsheet</em> tidak pernah disimpan di server pihak ketiga, melainkan di <em>sheet</em> tersembunyi milik sistem yang terenkripsi.
                    </p>
                </section>





                <section className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 mb-16">
                    <div className="flex items-center space-x-3 text-rose-600 mb-4">
                        <ShieldCheck size={24} strokeWidth={2.5} />
                        <h2 className="text-2xl font-bold text-gray-900">9. Keamanan Pendaftaran (Email OTP)</h2>
                    </div>
                    <p className="text-gray-600 font-medium leading-relaxed mb-6">
                        Untuk mencegah serangan DDoS dan pendaftaran akun palsu, platform sekarang mewajibkan verifikasi OTP via Email. Berikut alur logika yang harus ada di backend Anda:
                    </p>

                    <div className="space-y-4">
                        <div className="bg-gray-50 p-5 rounded-2xl border border-gray-100 text-xs text-gray-700 leading-relaxed">
                            <p className="font-bold text-gray-900 mb-2">Alur 1: Request OTP (verify = false)</p>
                            <ol className="list-decimal pl-4 space-y-2">
                                <li>Terima <code>username</code>, <code>email</code>, dan <code>password</code>.</li>
                                <li>Generate 6-digit angka acak.</li>
                                <li>Simpan data pendaftaran sementara (Pending) di database dengan kode OTP tersebut.</li>
                                <li>Kirim email ke user menggunakan <code>MailApp.sendEmail</code> (untuk GAS) atau SMTP (untuk Node.js).</li>
                            </ol>
                        </div>

                        <div className="bg-gray-50 p-5 rounded-2xl border border-gray-100 text-xs text-gray-700 leading-relaxed">
                            <p className="font-bold text-gray-900 mb-2">Alur 2: Verifikasi OTP (verify = true)</p>
                            <ol className="list-decimal pl-4 space-y-2">
                                <li>Cari data pendaftaran berdasarkan <code>username</code> di tabel Pending.</li>
                                <li>Cocokkan <code>otp</code> yang dikirim user dengan yang ada di database.</li>
                                <li>Jika cocok, pindahkan data ke tabel User Utama dan hapus dari tabel Pending.</li>
                            </ol>
                        </div>
                    </div>
                </section>

                {/* Section: Support / Give a Coffee */}
                <section className="mt-16 pt-16 border-t border-gray-100 pb-20 px-2 sm:px-0">
                    <div className="bg-gradient-to-br from-indigo-50 via-white to-indigo-50 rounded-2xl p-8 sm:p-12 border border-indigo-100/50 shadow-sm text-center relative overflow-hidden group">
                        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-200/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
                        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-200/20 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl"></div>

                        <div className="relative z-10 max-w-2xl mx-auto space-y-6">
                            <div className="inline-flex items-center justify-center p-4 bg-white rounded-2xl shadow-xl shadow-indigo-100/50 border border-indigo-50 group-hover:scale-110 transition-transform duration-500">
                                <Coffee size={40} className="text-blue-600" />
                            </div>
                            <h2 className="text-3xl sm:text-4xl font-black text-gray-900 leading-tight">Dukung Pengembangan <br /><span className="text-blue-600">Form Architect</span></h2>
                            <p className="text-gray-600 font-medium leading-relaxed">
                                App ini dikembangkan dengan tulus untuk memudahkan kawan-kawan pembuat form. Jika aplikasi ini membantu produktivitas Anda, secangkir kopi akan sangat berarti bagi kami untuk terus memperbarui fitur-fitur seru lainnya!
                            </p>
                            <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                                <Link
                                    to="/coffee"
                                    className="w-full sm:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-sm transition-all hover:shadow-xl hover:shadow-indigo-200 active:scale-95 flex items-center justify-center gap-3"
                                >
                                    <Coffee size={20} />
                                    Traktir Kopi (Dukungan)
                                </Link>
                                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest italic">Terima kasih atas dukungannya!</p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
}
