import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { gasRequest } from '../services/sheetsService';
import { generateFormBlueprint } from '../services/aiService';
import { Sparkles, Code, Globe, Copy, Palette, X, Type, AlignLeft, Mail, Hash, CheckSquare, List, ChevronDown, Calendar, Clock, Sliders, Layout, Split, Upload, Lock, Shield, Database, ExternalLink } from 'lucide-react';

import FormBuilderSidebar, { PATTERNS } from '../components/FormBuilderSidebar';
import FormBuilderTopbar from '../components/FormBuilderTopbar';
import FormBuilderCanvas from '../components/FormBuilderCanvas';
import BottomSheet from '../components/BottomSheet';
import { FIELD_TYPES } from '../components/FormFieldItem';

export default function FormBuilder() {
    const { user, googleToken } = useAuth();
    const navigate = useNavigate();
    const { formId } = useParams();

    const [embedMode, setEmbedMode] = useState(false);
    const [jsonMode, setJsonMode] = useState(false);
    const [jsonInput, setJsonInput] = useState('');
    const [formCount, setFormCount] = useState(0);

    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [customSlug, setCustomSlug] = useState('');
    const [theme, setTheme] = useState('blue');
    const [backgroundPattern, setBackgroundPattern] = useState('none');
    const [isActive, setIsActive] = useState(true);
    const [confirmationMessage, setConfirmationMessage] = useState('Tanggapan Anda telah dicatat.');
    const [gformUrl, setGformUrl] = useState('');
    const [userSpreadsheetId, setUserSpreadsheetId] = useState('');
    const [userFolderId, setUserFolderId] = useState('');
    const [isQuizMode, setIsQuizMode] = useState(false);
    const [requireLogin, setRequireLogin] = useState(false);
    const [limitOneResponse, setLimitOneResponse] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [showAi, setShowAi] = useState(false);
    const [showTheme, setShowTheme] = useState(false);
    const [openDropdownId, setOpenDropdownId] = useState(null);
    const [showAllTypes, setShowAllTypes] = useState(false);
    const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 1024);

    const [fields, setFields] = useState([]);

    const [aiPrompt, setAiPrompt] = useState('');
    const [aiLoading, setAiLoading] = useState(false);
    const [aiPreview, setAiPreview] = useState(null);

    const [importUrl, setImportUrl] = useState('');
    const [importLoading, setImportLoading] = useState(false);
    const [draggedItemIndex, setDraggedItemIndex] = useState(null);
    const [isDirty, setIsDirty] = useState(false);
    const [initialLoading, setInitialLoading] = useState(!!formId);
    const [error, setError] = useState(null);
    const [saving, setSaving] = useState(false);
    const [postToGFormUrl, setPostToGFormUrl] = useState('');

    useEffect(() => {
        const loadForm = async () => {
            if (formId) {
                const res = await gasRequest('getFormBySlug', { slug: formId });
                if (res.success) {
                    const existing = res.form;
                    setTitle(existing.title || '');
                    setDescription(existing.description || '');
                    setCustomSlug(existing.customSlug || '');
                    setTheme(existing.theme || 'blue');
                    setBackgroundPattern(existing.backgroundPattern || 'none');
                    setIsActive(existing.isActive !== false);
                    setConfirmationMessage(existing.confirmationMessage || 'Tanggapan Anda telah dicatat.');
                    setGformUrl(existing.gformUrl || '');
                    setUserSpreadsheetId(existing.userSpreadsheetId || '');
                    setUserFolderId(existing.userFolderId || '');
                    setIsQuizMode(existing.isQuizMode === true || existing.isQuizMode === "TRUE");
                    setRequireLogin(existing.requireLogin === true || existing.requireLogin === "TRUE");
                    setLimitOneResponse(existing.limitOneResponse === true || existing.limitOneResponse === "TRUE");
                    if (existing.gformUrl && existing.gformUrl.includes('docs.google.com/forms/')) {
                        setEmbedMode(!existing.fields_schema_json || existing.fields_schema_json === '[]');
                    }
                    try {
                        setFields(JSON.parse(existing.fields_schema_json || '[]'));
                    } catch (e) {
                        setFields([]);
                    }
                    setTimeout(() => setIsDirty(false), 500);
                } else {
                    setError('Formulir tidak ditemukan atau Anda tidak memiliki akses.');
                }
            }
            setInitialLoading(false);
        };
        loadForm();

        const fetchFormCount = async () => {
            if (user?.username) {
                const res = await gasRequest('getCreatorForms', { username: user.username });
                if (res.success) {
                    setFormCount(res.forms.length);
                }
            }
        };
        fetchFormCount();
    }, [formId, user?.username]);

    useEffect(() => {
        document.body.style.overflow = showAllTypes && !isDesktop ? 'hidden' : 'unset';
        return () => { document.body.style.overflow = 'unset'; };
    }, [showAllTypes, isDesktop]);

    useEffect(() => {
        const handleResize = () => setIsDesktop(window.innerWidth >= 1024);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const addField = (type) => {
        const newField = {
            id: `field_${Date.now()}`,
            type,
            label: type === 'Page Break' ? 'Pemisah Halaman' :
                type === 'Section Header' ? 'Judul Bagian Baru' :
                    `Pertanyaan Baru (${type})`,
            required: false,
            helpText: type === 'Section Header' ? 'Keterangan atau deskripsi tambahan untuk bagian ini...' : '',
            options: (type === 'Multiple Choice' || type === 'Checkboxes' || type === 'Dropdown') ? ['Opsi 1', 'Opsi 2'] : [],
            min: type === 'Linear Scale' ? 1 : undefined,
            max: type === 'Linear Scale' ? 5 : undefined,
            minLabel: type === 'Linear Scale' ? '' : undefined,
            maxLabel: type === 'Linear Scale' ? '' : undefined,
            points: (type === 'Section Header' || type === 'Page Break') ? 0 : 1,
            correctAnswer: ''
        };
        setFields([...fields, newField]);
        setIsDirty(true);
    };

    const removeField = (id) => {
        setFields(fields.filter(f => f.id !== id));
        setIsDirty(true);
    };

    const updateField = (id, updates) => {
        setFields(fields.map(f => f.id === id ? { ...f, ...updates } : f));
        setIsDirty(true);
    };

    const handleDragStart = (index) => setDraggedItemIndex(index);

    const handleDragOver = (e, index) => {
        e.preventDefault();
        if (draggedItemIndex === null || draggedItemIndex === index) return;
        const reordered = [...fields];
        const [removed] = reordered.splice(draggedItemIndex, 1);
        reordered.splice(index, 0, removed);
        setFields(reordered);
        setDraggedItemIndex(index);
        setIsDirty(true);
    };

    const handleDrop = () => setDraggedItemIndex(null);

    const handleSave = async () => {
        const isNewForm = !formId;
        const isLimitReached = formCount >= 10;
        const isPersonalStorage = !!googleToken;

        if (isNewForm && isLimitReached && !user?.isVerified && !isPersonalStorage) {
            alert('Kapasitas Penuh! Anda telah mencapai batas 10 formulir. Silakan verifikasi akun atau gunakan penyimpanan personal untuk menambah kapasitas.');
            return;
        }

        setSaving(true);
        let currentSpreadsheetId = userSpreadsheetId;
        let currentFolderId = userFolderId;

        if (googleToken && !embedMode) {
            try {
                if (!currentSpreadsheetId) {
                    const sheetRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${googleToken}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            properties: { title: `MYForm: ${title.trim()}` }
                        })
                    });
                    const sheetData = await sheetRes.json();
                    if (sheetData.spreadsheetId) {
                        currentSpreadsheetId = sheetData.spreadsheetId;
                        setUserSpreadsheetId(currentSpreadsheetId);
                    }
                }

                if (!currentFolderId) {
                    const folderRes = await fetch('https://www.googleapis.com/drive/v3/files', {
                        method: 'POST',
                        headers: {
                            'Authorization': `Bearer ${googleToken}`,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            name: `MYForm_Uploads_${title.trim()}`,
                            mimeType: 'application/vnd.google-apps.folder'
                        })
                    });
                    const folderData = await folderRes.json();
                    if (folderData.id) {
                        currentFolderId = folderData.id;
                        setUserFolderId(currentFolderId);
                    }
                }
            } catch (err) {
                console.error("Gagal membuat penyimpanan Google personal:", err);
            }
        }

        const payload = {
            formId: formId || null,
            title: title.trim(),
            description: description.trim(),
            customSlug: customSlug.trim().toLowerCase(),
            theme,
            backgroundPattern,
            isActive,
            confirmationMessage: embedMode ? '' : confirmationMessage.trim(),
            gformUrl: embedMode ? gformUrl.trim() : (postToGFormUrl || ''),
            fields_schema_json: embedMode ? '[]' : JSON.stringify(fields),
            userSpreadsheetId: currentSpreadsheetId,
            userFolderId: currentFolderId,
            isQuizMode,
            requireLogin,
            limitOneResponse
        };

        const res = await gasRequest('createForm', payload);
        setSaving(false);

        if (res.success) {
            setIsDirty(false);
            alert(formId ? 'Perubahan berhasil disimpan!' : `Berhasil dibuat! Link: /f/${res.customSlug}`);
            navigate('/');
        } else {
            setError(res.error || 'Terjadi kesalahan sistem.');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    };

    const handleImport = async () => {
        if (!importUrl) return;
        setImportLoading(true);
        const res = await gasRequest('importGForm', { url: importUrl });
        setImportLoading(false);
        if (res.success) {
            if (res.hasFileUpload) {
                alert("Form ini memiliki fitur File Upload yang tidak didukung via G-Embed Hybrid. Silakan gunakan Google Form murni atau bangun dari awal di Native.");
                return;
            }
            setEmbedMode(false);
            setPostToGFormUrl(res.actionUrl);
            setFields(res.fields);
            setGformUrl(importUrl);
            alert("Berhasil mengimpor struktur Google Form!");
        } else {
            alert("Gagal impor: " + res.error);
        }
    };

    const handleAiGenerate = async () => {
        if (!aiPrompt) return;
        setAiLoading(true);
        try {
            const blueprint = await generateFormBlueprint(aiPrompt);
            setAiPreview(blueprint);
        } catch (e) {
            alert("AI Magic Engine sedang sibuk. Silakan coba sebentar lagi.");
        }
        setAiLoading(false);
    };

    const applyAiBlueprint = () => {
        if (!aiPreview) return;
        setTitle(aiPreview.title || title);
        setDescription(aiPreview.description || description);
        setTheme(aiPreview.theme || theme);
        setBackgroundPattern(aiPreview.backgroundPattern || backgroundPattern);
        setConfirmationMessage(aiPreview.successMessage || confirmationMessage);
        setFields(aiPreview.fields || fields);
        setAiPreview(null);
        setAiPrompt('');
        setIsDirty(true);
    };

    const handleJsonSync = () => {
        try {
            const parsed = JSON.parse(jsonInput);
            if (parsed.title !== undefined) setTitle(parsed.title);
            if (parsed.description !== undefined) setDescription(parsed.description);
            if (parsed.fields !== undefined) setFields(parsed.fields);
            setJsonMode(false);
            setIsDirty(true);
            alert("Blueprint JSON berhasil disinkronkan!");
        } catch (e) {
            alert("Gagal sinkron: Format JSON tidak valid. Periksa kembali struktur data Anda.");
        }
    };

    if (initialLoading) {
        return (
            <div className="w-full h-full min-h-[60vh] flex flex-col items-center justify-center space-y-4">
                <Sparkles size={48} className="text-indigo-600 animate-spin" />
                <p className="text-sm font-black text-gray-400 uppercase tracking-widest">Memuat Formulir...</p>
            </div>
        );
    }

    return (
        <div className="w-full relative">
            {/* Bottom Sheet: Pilih Tipe Pertanyaan */}
            {!isDesktop && (
                <BottomSheet
                    isOpen={showAllTypes}
                    onClose={() => setShowAllTypes(false)}
                    title="Pilih Tipe Pertanyaan"
                >
                    <div className="grid grid-cols-2 gap-3 pb-20">
                        {FIELD_TYPES.map(type => (
                            <button key={type} onClick={() => { addField(type); setShowAllTypes(false); }} className="flex items-center gap-3 w-full p-4 rounded-2xl text-left bg-gray-50 hover:bg-indigo-50 group transition-all border border-transparent hover:border-blue-200">
                                <div className="p-2 bg-white rounded-xl shadow-sm text-gray-400 group-hover:text-indigo-600 transition-all">
                                    {type === 'Short Text' && <Type size={18} />}
                                    {type === 'Paragraph' && <AlignLeft size={18} />}
                                    {type === 'Email' && <Mail size={18} />}
                                    {type === 'Number' && <Hash size={18} />}
                                    {type === 'Multiple Choice' && <List size={18} />}
                                    {type === 'Checkboxes' && <CheckSquare size={18} />}
                                    {type === 'Dropdown' && <ChevronDown size={18} />}
                                    {type === 'Linear Scale' && <Sliders size={18} />}
                                    {type === 'Date' && <Calendar size={18} />}
                                    {type === 'Time' && <Clock size={18} />}
                                    {type === 'File Upload' && <Upload size={18} />}
                                    {type === 'Section Header' && <Layout size={18} />}
                                    {type === 'Page Break' && <Split size={18} />}
                                </div>
                                <span className="text-xs font-black text-gray-700 leading-tight">{type}</span>
                            </button>
                        ))}
                    </div>
                </BottomSheet>
            )}

            {/* Bottom Sheet: Tema & Tampilan (Mobile) */}
            <BottomSheet
                isOpen={showTheme}
                onClose={() => setShowTheme(false)}
                title="Tema & Tampilan"
                maxWidth="sm:max-w-md"
            >
                <div className="space-y-8 pb-10">
                    <div className="space-y-4">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                            <Palette size={12} /> TEMA WARNA
                        </label>
                        <div className="grid grid-cols-5 gap-3">
                            {['blue', 'purple', 'green', 'rose', 'orange'].map(c => (
                                <button key={c} onClick={() => setTheme(c)} className={`h-12 rounded-2xl transition-all border-4 ${theme === c ? 'border-indigo-500 scale-90 ring-4 ring-indigo-50' : 'border-transparent opacity-60'} ${c === 'blue' ? 'bg-indigo-500' : c === 'purple' ? 'bg-purple-500' : c === 'green' ? 'bg-green-500' : c === 'rose' ? 'bg-rose-500' : 'bg-orange-500'}`} />
                            ))}
                        </div>
                    </div>

                    <div className="space-y-4">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">POLA LATAR BELAKANG</label>
                        <div className="grid grid-cols-2 gap-3">
                            {PATTERNS.map(p => (
                                <button key={p.value} onClick={() => setBackgroundPattern(p.value)} className={`flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${backgroundPattern === p.value ? 'bg-indigo-50 border-blue-200' : 'bg-gray-50 border-transparent opacity-60'}`}>
                                    <span className="text-xs font-black text-gray-700">{p.label}</span>
                                    <div className={`w-10 h-10 rounded-xl ${p.className} border border-gray-200`} />
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </BottomSheet>

            {/* Bottom Sheet: Pengaturan Umum (Mobile) */}
            <BottomSheet
                isOpen={showSettings}
                onClose={() => setShowSettings(false)}
                title="Pengaturan Formulir"
                maxWidth="sm:max-w-md"
            >
                <div className="space-y-8 pb-10">
                    <div className="space-y-4">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">ALAMAT TAUTAN (CUSTOM)</label>
                        <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3 focus-within:ring-4 focus-within:ring-indigo-100 focus-within:border-indigo-500 transition-all">
                            <span className="text-gray-400 font-bold text-xs uppercase tracking-tighter">myform.id/f/</span>
                            <input
                                type="text"
                                value={customSlug}
                                onChange={(e) => setCustomSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                                placeholder="slug-bebas"
                                className="flex-1 bg-transparent border-none outline-none text-sm font-black text-gray-900 placeholder-gray-300 uppercase tracking-widest"
                            />
                        </div>
                    </div>

                    <div className="space-y-4 pt-2">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">PESAN KONFIRMASI</label>
                        <textarea
                            value={confirmationMessage}
                            onChange={(e) => setConfirmationMessage(e.target.value)}
                            placeholder="Tulis pesan terima kasih Anda..."
                            className="w-full bg-gray-50 border border-gray-200 rounded-2xl p-4 text-sm text-gray-700 placeholder-gray-400 outline-none focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 transition-all resize-none h-24 font-medium"
                        />
                    </div>

                    <div className="pt-6 border-t border-gray-100 flex items-center justify-between">
                        <div className="space-y-1">
                            <span className="text-xs font-black text-gray-900 uppercase tracking-widest block">Mode Kuis</span>
                            <span className="text-[10px] text-gray-400 font-bold">Skor & kunci jawaban otomatis</span>
                        </div>
                        <button onClick={() => setIsQuizMode(!isQuizMode)} className={`w-14 h-7 rounded-full transition-all relative flex-shrink-0 ${isQuizMode ? 'bg-orange-500 shadow-lg shadow-orange-200' : 'bg-gray-200'}`}>
                            <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-all shadow-sm ${isQuizMode ? 'left-8' : 'left-1'}`} />
                        </button>
                    </div>

                    <div className="pt-6 border-t border-gray-100 space-y-5">
                        <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2">
                            <Shield size={12} /> KEAMANAN PENGISIAN
                        </label>

                        <div className="flex items-center justify-between">
                            <div className="space-y-1 pr-4">
                                <span className="text-xs font-black text-gray-900 leading-tight block">Wajib Login</span>
                                <span className="text-[10px] text-gray-400 font-bold leading-relaxed block">Formulir tertutup untuk tamu. Pengisi wajib terdaftar akun.</span>
                            </div>
                            <button onClick={() => setRequireLogin(!requireLogin)} className={`w-14 h-7 rounded-full transition-all relative flex-shrink-0 ${requireLogin ? 'bg-rose-500 shadow-lg shadow-rose-200' : 'bg-gray-200'}`}>
                                <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-all shadow-sm flex items-center justify-center ${requireLogin ? 'left-8 text-rose-500' : 'left-1 text-gray-400'}`}>
                                    {requireLogin && <Lock size={10} strokeWidth={3} />}
                                </div>
                            </button>
                        </div>

                        <div className="flex items-center justify-between pt-2">
                            <div className="flex flex-col pr-2">
                                <span className="text-xs font-black text-gray-900 uppercase tracking-widest">Batas 1 Tanggapan</span>
                                <span className="text-[10px] text-gray-400 font-bold leading-tight">Mencegah spam form ganda</span>
                            </div>
                            <button onClick={() => setLimitOneResponse(!limitOneResponse)} className={`w-12 h-6 rounded-full transition-all relative flex-shrink-0 ${limitOneResponse ? 'bg-indigo-500' : 'bg-gray-200'}`}>
                                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${limitOneResponse ? 'left-7' : 'left-1'}`} />
                            </button>
                        </div>
                    </div>

                    {/* Mobile Storage Settings */}
                    {(googleToken || userSpreadsheetId) && (
                        <div className="pt-6 border-t border-gray-100">
                            <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest flex items-center gap-2 mb-4">
                                <Database size={12} /> PENYIMPANAN DATA
                            </label>

                            <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100 space-y-3">
                                <div className="flex items-center justify-between">
                                    <div className="flex items-center gap-2 text-emerald-600">
                                        <Globe size={14} />
                                        <span className="text-[10px] font-black uppercase tracking-widest">Google Drive</span>
                                    </div>
                                    <div className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-lg text-[8px] font-black uppercase">Aktif</div>
                                </div>

                                {userSpreadsheetId ? (
                                    <div className="space-y-3">
                                        <p className="text-[10px] text-gray-500 font-bold leading-tight line-clamp-1">ID: {userSpreadsheetId}</p>
                                        <a
                                            href={`https://docs.google.com/spreadsheets/d/${userSpreadsheetId}`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="w-full flex items-center justify-center gap-2 py-3 bg-white border border-gray-200 rounded-xl text-[10px] font-black text-indigo-600 uppercase tracking-widest hover:bg-indigo-50 transition-all shadow-sm active:scale-95"
                                        >
                                            <ExternalLink size={14} /> Buka Spreadsheet
                                        </a>
                                    </div>
                                ) : (
                                    <p className="text-[10px] text-gray-400 font-bold leading-relaxed italic">
                                        File baru akan dibuat otomatis saat Anda pertama kali menyimpan formulir ini.
                                    </p>
                                )}
                            </div>
                        </div>
                    )}
                </div>
            </BottomSheet>

            {/* Bottom Sheet: Magic AI Engine (Mobile) */}
            <BottomSheet
                isOpen={showAi}
                onClose={() => setShowAi(false)}
                title="Magic AI Engine"
            >
                <div className="space-y-6 pb-10 text-center">
                    <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100 text-left">
                        <p className="text-[10px] text-indigo-600 font-black uppercase tracking-widest mb-2 flex items-center gap-1">
                            <Sparkles size={10} /> AI Instructor
                        </p>
                        <p className="text-xs text-indigo-900 font-bold leading-relaxed italic">
                            "Berikan instruksi spesifik (misal: 'buat form pendaftaran kursus masak') dan saya akan merancang seluruh strukturnya."
                        </p>
                    </div>
                    <textarea
                        value={aiPrompt}
                        onChange={(e) => setAiPrompt(e.target.value)}
                        placeholder="Ketik permintaan Anda di sini..."
                        className="w-full bg-gray-50 border border-gray-200 rounded-2xl p-5 text-sm font-medium outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all h-40"
                    />
                    <div className="flex flex-col gap-3">
                        <button
                            onClick={() => { handleAiGenerate(); setShowAi(false); }}
                            disabled={aiLoading || !aiPrompt}
                            className="w-full bg-indigo-600 text-white py-5 rounded-2xl text-xs font-black uppercase tracking-[0.2em] transition-all shadow-xl active:scale-95 disabled:opacity-50"
                        >
                            {aiLoading ? 'Magic in progress...' : 'Mulai Sekarang'}
                        </button>
                        <button onClick={() => { setShowAi(false); setShowSettings(true); }} className="text-[10px] font-black text-gray-400 uppercase tracking-widest hover:text-gray-900 transition-colors">Kembali ke Pengaturan Formulir</button>
                    </div>
                </div>
            </BottomSheet>

            <FormBuilderTopbar
                title={title}
                embedMode={embedMode} setEmbedMode={setEmbedMode}
                jsonMode={jsonMode} setJsonMode={setJsonMode}
                setJsonInput={setJsonInput}
                fields={fields}
                description={description}
                showAi={showAi} setShowAi={setShowAi}
                showSettings={showSettings} setShowSettings={setShowSettings}
                showTheme={showTheme} setShowTheme={setShowTheme}
                handleSave={handleSave}
                saving={saving}
                isDirty={isDirty}
            />

            <div className="max-w-7xl mx-auto px-4 py-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                    <FormBuilderSidebar
                        theme={theme} setTheme={setTheme}
                        backgroundPattern={backgroundPattern} setBackgroundPattern={setBackgroundPattern}
                        isQuizMode={isQuizMode} setIsQuizMode={setIsQuizMode}
                        requireLogin={requireLogin} setRequireLogin={setRequireLogin}
                        limitOneResponse={limitOneResponse} setLimitOneResponse={setLimitOneResponse}
                        confirmationMessage={confirmationMessage} setConfirmationMessage={setConfirmationMessage}
                        customSlug={customSlug} setCustomSlug={setCustomSlug}
                        setShowSettings={setShowSettings}
                        aiPrompt={aiPrompt} setAiPrompt={setAiPrompt} aiLoading={aiLoading} handleAiGenerate={handleAiGenerate}
                        userSpreadsheetId={userSpreadsheetId} googleToken={googleToken}
                    />

                    <div className="lg:col-span-8 space-y-6">
                        {aiPreview && (
                            <div className="bg-indigo-600 rounded-2xl overflow-hidden shadow-2xl animate-in zoom-in duration-500 relative">
                                <div className="absolute -top-10 -right-10 text-blue-100 opacity-20">
                                    <Sparkles size={160} strokeWidth={1} />
                                </div>
                                <div className="p-8 sm:p-12 space-y-6 relative">
                                    <div className="flex items-center space-x-3 text-white">
                                        <div className="bg-white/20 p-2 rounded-xl lg:backdrop-blur-xl"><Sparkles size={24} /></div>
                                        <span className="font-black text-2xl uppercase tracking-tighter">Preview Magic Blueprint</span>
                                    </div>
                                    <div className="bg-white/10 lg:backdrop-blur-md p-6 rounded-2xl border border-white/10 text-sm text-indigo-50 font-bold space-y-4">
                                        <div className="flex items-center gap-3">
                                            <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                                            <span>AI telah merancang struktur form berdasarkan permintaan Anda. Ingin menerapkannya?</span>
                                        </div>
                                        <div className="bg-white/80 lg:backdrop-blur p-4 rounded-xl border border-blue-100 text-xs text-blue-900 space-y-1 max-h-40 overflow-y-auto">
                                            <p className="font-black uppercase tracking-widest opacity-50 text-[10px] mb-2">Preview Struktur:</p>
                                            <p>Judul: {aiPreview.title}</p>
                                            <p>Fields: {aiPreview.fields?.length} pertanyaan</p>
                                            <ul className="list-disc pl-4 mt-2 space-y-1">
                                                {aiPreview.fields?.map((f, i) => <li key={i}>{f.label} ({f.type})</li>)}
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="flex gap-4">
                                        <button onClick={applyAiBlueprint} className="flex-1 bg-white text-indigo-600 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-indigo-50 transition-all shadow-xl active:scale-95">Terapkan Struktur</button>
                                        <button onClick={() => setAiPreview(null)} className="px-8 bg-indigo-700 text-blue-300 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:text-white transition-all">Batal</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {jsonMode ? (
                            <div className="bg-gray-900 rounded-3xl p-6 sm:p-10 shadow-2xl border border-gray-800 space-y-6 animate-in zoom-in duration-300">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-800 pb-6">
                                    <div className="flex items-center space-x-3 text-emerald-400 font-black text-xl">
                                        <div className="bg-emerald-400/10 p-2 rounded-xl"><Code size={24} /></div>
                                        <span>Blueprint JSON</span>
                                    </div>
                                    <div className="flex items-center gap-3 w-full sm:w-auto">
                                        <button onClick={() => { navigator.clipboard.writeText(jsonInput); alert("JSON disalin ke clipboard!"); }} className="p-3 bg-gray-800 rounded-xl text-gray-400 hover:text-white transition-colors" title="Salin JSON"><Copy size={18} /></button>
                                        <button onClick={handleJsonSync} className="flex-1 sm:flex-none bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95">Sinkronkan Blueprint</button>
                                    </div>
                                </div>
                                <div className="relative group">
                                    <div className="absolute top-4 left-4 text-[10px] font-bold text-gray-600 uppercase tracking-widest pointer-events-none">SUMBER DATA</div>
                                    <textarea value={jsonInput} onChange={(e) => setJsonInput(e.target.value)} className="w-full h-[60vh] bg-gray-950 border border-gray-800 rounded-2xl p-8 pt-12 text-sm font-mono text-emerald-300 outline-none focus:ring-1 focus:ring-emerald-500/50 transition-all resize-none shadow-inner" spellCheck="false" />
                                </div>
                                <p className="text-[10px] text-gray-500 font-medium italic">Edit skema JSON di atas dan klik <strong className="font-bold text-gray-700">Sinkronkan</strong> untuk menerapkan perubahan ke editor visual.</p>
                            </div>
                        ) : !embedMode ? (
                            <FormBuilderCanvas
                                title={title}
                                setTitle={setTitle}
                                description={description}
                                setDescription={setDescription}
                                fields={fields}
                                theme={theme}
                                backgroundPattern={backgroundPattern}
                                setIsDirty={setIsDirty}
                                removeField={removeField}
                                updateField={updateField}
                                handleDragStart={handleDragStart}
                                handleDragOver={handleDragOver}
                                handleDrop={handleDrop}
                                draggedItemIndex={draggedItemIndex}
                                openDropdownId={openDropdownId}
                                setOpenDropdownId={setOpenDropdownId}
                                isQuizMode={isQuizMode}
                                addField={addField}
                                showAllTypes={showAllTypes}
                                setShowAllTypes={setShowAllTypes}
                                PATTERNS={PATTERNS}
                            />
                        ) : (
                            <div className="bg-white p-6 sm:p-10 rounded-3xl shadow-sm border border-gray-100 animate-in slide-in-from-bottom-4 duration-500">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                                    <div className="space-y-1">
                                        <div className="flex items-center gap-3 text-gray-900 font-black text-xl">
                                            <div className="bg-purple-100 p-2 rounded-xl text-purple-600"><Code size={20} /></div>
                                            <span>G-Embed Hybrid</span>
                                        </div>
                                        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest pl-1">Impor Struktur Google Form</p>
                                    </div>
                                    <div className="flex items-center gap-2 px-3 py-1.5 bg-purple-50 rounded-full text-[10px] font-black text-purple-600 uppercase w-fit">
                                        <Globe size={10} /> Live Sync Active
                                    </div>
                                </div>

                                <p className="text-sm text-gray-500 leading-relaxed font-bold mb-8 max-w-2xl">
                                    Tempelkan tautan **Google Form** Anda di bawah ini. Sistem akan secara otomatis membedah struktur pertanyaan dan menyiapkannya untuk diolah oleh mesin kami.
                                </p>

                                <div className="space-y-4">
                                    <div className="flex flex-col sm:flex-row gap-3">
                                        <div className="relative flex-1 group">
                                            <input
                                                type="text"
                                                value={importUrl}
                                                onChange={(e) => setImportUrl(e.target.value)}
                                                placeholder="https://docs.google.com/forms/d/..."
                                                className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-4 text-sm font-medium outline-none focus:ring-4 focus:ring-purple-100 focus:border-purple-400 transition-all placeholder-gray-300"
                                            />
                                        </div>
                                        <button
                                            onClick={handleImport}
                                            disabled={importLoading || !importUrl}
                                            className="w-full sm:w-auto bg-purple-600 hover:bg-purple-700 text-white px-10 py-4 sm:py-0 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all shadow-lg shadow-purple-100 active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
                                        >
                                            {importLoading ? (
                                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                            ) : (
                                                <>Mulai Impor <Sparkles size={12} /></>
                                            )}
                                        </button>
                                    </div>
                                    <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-start gap-3">
                                        <div className="p-1 bg-amber-200 rounded-lg text-amber-700 mt-0.5"><Sparkles size={12} /></div>
                                        <p className="text-[10px] text-amber-700 font-bold leading-relaxed">
                                            Pastikan Google Form dalam status **Publik** atau sudah mendapatkan izin akses untuk hasil impor yang maksimal.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div >
    );
}
