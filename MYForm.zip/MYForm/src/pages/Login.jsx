import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Layers, Eye, EyeOff } from 'lucide-react';

export default function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const { login } = useAuth();
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        const res = await login(username, password);
        setLoading(false);

        if (res.success) {
            navigate('/');
        } else {
            setError(res.error || 'Terjadi kesalahan saat masuk.');
        }
    };

    return (
        <div className="w-full">
            <form className="space-y-6" onSubmit={handleLogin}>
                {error && (
                    <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-2xl text-sm font-medium animate-in fade-in zoom-in-95 duration-200">
                        {error}
                    </div>
                )}
                <div>
                    <label className="block text-sm font-semibold text-gray-700 uppercase tracking-widest text-[10px] mb-2 px-1">USERNAME</label>
                    <div className="mt-1">
                        <input
                            type="text"
                            required
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="appearance-none block w-full px-4 py-4 bg-white border border-gray-200 rounded-2xl lg:shadow-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 sm:text-sm transition-all font-medium"
                            placeholder="Ketik username Anda..."
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-semibold text-gray-700 uppercase tracking-widest text-[10px] mb-2 px-1">KATA SANDI</label>
                    <div className="mt-1 relative group">
                        <input
                            type={showPassword ? "text" : "password"}
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="appearance-none block w-full px-4 py-4 pr-12 bg-white border border-gray-200 rounded-2xl lg:shadow-sm placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 sm:text-sm transition-all font-medium"
                            placeholder="••••••••"
                        />
                        <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute inset-y-0 right-0 pr-4 flex items-center justify-center text-gray-400 hover:text-blue-600 transition-colors focus:outline-none"
                        >
                            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                    </div>
                </div>

                <div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex justify-center py-4 px-4 border border-transparent rounded-2xl lg:shadow-xl lg:shadow-blue-200 text-xs font-black uppercase tracking-widest text-white bg-blue-600 hover:bg-blue-700 active:scale-[0.98] outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-blue-300 disabled:lg:shadow-none transition-all"
                    >
                        {loading ? 'Memeriksa Kredensial...' : 'Masuk Sistem'}
                    </button>
                </div>
            </form>

            <div className="mt-10 text-center text-xs">
                <span className="text-gray-400 font-bold uppercase tracking-widest">Belum punya akun? </span>
                <Link to="/daftar" className="font-black text-blue-600 hover:underline underline-offset-4 transition-all">
                    Daftar sekarang
                </Link>
            </div>
        </div>
    );
}
