import React from 'react';

// Custom pattern classes as defined in index.css
const PATTERN_MAP = {
    grid: 'pattern-grid',
    polkadot: 'pattern-polkadot',
    waves: 'pattern-waves',
    zigzag: 'pattern-zigzag',
    none: 'pattern-none'
};

const THEME_GRADIENT_MAP = {
    blue: 'from-indigo-50 to-blue-100',
    green: 'from-emerald-50 to-emerald-100',
    red: 'from-rose-50 to-rose-100',
    orange: 'from-orange-50 to-orange-100',
    dark: 'from-gray-100 to-gray-200',
};

// Layout fleksibel dan responsif untuk Public Form Visitor
const PublicLayout = ({ children, theme = 'blue' }) => {
    const gradientClass = THEME_GRADIENT_MAP[theme] || THEME_GRADIENT_MAP['blue'];

    return (
        <div className={`min-h-screen bg-gradient-to-br ${gradientClass} texture-noise flex justify-center py-10 px-4 md:px-8 transition-all duration-500 font-sans`}>
            <div className="w-full max-w-3xl mb-10 h-max animate-in fade-in slide-in-from-bottom-4 duration-700">
                {children}
            </div>
        </div>
    );
};

export default PublicLayout;
