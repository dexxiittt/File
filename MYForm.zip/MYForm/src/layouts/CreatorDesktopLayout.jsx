import React, { useState, useEffect, Suspense } from 'react';
import Pusher from 'pusher-js';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, PenTool, LogOut, BookOpen, Coffee, Settings, ShieldAlert, X, Bell, Loader2 } from 'lucide-react';
import * as PusherBeams from '@pusher/push-notifications-web';
import BottomSheet from '../components/BottomSheet';

const InLayoutLoader = () => (
    <div className="flex h-full w-full min-h-[60vh] flex-col items-center justify-center space-y-4">
        <Loader2 className="animate-spin h-10 w-10 text-blue-600" />
        <p className="text-gray-400 font-bold uppercase tracking-widest text-xs animate-pulse">Memuat Komponen...</p>
    </div>
);

const CreatorDesktopLayout = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const [toast, setToast] = useState(null);
    const [isLogoutModalOpen, setIsLogoutModalOpen] = useState(false);
    const [adminNotify, setAdminNotify] = useState(0);

    useEffect(() => {
        if (!user || !user.username) return;

        let pusher = null;
        let userChannel = null;
        let adminChannel = null;

        try {
            pusher = new Pusher(import.meta.env.VITE_PUSHER_KEY || '0302a51d1ad8ee4a2dc6', {
                cluster: import.meta.env.VITE_PUSHER_CLUSTER || 'ap1'
            });

            // Channel Pribadi (Response Baru)
            userChannel = pusher.subscribe(user.username);
            userChannel.bind('new-response', (data) => {
                setToast({
                    title: 'Data Baru Masuk!',
                    message: `Ada tanggapan baru di formulir: ${data.formTitle}`
                });
                setTimeout(() => setToast(null), 5000);
            });

            // Channel Admin (Registrasi Baru)
            if (user.isAdmin) {
                adminChannel = pusher.subscribe('admin-channel');
                adminChannel.bind('new-registration', (data) => {
                    if (window.location.pathname !== '/admin') {
                        setAdminNotify(prev => prev + 1);
                        setToast({
                            title: 'Pendaftar Baru!',
                            message: `User @${data.username} sedang menunggu persetujuan Anda.`
                        });
                        setTimeout(() => setToast(null), 5000);

                        const isPushEnabled = localStorage.getItem('admin_notifications_enabled') === 'true';
                        // User commit: Remove document visibility constraint to ensure native admin notifications always fire
                        if (isPushEnabled && 'Notification' in window && Notification.permission === 'granted') {
                            navigator.serviceWorker.ready.then(registration => {
                                registration.showNotification('Pendaftar Baru!', {
                                    body: `@${data.username} menunggu persetujuan.`,
                                    icon: '/icon-192.png',
                                    badge: '/icon-192.png',
                                    tag: 'new-reg-' + data.username,
                                    data: {
                                        targetUsername: data.username,
                                        username: user.username,
                                        token: user.token,
                                        gasUrl: import.meta.env.VITE_GAS_URL
                                    },
                                    actions: [
                                        { action: 'approve', title: 'Terima' },
                                        { action: 'reject', title: 'Tolak' }
                                    ]
                                });
                            });
                        }
                    }
                });
            }
        } catch (error) {
            console.error('[Pusher Layout Debug] Init failed:', error);
        }

        return () => {
            if (userChannel) {
                userChannel.unbind_all();
                pusher.unsubscribe(user.username);
            }
            if (adminChannel) {
                adminChannel.unbind_all();
                pusher.unsubscribe('admin-channel');
            }
            if (pusher) pusher.disconnect();
        };
    }, [user]);

    // Pusher Beams Integration for Background Notifications (PENTING: JANGAN DIHAPUS)
    useEffect(() => {
        let beamsClient = null;
        const initializeBeams = async () => {
            try {
                const instanceId = import.meta.env.VITE_BEAMS_INSTANCE_ID;
                if (!user || !user.isAdmin || !instanceId || instanceId === 'PASTE_YOUR_BEAMS_INSTANCE_ID_HERE') return;

                const isNotifyEnabled = localStorage.getItem('admin_notifications_enabled') === 'true';
                if (!isNotifyEnabled) return;

                const BeamsSDK = PusherBeams?.default || PusherBeams;
                if (!BeamsSDK || !BeamsSDK.Client) return;

                beamsClient = new BeamsSDK.Client({ instanceId });

                const tokenProvider = new BeamsSDK.TokenProvider({
                    url: "/api/beams-auth",
                    queryParams: { user_id: "admin-broadcast" }
                });

                await beamsClient.start();
                await beamsClient.setUserId("admin-broadcast", tokenProvider);
                console.log('[Beams] Admin background notifications active');
            } catch (error) {
                console.error('[Beams] Init failed:', error);
            }
        };

        initializeBeams();
    }, [user?.isAdmin]);

    // Send credentials to Service Worker for Background Actions
    useEffect(() => {
        if (!user || !user.isAdmin || !navigator.serviceWorker?.controller) return;

        const gasUrl = localStorage.getItem('customGasUrl') || import.meta.env.VITE_GAS_URL;
        const token = user.token || localStorage.getItem('formBuilderToken');

        navigator.serviceWorker.controller.postMessage({
            type: 'SET_ADMIN_CREDENTIALS',
            payload: {
                username: user.username,
                token: token,
                gasUrl: gasUrl
            }
        });
    }, [user?.username, user?.isAdmin]);

    // Reset notification if entering admin panel
    useEffect(() => {
        if (location.pathname === '/admin') {
            setAdminNotify(0);
        }
    }, [location.pathname]);

    const handleLogout = () => {
        setIsLogoutModalOpen(true);
    };

    const confirmLogout = () => {
        logout();
        navigate('/login');
    };

    const menuItems = [
        { path: '/', label: 'Dashboard', icon: LayoutDashboard },
        { path: '/builder', label: 'Buat Form', icon: PenTool },
        { path: '/docs', label: 'Panduan', icon: BookOpen }
    ];

    if (user?.isAdmin) {
        menuItems.push({
            path: '/admin',
            label: 'Admin Panel',
            icon: ShieldAlert,
            badge: adminNotify > 0 ? adminNotify : null
        });
    }

    menuItems.push(
        { path: '/settings', label: 'Setelan', icon: Settings },
        { path: '/coffee', label: 'Dukung', icon: Coffee }
    );

    return (
        <div className="flex h-screen bg-gray-50 text-gray-900 font-sans relative">
            {/* Sidebar Asli - Dikembalikan Sesuai Request */}
            <aside className="w-64 bg-white/80 backdrop-blur-md shadow-2xl border-r border-gray-100 flex flex-col items-center py-6 transition-all duration-300 z-10">
                <h1 className="text-2xl font-black tracking-tight bg-gradient-to-br from-blue-600 to-indigo-600 bg-clip-text text-transparent mb-1">
                    Form Architect
                </h1>
                <span className="text-[9px] font-black tracking-widest uppercase bg-gradient-to-r from-indigo-500 to-indigo-500 text-white px-2 py-0.5 rounded-full mb-12 inline-block">v3.4.0 PRO</span>
                <nav className="flex-1 w-full px-5 space-y-2">
                    {menuItems.map((item) => {
                        const isActive = location.pathname === item.path;
                        const Icon = item.icon;
                        return (
                            <Link
                                key={item.path}
                                to={item.path}
                                className={`flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 font-medium relative ${isActive
                                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 translate-x-1'
                                    : 'hover:bg-gray-100 text-gray-600 hover:text-gray-900'
                                    }`}
                            >
                                <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
                                <span className="flex-1">{item.label}</span>
                                {item.badge && (
                                    <span className="bg-rose-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full min-w-[18px] text-center shadow-lg shadow-rose-200">
                                        {item.badge}
                                    </span>
                                )}
                            </Link>
                        );
                    })}
                </nav>

                <div className="w-full px-5 pb-4 border-t border-gray-100 pt-6 mt-auto">
                    <div className="flex items-center justify-between mb-5 px-3 bg-gray-50/50 py-3 rounded-xl border border-gray-100">
                        <div className="flex flex-col">
                            <span className="text-xs text-gray-400 font-medium uppercase tracking-wider">Kreator Aktif</span>
                            <span className="font-bold text-gray-800 truncate max-w-[140px]">{user?.username}</span>
                        </div>
                    </div>
                    <button
                        onClick={() => setIsLogoutModalOpen(true)}
                        className="group flex items-center justify-center w-full space-x-2 py-3 px-4 rounded-xl text-rose-600 bg-rose-50 hover:bg-rose-100 transition-all duration-300 font-semibold border border-rose-100 hover:shadow-md"
                    >
                        <LogOut size={18} className="group-hover:-translate-x-1 transition-transform" />
                        <span>Keluar Sesi</span>
                    </button>
                </div>
            </aside>

            {/* Main Content */}
            <main className="flex-1 overflow-auto bg-[#F8FAFC] p-8">
                <div className="max-w-6xl mx-auto h-full animate-in fade-in duration-200">
                    <Suspense fallback={<InLayoutLoader />}>
                        <Outlet />
                    </Suspense>
                </div>
            </main>

            {/* Toast Notification */}
            {toast && (
                <div className="fixed bottom-6 right-6 bg-white border-l-4 border-indigo-500 shadow-2xl rounded-2xl p-4 z-50 animate-in slide-in-from-right-8 flex items-start gap-4 max-w-sm ring-1 ring-gray-100">
                    <div className="bg-indigo-50 p-2.5 rounded-full text-indigo-600 mt-0.5">
                        <Bell size={20} />
                    </div>
                    <div className="flex-1 pt-1">
                        <h4 className="text-sm font-black text-gray-900">{toast.title}</h4>
                        <p className="text-xs font-medium text-gray-500 mt-1 leading-relaxed">{toast.message}</p>
                    </div>
                    <button onClick={() => setToast(null)} className="p-1.5 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors">
                        <X size={16} strokeWidth={3} />
                    </button>
                </div>
            )}

            {/* Modal Konfirmasi Logout */}
            <BottomSheet isOpen={isLogoutModalOpen} onClose={() => setIsLogoutModalOpen(false)} title="Konfirmasi Keluar">
                <p className="text-sm text-gray-500 mb-6 font-medium leading-relaxed">
                    Apakah Anda yakin ingin keluar dari sesi saat ini? Anda membutuhkan username dan kata sandi untuk masuk kembali.
                </p>
                <div className="flex gap-3 mt-4">
                    <button onClick={() => setIsLogoutModalOpen(false)} className="flex-1 px-4 py-3 bg-gray-100 text-gray-600 rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-gray-200 transition-all active:scale-95">Batal</button>
                    <button onClick={confirmLogout} className="flex-1 px-4 py-3 bg-rose-600 text-white rounded-xl text-[11px] font-black uppercase tracking-widest hover:bg-rose-700 transition-all shadow-md active:scale-95">Ya, Keluar</button>
                </div>
            </BottomSheet>
        </div>
    );
};

export default CreatorDesktopLayout;
