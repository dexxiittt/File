import React, { Suspense, useState, useEffect } from 'react';
import Pusher from 'pusher-js';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, PenTool, LogOut, BookOpen, Settings, Coffee, ShieldAlert, Loader2 } from 'lucide-react';
import * as PusherBeams from '@pusher/push-notifications-web';

const InLayoutLoader = () => (
    <div className="flex h-full w-full min-h-[60vh] flex-col items-center justify-center space-y-4">
        <Loader2 className="animate-spin h-10 w-10 text-blue-600" />
        <p className="text-gray-400 font-bold uppercase tracking-widest text-xs animate-pulse">Memuat Komponen...</p>
    </div>
);

const CreatorMobileLayout = () => {
    const { logout, user } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    const [adminNotify, setAdminNotify] = useState(0);

    useEffect(() => {
        if (!user || !user.username) return;

        let pusher = null;
        let adminChannel = null;

        try {
            pusher = new Pusher(import.meta.env.VITE_PUSHER_KEY || '0302a51d1ad8ee4a2dc6', {
                cluster: import.meta.env.VITE_PUSHER_CLUSTER || 'ap1'
            });

            // Channel Admin (Registrasi Baru)
            if (user.isAdmin) {
                adminChannel = pusher.subscribe('admin-channel');
                adminChannel.bind('new-registration', (data) => {
                    if (window.location.pathname !== '/admin') {
                        setAdminNotify(prev => prev + 1);

                        // Native OS Notification (Background)
                        const isPushEnabled = localStorage.getItem('admin_notifications_enabled') === 'true';
                        if (isPushEnabled && 'Notification' in window && document.visibilityState === 'hidden' && Notification.permission === 'granted') {
                            navigator.serviceWorker.ready.then(registration => {
                                registration.showNotification('Pendaftar Baru!', {
                                    body: `@${data.username} menunggu persetujuan.`,
                                    icon: '/qris.png',
                                    badge: '/qris.png',
                                    tag: 'new-reg-' + data.username,
                                    data: {
                                        targetUsername: data.username,
                                        username: user.username,
                                        token: user.token,
                                        gasUrl: import.meta.env.VITE_GAS_URL
                                    },
                                    actions: [
                                        { action: 'approve', title: 'Terima' },
                                        { action: 'reject', title: 'Tolak' }
                                    ]
                                });
                            });
                        }
                    }
                });
            }
        } catch (error) {
            console.error('[Pusher Mobile Layout Debug] Init failed:', error);
        }

        return () => {
            if (adminChannel) {
                adminChannel.unbind_all();
                pusher.unsubscribe('admin-channel');
            }
            if (pusher) pusher.disconnect();
        };
    }, [user]);

    // Pusher Beams Integration for Background Notifications
    useEffect(() => {
        let beamsClient = null;
        const initializeBeams = async () => {
            try {
                const instanceId = import.meta.env.VITE_BEAMS_INSTANCE_ID;
                if (!user || !user.isAdmin || !instanceId || instanceId === 'PASTE_YOUR_BEAMS_INSTANCE_ID_HERE') return;

                const isNotifyEnabled = localStorage.getItem('admin_notifications_enabled') === 'true';
                if (!isNotifyEnabled) return;

                const BeamsSDK = PusherBeams?.default || PusherBeams;
                if (!BeamsSDK || !BeamsSDK.Client) return;

                beamsClient = new BeamsSDK.Client({ instanceId });

                const tokenProvider = new BeamsSDK.TokenProvider({
                    url: "/api/beams-auth",
                    queryParams: { user_id: "admin-broadcast" }
                });

                await beamsClient.start();
                await beamsClient.setUserId("admin-broadcast", tokenProvider);
                console.log('[Beams] Admin background notifications active (Mobile)');
            } catch (error) {
                console.error('[Beams] Init failed (Mobile):', error);
            }
        };

        initializeBeams();
    }, [user?.isAdmin]);

    // Send credentials to Service Worker for Background Actions
    useEffect(() => {
        if (!user || !user.isAdmin || !navigator.serviceWorker?.controller) return;

        const gasUrl = localStorage.getItem('customGasUrl') || import.meta.env.VITE_GAS_URL;
        const token = user.token || localStorage.getItem('formBuilderToken');

        navigator.serviceWorker.controller.postMessage({
            type: 'SET_ADMIN_CREDENTIALS',
            payload: {
                username: user.username,
                token: token,
                gasUrl: gasUrl
            }
        });
    }, [user?.username, user?.isAdmin]);

    // Reset notification if entering admin panel

    // Reset notification if entering admin panel
    useEffect(() => {
        if (location.pathname === '/admin') {
            setAdminNotify(0);
        }
    }, [location.pathname]);

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    const navItems = [
        { path: '/', label: 'Dasbor', icon: LayoutDashboard },
        { path: '/builder', label: 'Buat Baru', icon: PenTool },
        { path: '/docs', label: 'Panduan', icon: BookOpen }
    ];

    if (user?.isAdmin) {
        navItems.push({
            path: '/admin',
            label: 'Admin',
            icon: ShieldAlert,
            badge: adminNotify > 0 ? adminNotify : null
        });
    }

    return (
        <div className="flex flex-col h-screen bg-gray-50 text-gray-900 font-sans">
            {/* Header Mobile */}
            <header className="bg-white border-b border-gray-200 py-3 px-4 flex justify-between items-center z-10 shrink-0">
                <div>
                    <h1 className="text-xl font-bold text-blue-600 tracking-tight">
                        Form Architect
                    </h1>
                    <p className="text-[9px] font-black tracking-widest uppercase text-indigo-500">v3.4.0 PRO</p>
                    <p className="text-xs text-gray-500 truncate max-w-[150px] font-medium">{user?.username}</p>
                </div>
                <Link
                    to="/settings"
                    className="text-gray-600 p-2 rounded-full bg-gray-100 active:bg-gray-200 transition-colors"
                >
                    <Settings size={18} />
                </Link>
            </header>

            {/* Main Content Area */}
            <main className="flex-1 overflow-auto bg-gray-50 p-4 pb-20">
                <Suspense fallback={<InLayoutLoader />}>
                    <Outlet />
                </Suspense>
            </main>

            <nav className="bg-white border-t border-gray-200 fixed bottom-0 w-full flex justify-around py-2 px-2 z-10 pb-safe shrink-0">
                {navItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = location.pathname === item.path;

                    return (
                        <Link
                            key={item.path}
                            to={item.path}
                            className={`flex flex-col items-center p-2 rounded-xl transition-colors duration-200 relative ${isActive
                                ? 'text-blue-600 bg-blue-50'
                                : 'text-gray-500 active:bg-gray-50'
                                }`}
                            style={{ width: `${100 / navItems.length}%` }}
                        >
                            <div className="relative">
                                <Icon size={22} className="mb-0.5" strokeWidth={isActive ? 2.5 : 2} />
                                {item.badge && (
                                    <span className="absolute -top-1 -right-1.5 bg-rose-500 text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                                        {item.badge}
                                    </span>
                                )}
                            </div>
                            <span className="text-[10px] font-bold">{item.label}</span>
                        </Link>
                    );
                })}
            </nav>
        </div>
    );
};

export default CreatorMobileLayout;
