import React from 'react';
import { Palette, X, Sparkles, Lock, Shield, Database, ExternalLink, Globe } from 'lucide-react';

export const PATTERNS = [
    { label: 'Tidak Ada', value: 'none', className: '' },
    { label: 'Titik', value: 'dots', className: 'pattern-dots' },
    { label: 'Grid', value: 'grid', className: 'pattern-grid' },
    { label: 'Waves', value: 'waves', className: 'pattern-waves' },
    { label: 'Zigzag', value: 'zigzag', className: 'pattern-zigzag' }
];

export default function FormBuilderSidebar({
    theme, setTheme,
    backgroundPattern, setBackgroundPattern,
    isQuizMode, setIsQuizMode,
    requireLogin, setRequireLogin,
    limitOneResponse, setLimitOneResponse,
    confirmationMessage, setConfirmationMessage,
    customSlug, setCustomSlug,
    setShowSettings,
    aiPrompt, setAiPrompt,
    aiLoading, handleAiGenerate,
    userSpreadsheetId, googleToken
}) {
    return (
        <div className="hidden lg:block space-y-6 lg:col-span-4 h-fit">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 space-y-6">
                <div className="flex items-center justify-between">
                    <h2 className="text-xs font-black text-gray-900 uppercase tracking-[0.2em] flex items-center gap-2">
                        <Palette size={14} /> Pengaturan Gaya
                    </h2>
                    <button className="lg:hidden" onClick={() => setShowSettings(false)}><X size={18} /></button>
                </div>

                {/* Bagian: Tautan Custom — Langsung di Atas */}
                <div className="space-y-4">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">ALAMAT TAUTAN (CUSTOM)</label>
                    <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3 focus-within:ring-4 focus-within:ring-indigo-100 focus-within:border-indigo-500 transition-all">
                        <span className="text-gray-400 font-bold text-[10px] uppercase tracking-tighter">myform.id/f/</span>
                        <input
                            type="text"
                            value={customSlug}
                            onChange={(e) => setCustomSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                            placeholder="slug-bebas"
                            className="flex-1 bg-transparent border-none outline-none text-xs font-black text-gray-900 placeholder-gray-300 uppercase tracking-widest"
                        />
                    </div>
                </div>

                {/* Bagian: Pesan Konfirmasi — Tepat di Bawah Tautan Custom */}
                <div className="space-y-4 pt-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">PESAN KONFIRMASI</label>
                    <textarea
                        value={confirmationMessage}
                        onChange={(e) => setConfirmationMessage(e.target.value)}
                        placeholder="Tulis pesan terima kasih Anda..."
                        className="w-full bg-gray-50 border border-gray-200 rounded-2xl p-4 text-xs text-gray-700 placeholder-gray-400 outline-none focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 transition-all resize-none h-24 font-medium"
                    />
                </div>

                {/* Bagian: Tema Warna */}
                <div className="space-y-4 pt-4 border-t border-gray-100">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">TEMA WARNA</label>
                    <div className="grid grid-cols-5 gap-2">
                        {['blue', 'purple', 'green', 'rose', 'orange'].map(c => (
                            <button key={c} onClick={() => setTheme(c)} className={`h-10 rounded-xl transition-all border-2 ${theme === c ? 'ring-2 ring-offset-2 ring-indigo-500 scale-90 border-transparent' : 'border-transparent opacity-50 hover:opacity-100'} ${c === 'blue' ? 'bg-indigo-500' : c === 'purple' ? 'bg-purple-500' : c === 'green' ? 'bg-green-500' : c === 'rose' ? 'bg-rose-500' : 'bg-orange-500'}`} />
                        ))}
                    </div>
                </div>

                {/* Bagian: Pola Latar Belakang */}
                <div className="space-y-4">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">POLA LATAR BELAKANG</label>
                    <div className="grid grid-cols-2 gap-2">
                        {PATTERNS.map(p => (
                            <button key={p.value} onClick={() => setBackgroundPattern(p.value)} className={`flex items-center justify-between p-3 rounded-xl border-2 transition-all ${backgroundPattern === p.value ? 'bg-indigo-50 border-blue-200' : 'bg-gray-50 border-transparent opacity-50 hover:opacity-100 hover:scale-[1.02]'}`}>
                                <span className="text-xs font-bold text-gray-700">{p.label}</span>
                                <div className={`w-8 h-8 rounded-lg ${p.className} border border-gray-200`} />
                            </button>
                        ))}
                    </div>
                </div>

                {/* Mode Kuis */}
                <div className="space-y-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                        <div className="flex flex-col pr-2">
                            <span className="text-xs font-black text-gray-900 uppercase tracking-widest">Mode Kuis</span>
                            <span className="text-[10px] text-gray-400 font-bold leading-tight">Aktifkan skor & kunci jawaban</span>
                        </div>
                        <button onClick={() => setIsQuizMode(!isQuizMode)} className={`w-12 h-6 rounded-full transition-all relative flex-shrink-0 ${isQuizMode ? 'bg-orange-500' : 'bg-gray-200'}`}>
                            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isQuizMode ? 'left-7' : 'left-1'}`} />
                        </button>
                    </div>
                </div>

                {/* Keamanan Pengisian */}
                <div className="space-y-4 pt-4 border-t border-gray-100">
                    <div className="flex items-center gap-2 mb-2">
                        <Shield size={14} className="text-gray-400" />
                        <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">KEAMANAN PENGISIAN</span>
                    </div>

                    <div className="flex items-center justify-between">
                        <div className="flex flex-col pr-2">
                            <span className="text-xs font-black text-gray-900 uppercase tracking-widest">Wajib Login</span>
                            <span className="text-[10px] text-gray-400 font-bold leading-tight">Berlaku khusus tamu</span>
                        </div>
                        <button onClick={() => setRequireLogin(!requireLogin)} className={`w-12 h-6 rounded-full transition-all relative flex-shrink-0 ${requireLogin ? 'bg-rose-500' : 'bg-gray-200'}`}>
                            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all flex items-center justify-center ${requireLogin ? 'left-7 text-rose-500' : 'left-1 text-gray-400'}`}>
                                {requireLogin && <Lock size={8} strokeWidth={3} />}
                            </div>
                        </button>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                        <div className="flex flex-col pr-2">
                            <span className="text-xs font-black text-gray-900 uppercase tracking-widest">Batas 1 Tanggapan</span>
                            <span className="text-[10px] text-gray-400 font-bold leading-tight">Mencegah spam form ganda</span>
                        </div>
                        <button onClick={() => setLimitOneResponse(!limitOneResponse)} className={`w-12 h-6 rounded-full transition-all relative flex-shrink-0 ${limitOneResponse ? 'bg-indigo-500' : 'bg-gray-200'}`}>
                            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${limitOneResponse ? 'left-7' : 'left-1'}`} />
                        </button>
                    </div>
                </div>

                {/* Penyimpanan Data */}
                {(googleToken || userSpreadsheetId) && (
                    <div className="space-y-4 pt-4 border-t border-gray-100">
                        <div className="flex items-center gap-2 mb-2">
                            <Database size={14} className="text-gray-400" />
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">PENYIMPANAN DATA</span>
                        </div>

                        <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100 space-y-3">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-2 text-emerald-600">
                                    <Globe size={14} />
                                    <span className="text-[10px] font-black uppercase tracking-widest">Google Drive</span>
                                </div>
                                <div className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-lg text-[8px] font-black uppercase">Aktif</div>
                            </div>

                            {userSpreadsheetId ? (
                                <div className="space-y-3">
                                    <p className="text-[10px] text-gray-500 font-bold leading-tight line-clamp-1">ID: {userSpreadsheetId}</p>
                                    <a
                                        href={`https://docs.google.com/spreadsheets/d/${userSpreadsheetId}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="w-full flex items-center justify-center gap-2 py-2.5 bg-white border border-gray-200 rounded-xl text-[9px] font-black text-indigo-600 uppercase tracking-widest hover:bg-indigo-50 transition-all shadow-sm active:scale-95"
                                    >
                                        <ExternalLink size={12} /> Buka Spreadsheet
                                    </a>
                                </div>
                            ) : (
                                <p className="text-[9px] text-gray-400 font-bold leading-relaxed italic">
                                    File baru akan dibuat otomatis saat Anda pertama kali menyimpan formulir ini.
                                </p>
                            )}
                        </div>
                    </div>
                )}
            </div>

            {/* Magic AI Engine */}
            <div className="hidden lg:block bg-gradient-to-br from-blue-900 to-indigo-900 p-6 rounded-2xl shadow-xl space-y-4">
                <h2 className="text-xs font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
                    <Sparkles size={14} className="text-white" /> Magic AI Engine
                </h2>
                <textarea value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)} placeholder="Tulis instruksi formulir Anda..." className="w-full bg-white/10 border border-white/20 rounded-2xl p-4 text-sm text-white placeholder-white/60 outline-none focus:ring-2 focus:ring-white/50 transition-all resize-none h-24 font-medium" />
                <button onClick={handleAiGenerate} disabled={aiLoading || !aiPrompt} className="w-full bg-white text-blue-900 hover:bg-indigo-50 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all shadow-md active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2">
                    {aiLoading ? 'Magic in progress...' : 'Mulai Sekarang'}
                </button>
            </div>
        </div>
    );
}
