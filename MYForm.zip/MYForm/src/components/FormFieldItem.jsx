import React from 'react';
import {
    Split, X, Layout, Trash2, GripVertical, ChevronDown,
    CheckSquare, List, Hash, Mail, AlignLeft, Type,
    Sliders, Calendar, Clock, Upload, Zap, Check, Plus
} from 'lucide-react';

export const FIELD_TYPES = [
    'Short Text', 'Paragraph', 'Email', 'Number',
    'Multiple Choice', 'Checkboxes', 'Dropdown',
    'Linear Scale', 'Date', 'Time', 'File Upload',
    'Section Header', 'Page Break'
];

export default function FormFieldItem({
    field, index, fields,
    removeField, updateField,
    handleDragStart, handleDragOver, handleDrop, draggedItemIndex,
    openDropdownId, setOpenDropdownId,
    isQuizMode
}) {
    if (field.type === 'Page Break') {
        const pageNum = fields.filter((f, i) => i < index && f.type === 'Page Break').length + 2;
        return (
            <div key={field.id} className="relative py-8 group animate-in slide-in-from-bottom-2 duration-300">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t-2 border-dashed border-blue-100 group-hover:border-blue-300 transition-all" /></div>
                <div className="relative flex justify-center">
                    <div className="bg-indigo-600 px-6 py-2 rounded-full shadow-lg flex items-center gap-2 text-white text-[10px] font-black uppercase tracking-[0.2em] transform transition-all group-hover:scale-110">
                        <Split size={14} />
                        <span>Halaman {pageNum} dimulai di sini</span>
                        <button onClick={() => removeField(field.id)} className="ml-2 p-1 hover:bg-white/20 rounded-lg"><X size={12} /></button>
                    </div>
                </div>
            </div>
        );
    }

    if (field.type === 'Section Header') {
        return (
            <div key={field.id} className="group bg-indigo-50/50 border-2 border-blue-100 rounded-2xl p-8 transition-all hover:bg-white hover:shadow-2xl hover:border-blue-300 relative">
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                        <div className="p-2 bg-indigo-600 rounded-xl text-white shadow-md"><Layout size={18} /></div>
                        <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">BAGIAN BARU</span>
                    </div>
                    <button onClick={() => removeField(field.id)} className="text-gray-300 hover:text-rose-500 p-2 rounded-xl transition-all hover:bg-rose-50"><Trash2 size={18} /></button>
                </div>
                <div className="space-y-4">
                    <input type="text" value={field.label} onChange={(e) => updateField(field.id, { label: e.target.value })} placeholder="Judul Bagian..." className="w-full bg-transparent border-none focus:ring-0 p-0 text-2xl font-black text-gray-900 placeholder-gray-300" />
                    <textarea value={field.helpText} onChange={(e) => updateField(field.id, { helpText: e.target.value })} placeholder="Deskripsi bagian (opsional)..." className="w-full bg-transparent border-none focus:ring-0 p-0 text-sm font-medium text-gray-500 placeholder-gray-200 resize-none min-h-[40px]" />
                </div>
            </div>
        );
    }

    const qNum = fields.filter((f, i) => i <= index && !['Section Header', 'Page Break'].includes(f.type)).length;

    return (
        <div
            key={field.id}
            draggable
            onDragStart={() => handleDragStart(index)}
            onDragOver={(e) => handleDragOver(e, index)}
            onDrop={handleDrop}
            className={`group bg-gray-50/50 border border-gray-100 rounded-2xl p-6 transition-all hover:bg-white hover:shadow-xl hover:border-blue-100 relative ${draggedItemIndex === index ? 'opacity-50 scale-[0.98]' : ''}`}
        >
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                    <div className="cursor-grab active:cursor-grabbing p-1 text-gray-300 hover:text-gray-500 transition-colors"><GripVertical size={18} /></div>
                    <span className="text-gray-400 font-black text-xs opacity-50">Q{qNum}</span>
                    <div className="relative">
                        <button onClick={() => setOpenDropdownId(openDropdownId === field.id ? null : field.id)} className="bg-white border border-gray-200 rounded-xl px-4 py-2 text-xs font-bold text-gray-700 outline-none shadow-sm hover:border-blue-400 transition-all flex items-center gap-2">
                            {field.type}
                            <ChevronDown size={14} className={`transition-transform duration-300 ${openDropdownId === field.id ? 'rotate-180' : ''}`} />
                        </button>
                        {openDropdownId === field.id && (
                            <>
                                <div className="fixed inset-0 z-40" onClick={() => setOpenDropdownId(null)} />
                                <div className="absolute top-full left-0 mt-2 w-56 bg-white border border-gray-100 rounded-2xl shadow-2xl p-2 z-50 animate-in zoom-in-95 duration-200">
                                    <div className="grid gap-1">
                                        {FIELD_TYPES.map(t => (
                                            <button key={t} onClick={() => { updateField(field.id, { type: t }); setOpenDropdownId(null); }} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${field.type === t ? 'bg-indigo-600 text-white' : 'text-gray-600 hover:bg-indigo-50'}`}>
                                                <div className={`p-1.5 rounded-lg ${field.type === t ? 'bg-white/20' : 'bg-gray-100'}`}>
                                                    {t === 'Short Text' && <Type size={14} />}
                                                    {t === 'Paragraph' && <AlignLeft size={14} />}
                                                    {t === 'Email' && <Mail size={14} />}
                                                    {t === 'Number' && <Hash size={14} />}
                                                    {t === 'Multiple Choice' && <List size={14} />}
                                                    {t === 'Checkboxes' && <CheckSquare size={14} />}
                                                    {t === 'Dropdown' && <ChevronDown size={14} />}
                                                    {t === 'Linear Scale' && <Sliders size={14} />}
                                                    {t === 'Date' && <Calendar size={14} />}
                                                    {t === 'Time' && <Clock size={14} />}
                                                    {t === 'File Upload' && <Upload size={14} />}
                                                    {t === 'Section Header' && <Layout size={14} />}
                                                    {t === 'Page Break' && <Split size={14} />}
                                                </div>
                                                {t}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </>
                        )}
                    </div>
                </div>
                <button onClick={() => removeField(field.id)} className="text-gray-300 hover:text-rose-500 p-2 rounded-xl transition-all"><Trash2 size={18} /></button>
            </div>

            <div className="space-y-4">
                <input type="text" value={field.label} onChange={(e) => updateField(field.id, { label: e.target.value })} className="w-full bg-transparent border-none focus:ring-0 p-0 text-xl font-bold text-gray-800 placeholder-gray-300 outline-none" placeholder="Tulis pertanyaan Anda..." />

                <div className="py-2 opacity-40 pointer-events-none select-none">
                    {field.type === 'Short Text' && <div className="h-2 w-1/2 bg-gray-200 rounded-full" />}
                    {field.type === 'Paragraph' && <div className="space-y-2"><div className="h-2 w-full bg-gray-200 rounded-full" /><div className="h-2 w-3/4 bg-gray-200 rounded-full" /></div>}
                    {field.type === 'Email' && <div className="h-2 w-1/3 bg-gray-200 rounded-full border-b border-gray-300" />}
                    {field.type === 'Number' && <div className="h-2 w-20 bg-gray-200 rounded-full" />}
                    {(field.type === 'Multiple Choice' || field.type === 'Checkboxes' || field.type === 'Dropdown') && (
                        <div className="space-y-2 mt-4 pointer-events-auto opacity-100">
                            {field.options.map((opt, i) => (
                                <div key={i} className="flex items-center gap-3">
                                    <div className={`w-4 h-4 rounded-full border-2 ${field.type === 'Checkboxes' ? 'rounded-md' : 'rounded-full'} border-gray-300`} />
                                    <input type="text" value={opt} onChange={(e) => { const newOpts = [...field.options]; newOpts[i] = e.target.value; updateField(field.id, { options: newOpts }); }} className="flex-1 text-sm text-gray-500 bg-transparent border-none p-0 focus:ring-0 outline-none" />
                                    <button onClick={() => updateField(field.id, { options: field.options.filter((_, idx) => idx !== i) })} className="text-rose-300 hover:text-rose-500"><X size={14} /></button>
                                </div>
                            ))}
                            <button onClick={() => updateField(field.id, { options: [...field.options, `Opsi ${field.options.length + 1}`] })} className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mt-2 flex items-center gap-2 hover:translate-x-1 transition-all"><Plus size={10} /> Tambah Opsi</button>
                        </div>
                    )}
                    {field.type === 'Linear Scale' && (
                        <div className="space-y-4 mt-4 pointer-events-auto opacity-100">
                            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 bg-gray-50/50 p-4 rounded-2xl border border-gray-100 transition-all">
                                <div className="flex-1 w-full">
                                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 block">Rentang Skala</label>
                                    <div className="flex items-center gap-3">
                                        <select value={field.min ?? 1} onChange={(e) => updateField(field.id, { min: parseInt(e.target.value) })} className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none cursor-pointer">
                                            <option value="0">0</option>
                                            <option value="1">1</option>
                                        </select>
                                        <span className="text-gray-400 font-bold text-xs">sampai</span>
                                        <select value={field.max ?? 5} onChange={(e) => updateField(field.id, { max: parseInt(e.target.value) })} className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs font-bold outline-none cursor-pointer">
                                            {[2, 3, 4, 5, 6, 7, 8, 9, 10].map(v => <option key={v} value={v}>{v}</option>)}
                                        </select>
                                    </div>
                                </div>
                                <div className="flex-[2] w-full space-y-3">
                                    <input type="text" placeholder="Label terendah..." value={field.minLabel ?? ''} onChange={(e) => updateField(field.id, { minLabel: e.target.value })} className="w-full bg-white border border-gray-100 rounded-xl px-4 py-2 text-xs outline-none" />
                                    <input type="text" placeholder="Label tertinggi..." value={field.maxLabel ?? ''} onChange={(e) => updateField(field.id, { maxLabel: e.target.value })} className="w-full bg-white border border-gray-100 rounded-xl px-4 py-2 text-xs outline-none" />
                                </div>
                            </div>
                        </div>
                    )}
                    {field.type === 'Date' && <div className="h-2 w-32 bg-gray-200 rounded-full" />}
                    {field.type === 'Time' && <div className="h-2 w-24 bg-gray-200 rounded-full" />}
                    {field.type === 'File Upload' && (
                        <div className="space-y-4">
                            <div className="h-10 w-full border-2 border-dashed border-gray-200 rounded-xl flex items-center justify-center text-[10px] font-bold text-gray-300">Google Drive</div>

                            {/* Toggle Limit Size */}
                            <div className="flex items-center justify-between bg-gray-50 p-4 rounded-xl border border-gray-100 mt-4">
                                <div>
                                    <h4 className="text-xs font-bold text-gray-800">Batasi Ukuran File</h4>
                                    <p className="text-[10px] text-gray-400 font-medium mt-0.5">Tolak otomatis jika ukuran file pemilih melebihi batas</p>
                                </div>
                                <button
                                    onClick={() => updateField(field.id, { limitFileSize: !field.limitFileSize, maxFileSize: field.maxFileSize || 10, maxFileSizeUnit: field.maxFileSizeUnit || 'MB' })}
                                    className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center justify-center rounded-full focus:outline-none transition-colors ${field.limitFileSize ? 'bg-indigo-600' : 'bg-gray-200'}`}
                                >
                                    <span className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${field.limitFileSize ? 'translate-x-[7px]' : '-translate-x-[7px]'}`} />
                                </button>
                            </div>

                            {field.limitFileSize && (
                                <div className="flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                                    <input
                                        type="number"
                                        value={field.maxFileSize || 10}
                                        onChange={(e) => updateField(field.id, { maxFileSize: parseInt(e.target.value) || 1 })}
                                        className="w-24 bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm font-bold text-gray-700 outline-none focus:border-indigo-500 shadow-sm"
                                        min="1"
                                    />
                                    <select
                                        value={field.maxFileSizeUnit || 'MB'}
                                        onChange={(e) => updateField(field.id, { maxFileSizeUnit: e.target.value })}
                                        className="bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm font-bold text-gray-700 outline-none focus:border-indigo-500 shadow-sm"
                                    >
                                        <option value="KB">KB</option>
                                        <option value="MB">MB</option>
                                    </select>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                {isQuizMode && (
                    <div className="mt-6 pt-6 border-t border-dashed border-gray-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label className="text-[10px] font-black text-orange-600 uppercase tracking-widest mb-2 block flex items-center gap-1"><Zap size={10} /> Poin Soal</label>
                            <input type="number" value={field.points || 0} onChange={(e) => updateField(field.id, { points: parseInt(e.target.value) || 0 })} className="w-full bg-white border border-orange-100 rounded-xl px-3 py-2 text-sm font-bold text-gray-700 outline-none shadow-sm" />
                        </div>
                        <div>
                            <label className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-2 block flex items-center gap-1"><Check size={10} /> Kunci Jawaban</label>
                            <input type="text" value={field.correctAnswer || ''} onChange={(e) => updateField(field.id, { correctAnswer: e.target.value })} placeholder="Jawaban benar..." className="w-full bg-white border border-blue-100 rounded-xl px-3 py-2 text-sm font-bold text-gray-700 outline-none shadow-sm" />
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
