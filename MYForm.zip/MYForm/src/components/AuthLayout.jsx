import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles } from 'lucide-react';
import { useLocation, useOutlet } from 'react-router-dom';
import { useMediaQuery } from '../hooks/useMediaQuery';

// Custom SVG Icon (Stack Layers)
const CustomLayersIcon = ({ size = 48, className = "" }) => (
    <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
    >
        <path d="M12 2L2 7l10 5 10-5-10-5z" />
        <path d="M2 17l10 5 10-5" />
        <path d="M2 12l10 5 10-5" />
    </svg>
);

const AuthLayout = () => {
    const location = useLocation();
    const outlet = useOutlet();

    // Check if it's desktop view (lg breakpoint in Tailwind is 1024px)
    const isDesktop = useMediaQuery('(min-width: 1024px)');

    const isLogin = location.pathname === '/login';
    const isRegister = location.pathname === '/daftar';
    const isVerify = location.pathname === '/verifikasi';

    const mode = isLogin ? 'login' : (isVerify ? 'verify' : 'register');

    const [delayedMode, setDelayedMode] = useState(mode);
    const [delayedOutlet, setDelayedOutlet] = useState(outlet);

    useEffect(() => {
        const timer = setTimeout(() => {
            setDelayedMode(mode);
            setDelayedOutlet(outlet);
        }, 160);
        return () => clearTimeout(timer);
    }, [mode, outlet]);

    const config = {
        login: {
            title: "Selamat Datang Kembali",
            description: "Masuk untuk mengelola dan merancang formulir instan Anda.",
            visualTitle: "Siap Merancang Hari Ini?",
            visualDesc: "Form Architect — Professional Edition"
        },
        register: {
            title: "Buat Akun Kreator",
            description: "Mulai petualangan Anda dalam membuat formulir cerdas dengan AI.",
            visualTitle: "Mari Bergabung!",
            visualDesc: "Bangun Form Impian dalam Sekejap"
        },
        verify: {
            title: "Verifikasi Identitas",
            description: "Langkah terakhir untuk mengaktifkan akses penuh Anda.",
            visualTitle: "Hampir Selesai",
            visualDesc: "Keamanan Akun Prioritas Kami"
        }
    };

    const current = config[delayedMode] || config.login;
    const springConfig = { type: 'spring', stiffness: 70, damping: 24, mass: 1 };

    return (
        <div className="min-h-screen w-full bg-white flex overflow-hidden font-sans relative">
            <div className="w-full flex relative overflow-hidden h-screen bg-slate-50 transition-all duration-500">

                {/* Visual Panel (Blue Gradient) */}
                {isDesktop && (
                    <motion.div
                        initial={false}
                        animate={{ x: isDesktop ? (isLogin ? '0%' : '100%') : '0%' }}
                        transition={springConfig}
                        className="hidden lg:flex absolute top-0 left-0 w-1/2 h-full bg-gradient-to-br from-indigo-700 via-blue-600 to-indigo-800 z-20 flex-col items-center justify-center p-20 text-white overflow-hidden shadow-2xl"
                    >
                        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-30">
                            <div className="absolute top-1/4 -right-20 w-80 h-80 bg-white/10 rounded-full blur-[100px]" />
                            <div className="absolute bottom-1/4 -left-20 w-80 h-80 bg-indigo-400/20 rounded-full blur-[100px]" />
                        </div>

                        <div className="relative z-30 text-center flex flex-col items-center justify-center w-full max-w-sm">
                            <motion.div
                                initial={{ scale: 0.9, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                className="bg-white/10 backdrop-blur-3xl p-5 rounded-[2.5rem] inline-block mb-10 border border-white/20 shadow-xl text-white"
                            >
                                <CustomLayersIcon size={48} />
                            </motion.div>

                            <div className="relative w-full flex flex-col items-center min-h-[140px]">
                                <AnimatePresence mode="wait">
                                    <motion.div
                                        key={delayedMode}
                                        initial={{ opacity: 0, scale: 0.9, y: 15 }}
                                        animate={{ opacity: 1, scale: 1, y: 0 }}
                                        exit={{ opacity: 0, scale: 0.9, y: -15 }}
                                        transition={{ duration: 0.35, ease: "easeInOut" }}
                                        className="flex flex-col items-center justify-center space-y-6"
                                    >
                                        <h2 className="text-4xl xl:text-5xl font-black leading-[1.15] tracking-tighter text-white drop-shadow-md">
                                            {current.visualTitle}
                                        </h2>
                                        <div className="flex items-center gap-2 text-indigo-50 font-black uppercase tracking-[0.25em] text-[10px] bg-white/10 border border-white/20 px-5 py-2.5 rounded-2xl backdrop-blur-md">
                                            <Sparkles size={12} className="text-yellow-400" /> {current.visualDesc}
                                        </div>
                                    </motion.div>
                                </AnimatePresence>
                            </div>
                        </div>
                    </motion.div>
                )}

                {/* Form Container (Swipes Opposite Side) */}
                <motion.div
                    initial={false}
                    animate={{ x: isDesktop ? (isLogin ? '100%' : '0%') : '0%' }}
                    transition={springConfig}
                    className="w-full lg:w-1/2 h-full z-10 bg-white relative lg:shadow-inner overflow-hidden flex flex-col"
                >
                    {/* FIXED STICKY WATERMARK: Outside the scrollable area (Desktop Only) */}
                    {isDesktop && (
                        <div className="absolute -bottom-24 -right-20 hidden lg:block opacity-[0.04] pointer-events-none select-none -rotate-12 text-slate-950 z-0">
                            <CustomLayersIcon size={360} />
                        </div>
                    )}

                    {/* SCROLLABLE CONTENT AREA */}
                    <div className={`flex-1 w-full relative z-10 flex flex-col items-center justify-start p-6 lg:p-14 ${isLogin ? 'lg:overflow-hidden overflow-y-auto' : 'overflow-y-auto'
                        }`}>
                        <div className="w-full max-w-md my-auto flex flex-col py-10">

                            {/* Mobile Logo Only */}
                            <div className="lg:hidden flex flex-col items-center mb-10 text-center">
                                <div className="bg-blue-600 p-3 rounded-2xl text-white mb-4">
                                    <CustomLayersIcon size={32} />
                                </div>
                                <h1 className="text-2xl font-black text-gray-900 tracking-tight">Form Architect</h1>
                            </div>

                            {/* Header Section */}
                            <div className="relative w-full min-h-[120px] mb-8">
                                <AnimatePresence mode="wait">
                                    <motion.div
                                        key={delayedMode}
                                        initial={{ opacity: 0, y: 10, scale: 0.98 }}
                                        animate={{ opacity: 1, y: 0, scale: 1 }}
                                        exit={{ opacity: 0, y: -10, scale: 0.98 }}
                                        transition={{ duration: 0.3, ease: "easeInOut" }}
                                        className="w-full lg:text-left text-center px-1"
                                    >
                                        <h1 className="text-3xl lg:text-4xl font-black text-gray-900 mb-2 tracking-tight line-clamp-2">
                                            {current.title}
                                        </h1>
                                        <p className="text-gray-500 font-medium leading-relaxed">
                                            {current.description}
                                        </p>
                                    </motion.div>
                                </AnimatePresence>
                            </div>

                            {/* Form Outlet */}
                            <div className="relative z-10 w-full animate-in fade-in slide-in-from-bottom-4 duration-500 delay-200">
                                <React.Suspense fallback={
                                    <div className="flex flex-col items-center justify-center py-20 space-y-4">
                                        <div className="w-8 h-8 border-4 border-blue-600/20 border-t-blue-600 rounded-full animate-spin" />
                                        <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 animate-pulse">Menghubungkan...</p>
                                    </div>
                                }>
                                    {delayedOutlet}
                                </React.Suspense>
                            </div>
                        </div>
                    </div>
                </motion.div>

            </div>
        </div>
    );
};

export default AuthLayout;
