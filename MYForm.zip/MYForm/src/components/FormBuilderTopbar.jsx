import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronUp, Layout, Code, Globe, Sparkles, Palette, Save, Shield } from 'lucide-react';

export default function FormBuilderTopbar({
    title,
    embedMode,
    setEmbedMode,
    jsonMode,
    setJsonMode,
    setJsonInput,
    fields,
    description,
    showAi,
    setShowAi,
    showSettings,
    setShowSettings,
    showTheme,
    setShowTheme,
    handleSave,
    saving,
    isDirty
}) {
    return (
        <div className="sticky top-0 z-[60] bg-white/95 lg:backdrop-blur-xl border-b border-gray-100 px-4 py-3">
            <div className="max-w-7xl mx-auto flex items-center justify-between">
                <div className="flex items-center space-x-4">
                    <Link to="/" className="hidden sm:block p-2 hover:bg-gray-100 rounded-full transition-all group">
                        <ChevronUp className="-rotate-90 text-gray-400 group-hover:text-gray-900" />
                    </Link>
                    <div className="hidden sm:block">
                        <h1 className="text-sm font-black text-gray-900 uppercase tracking-tighter truncate max-w-[200px]">{title || 'Formulir Tanpa Judul'}</h1>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Formulir Baru / Draft</p>
                    </div>
                </div>

                <div className="flex items-center space-x-2">
                    <div className="hidden sm:flex bg-gray-100 p-1 rounded-xl">
                        <button onClick={() => { setEmbedMode(false); setJsonMode(false); }} className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${!embedMode && !jsonMode ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-500'}`}>Rakit</button>
                        <button onClick={() => { setJsonMode(true); setEmbedMode(false); setJsonInput(JSON.stringify({ title, description, fields }, null, 2)); }} className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${jsonMode ? 'bg-gray-900 shadow-sm text-emerald-400' : 'text-gray-500'}`}>JSON</button>
                        <button onClick={() => { setEmbedMode(true); setJsonMode(false); }} className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${embedMode ? 'bg-white shadow-sm text-purple-600' : 'text-gray-500'}`}>G-Hybrid</button>
                    </div>

                    {/* Mobile Tabs (Icons Only or Compact) */}
                    <div className="flex sm:hidden bg-gray-100 p-1 rounded-xl">
                        <button onClick={() => { setEmbedMode(false); setJsonMode(false); }} className={`p-2 rounded-lg transition-all ${!embedMode && !jsonMode ? 'bg-white shadow-sm text-indigo-600' : 'text-gray-400'}`}><Layout size={16} /></button>
                        <button onClick={() => { setJsonMode(true); setEmbedMode(false); setJsonInput(JSON.stringify({ title, description, fields }, null, 2)); }} className={`p-2 rounded-lg transition-all ${jsonMode ? 'bg-gray-900 shadow-sm text-emerald-400' : 'text-gray-400'}`}><Code size={16} /></button>
                        <button onClick={() => { setEmbedMode(true); setJsonMode(false); }} className={`p-2 rounded-lg transition-all ${embedMode ? 'bg-white shadow-sm text-purple-600' : 'text-gray-400'}`}><Globe size={16} /></button>
                    </div>

                    <button
                        onClick={() => { setShowAi(!showAi); setShowSettings(false); setShowTheme(false); }}
                        className={`lg:hidden p-2 rounded-xl transition-all ${showAi ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-100 text-gray-500'}`}
                    >
                        <Sparkles size={16} />
                    </button>

                    <button
                        onClick={() => { setShowTheme(!showTheme); setShowSettings(false); setShowAi(false); }}
                        className={`lg:hidden p-2 rounded-xl transition-all ${showTheme ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-100 text-gray-400'}`}
                    >
                        <Palette size={16} />
                    </button>

                    <button
                        onClick={() => { setShowSettings(!showSettings); setShowTheme(false); setShowAi(false); }}
                        className={`lg:hidden p-2 rounded-xl transition-all ${showSettings ? 'bg-indigo-600 text-white shadow-lg' : 'bg-gray-100 text-gray-400'}`}
                    >
                        <Shield size={16} />
                    </button>

                    <button onClick={handleSave} disabled={saving} className={`flex items-center space-x-2 px-4 sm:px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-lg active:scale-95 ${isDirty ? 'bg-indigo-600 hover:bg-indigo-700 text-white shadow-blue-200' : 'bg-gray-100 text-gray-400 cursor-not-allowed'}`}>
                        {saving ? <Sparkles size={14} className="animate-spin" /> : <Save size={14} />}
                        <span className="hidden sm:inline">{saving ? 'Menyimpan...' : 'Simpan'}</span>
                    </button>
                </div>
            </div>
        </div>
    );
}
