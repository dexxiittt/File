import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

export default function ConfirmModal({ isOpen, onClose, onConfirm, title, message, confirmText = "Hapus Permanen", cancelText = "Batal", type = "danger" }) {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
            {/* Backdrop */}
            <div
                className="absolute inset-0 bg-gray-900/60 lg:backdrop-blur-md animate-in fade-in duration-300"
                onClick={onClose}
            />

            {/* Modal */}
            <div className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.25)] border border-gray-100 overflow-hidden animate-in zoom-in-95 duration-300 ease-out">
                {/* Close Button */}
                <button
                    onClick={onClose}
                    className="absolute top-6 right-6 p-2 text-gray-400 hover:text-gray-900 hover:bg-gray-100 rounded-xl transition-all"
                >
                    <X size={20} />
                </button>

                <div className="p-8 sm:p-10">
                    <div className={`w-16 h-16 rounded-3xl flex items-center justify-center mb-6 ${type === 'danger' ? 'bg-rose-50 text-rose-500' : 'bg-blue-50 text-blue-500'}`}>
                        <AlertTriangle size={32} strokeWidth={2.5} />
                    </div>

                    <h3 className="text-2xl font-black text-gray-900 mb-3 tracking-tight leading-tight">
                        {title}
                    </h3>

                    <p className="text-gray-500 font-medium leading-relaxed mb-10">
                        {message}
                    </p>

                    <div className="flex flex-col sm:flex-row gap-3">
                        <button
                            onClick={onConfirm}
                            className={`flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg active:scale-95 ${type === 'danger' ? 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-200' : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-200'}`}
                        >
                            {confirmText}
                        </button>
                        <button
                            onClick={onClose}
                            className="flex-1 py-4 bg-gray-50 hover:bg-gray-100 text-gray-500 font-black rounded-2xl text-xs uppercase tracking-widest transition-all border border-gray-100"
                        >
                            {cancelText}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
