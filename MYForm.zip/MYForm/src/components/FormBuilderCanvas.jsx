import React from 'react';
import { Plus, Type, AlignLeft, Mail, Hash, CheckSquare, List, ChevronDown, Calendar, Clock, Sliders, Layout, Split, Upload } from 'lucide-react';
import FormFieldItem from './FormFieldItem';
import { FIELD_TYPES } from './FormFieldItem';

const PenTool = ({ size, className, strokeWidth }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth || "2"} strokeLinecap="round" strokeLinejoin="round" className={className}>
        <path d="m12 19 7-7 3 3-7 7-3-3z" />
        <path d="m18 13-1.5-7.5L4 2l3.5 12.5L13 16" />
        <path d="m2 22 5-5" />
        <path d="M8 14 14 8" />
    </svg>
);

export default function FormBuilderCanvas({
    title,
    setTitle,
    description,
    setDescription,
    fields,
    theme,
    backgroundPattern,
    setIsDirty,
    removeField,
    updateField,
    handleDragStart,
    handleDragOver,
    handleDrop,
    draggedItemIndex,
    openDropdownId,
    setOpenDropdownId,
    isQuizMode,
    addField,
    showAllTypes,
    setShowAllTypes,
    PATTERNS
}) {
    return (
        <div className="space-y-0 bg-white rounded-2xl shadow-sm border border-gray-200 relative transition-all min-h-[60vh]">
            <div className={`absolute inset-0 overflow-hidden rounded-2xl pointer-events-none ${PATTERNS.find(p => p.value === backgroundPattern)?.className || ''}`}>
                <div className={`absolute top-0 right-0 w-32 h-32 opacity-[0.03] ${theme === 'blue' ? 'text-indigo-600' : theme === 'purple' ? 'text-purple-600' : 'text-gray-600'}`}>
                    <PenTool size={128} strokeWidth={1} />
                </div>
            </div>

            <div className="relative z-10 p-6 sm:p-10 space-y-6">
                <div className="space-y-4 relative">
                    <input type="text" placeholder="Judul Formulir" value={title} onChange={(e) => { setTitle(e.target.value); setIsDirty(true); }} className="w-full text-3xl font-black border-none focus:ring-0 placeholder-gray-200 outline-none p-0 bg-transparent" />
                    <textarea placeholder="Tambahkan deskripsi singkat..." value={description} onChange={(e) => { setDescription(e.target.value); setIsDirty(true); }} className="w-full text-gray-500 border-none focus:ring-0 placeholder-gray-200 outline-none p-0 resize-none min-h-[60px] bg-transparent font-medium" />
                    <div className={`h-1.5 w-24 rounded-full ${theme === 'blue' ? 'bg-indigo-500' : theme === 'purple' ? 'bg-purple-500' : theme === 'green' ? 'bg-green-500' : theme === 'rose' ? 'bg-rose-500' : theme === 'orange' ? 'bg-orange-500' : 'bg-slate-800'}`} />
                </div>

                <div className="space-y-4 pt-10">
                    {fields.length === 0 && (
                        <div className="border-2 border-dashed border-gray-100 rounded-xl py-20 flex flex-col items-center justify-center text-gray-400 space-y-4">
                            <div className="p-5 bg-gray-50 rounded-full animate-pulse"><Plus size={32} /></div>
                            <p className="font-bold text-sm">Klik tombol di bawah untuk menambah pertanyaan</p>
                        </div>
                    )}

                    {fields.map((field, index) => (
                        <FormFieldItem
                            key={field.id}
                            field={field}
                            index={index}
                            fields={fields}
                            removeField={removeField}
                            updateField={updateField}
                            handleDragStart={handleDragStart}
                            handleDragOver={handleDragOver}
                            handleDrop={handleDrop}
                            draggedItemIndex={draggedItemIndex}
                            openDropdownId={openDropdownId}
                            setOpenDropdownId={setOpenDropdownId}
                            isQuizMode={isQuizMode}
                        />
                    ))}

                    {showAllTypes && (
                        <div className="hidden lg:block relative mb-8 w-full bg-white border border-gray-100 rounded-2xl shadow-xl p-6 sm:p-10 animate-in slide-in-from-bottom-4">
                            <div className="flex items-center justify-between mb-8">
                                <div className="flex flex-col">
                                    <div className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em] mb-1">Struktur Formulir</div>
                                    <h3 className="text-xl font-black text-gray-900 leading-none">Pilih Tipe Pertanyaan</h3>
                                </div>
                                <button onClick={() => setShowAllTypes(false)} className="p-2 text-gray-400 hover:text-gray-900 transition-all">
                                    {/* X Icon inline to avoid explicit import if not needed */}
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18" /><path d="m6 6 12 12" /></svg>
                                </button>
                            </div>

                            <div className="grid grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3">
                                {FIELD_TYPES.map(type => (
                                    <button key={type} onClick={() => { addField(type); setShowAllTypes(false); }} className="flex items-center gap-2 sm:gap-4 w-full p-3 sm:p-4 rounded-2xl text-left hover:bg-indigo-50 group transition-all border border-gray-50 hover:border-blue-200">
                                        <div className="p-3 bg-gray-50 rounded-xl group-hover:bg-white group-hover:shadow-md text-gray-400 group-hover:text-indigo-600 transition-all">
                                            {type === 'Short Text' && <Type size={18} />}
                                            {type === 'Paragraph' && <AlignLeft size={18} />}
                                            {type === 'Email' && <Mail size={18} />}
                                            {type === 'Number' && <Hash size={18} />}
                                            {type === 'Multiple Choice' && <List size={18} />}
                                            {type === 'Checkboxes' && <CheckSquare size={18} />}
                                            {type === 'Dropdown' && <ChevronDown size={18} />}
                                            {type === 'Linear Scale' && <Sliders size={18} />}
                                            {type === 'Date' && <Calendar size={18} />}
                                            {type === 'Time' && <Clock size={18} />}
                                            {type === 'File Upload' && <Upload size={18} />}
                                            {type === 'Section Header' && <Layout size={18} />}
                                            {type === 'Page Break' && <Split size={18} />}
                                        </div>
                                        <div className="flex flex-col flex-1">
                                            <span className="text-[11px] sm:text-sm font-black text-gray-700 group-hover:text-gray-900 leading-tight">{type}</span>
                                            <span className="text-[9px] sm:text-[10px] text-gray-400 font-bold opacity-0 group-hover:opacity-100 transition-opacity">Tambah</span>
                                        </div>
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}

                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                        {FIELD_TYPES.slice(0, 4).map(type => (
                            <button key={type} onClick={() => addField(type)} className="flex flex-col items-center justify-center p-4 bg-gray-50 hover:bg-indigo-50 rounded-2xl border border-gray-100 hover:border-blue-200 transition-all group min-h-[80px]">
                                <div className="p-2 bg-white rounded-xl shadow-sm group-hover:shadow-md text-gray-400 group-hover:text-indigo-600 mb-2 transition-all">
                                    {type === 'Short Text' && <Type size={18} />}
                                    {type === 'Paragraph' && <AlignLeft size={18} />}
                                    {type === 'Email' && <Mail size={18} />}
                                    {type === 'Number' && <Hash size={18} />}
                                </div>
                                <span className="text-[8px] font-black uppercase tracking-widest text-gray-400 group-hover:text-indigo-500">{type}</span>
                            </button>
                        ))}
                        <div className="h-full col-span-2 sm:col-span-1">
                            <button onClick={() => setShowAllTypes(!showAllTypes)} className={`h-full w-full min-h-[80px] rounded-2xl shadow-lg transition-all active:scale-95 flex items-center justify-center bg-blue-600 text-white hover:bg-blue-700`}>
                                <Plus size={24} className={`transition-transform duration-300 ${showAllTypes ? 'rotate-45' : ''}`} />
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
