import React, { useState, useRef, useEffect } from 'react';

/**
 * BottomSheet — Global Reusable Component
 * Features:
 * - Responsive: Bottom sheet on mobile, centered modal on desktop
 * - Smooth Drag: Swipe-down to close without conflicting animations
 * - Seamless Transition: Backdrop follows drag progress
 */
export default function BottomSheet({ isOpen, onClose, title, children, maxWidth = 'sm:max-w-sm' }) {
    const [dragOffset, setDragOffset] = useState(0);
    const [isClosing, setIsClosing] = useState(false);
    const [active, setActive] = useState(false); // Controls the entrance transition
    const startY = useRef(0);
    const isDragging = useRef(false);

    // Initial entrance and cleanup
    useEffect(() => {
        if (isOpen) {
            // Pequi delay to ensure mount before transition
            const timer = setTimeout(() => setActive(true), 10);
            return () => {
                clearTimeout(timer);
                document.body.style.overflow = 'unset';
            };
        } else {
            setActive(false);
            setDragOffset(0);
        }
    }, [isOpen]);

    // Body scroll lock
    useEffect(() => {
        if (isOpen && active) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'unset';
        }
    }, [isOpen, active]);

    if (!isOpen && !isClosing) return null;

    const handleClose = () => {
        if (isClosing) return;
        setIsClosing(true);
        setActive(false); // Trigger exit transition
        setTimeout(() => {
            onClose();
            setIsClosing(false);
            setDragOffset(0);
        }, 300);
    };

    const handleTouchStart = (e) => {
        startY.current = e.touches[0].clientY - dragOffset;
        isDragging.current = true;
    };

    const handleTouchMove = (e) => {
        if (!isDragging.current || isClosing) return;
        const currentY = e.touches[0].clientY;
        const offset = currentY - startY.current;
        if (offset >= 0) {
            setDragOffset(offset);
        }
    };

    const handleTouchEnd = () => {
        if (!isDragging.current) return;
        isDragging.current = false;

        if (dragOffset > 150) {
            handleClose();
        } else {
            setDragOffset(0);
        }
    };

    // Calculate dynamic styles
    const backdropOpacity = Math.max(0, 0.5 - (dragOffset / 400));

    // On mobile: uses translate for entry/exit/drag
    // On desktop: uses scale/opacity
    const isMobile = typeof window !== 'undefined' && window.innerWidth < 640;

    // Final vertical position
    let translateY = '100%';
    if (active && !isClosing) translateY = `${dragOffset}px`;
    if (isClosing) translateY = '100%';
    if (!isMobile) translateY = '0'; // Desktop uses centered modal logic

    return (
        <div className={`fixed inset-0 z-[1000] flex items-end sm:items-center justify-center transition-opacity duration-300 ${isOpen && active && !isClosing ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
            <div
                className="absolute inset-0 bg-gray-900"
                style={{
                    backgroundColor: `rgba(17, 24, 39, ${backdropOpacity})`,
                    transition: isDragging.current ? 'none' : 'background-color 0.3s ease-out'
                }}
                onClick={handleClose}
            />

            <div
                className={`bg-white w-full ${maxWidth} sm:rounded-3xl rounded-t-[2.5rem] shadow-2xl relative overflow-hidden transition-all`}
                style={{
                    transform: isMobile
                        ? `translateY(${translateY})`
                        : (active && !isClosing ? 'scale(1) opacity(1)' : 'scale(0.95) opacity(0)'),
                    transition: isDragging.current ? 'none' : 'transform 0.3s cubic-bezier(0.19, 1, 0.22, 1), opacity 0.3s ease-out',
                    willChange: 'transform'
                }}
            >
                {/* Drag Handle Area */}
                <div
                    className="w-full flex justify-center pt-3 pb-5 sm:hidden cursor-grab active:cursor-grabbing touch-none select-none"
                    onTouchStart={handleTouchStart}
                    onTouchMove={handleTouchMove}
                    onTouchEnd={handleTouchEnd}
                >
                    <div className="w-12 h-1.5 bg-gray-200 rounded-full" />
                </div>

                <div className="p-6 pt-0 sm:p-8">
                    {title && (
                        <h3 className="text-xl font-black text-gray-900 mb-4 tracking-tight">{title}</h3>
                    )}

                    <div className="max-h-[75vh] overflow-y-auto scrollbar-hide">
                        {children}
                    </div>
                </div>
            </div>
        </div>
    );
}
