// Konfigurasi Terpusat untuk Backend Google Apps Script (GAS)

const CONFIG = {
  SPREADSHEET_ID: "1jwT-SU7zdN_FUviop03L4mRGocuq1Ig8S6FseDWAapU", 
  GDRIVE_FOLDER_ID: "1TFvW6iqe0ebnU_vPl1xDbUFW9q_oNDll",
  GROQ_API_KEYS: [
    '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',
    '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',
    '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'
  ],
  GROQ_MODELS: [
    'llama-3.3-70b-versatile',
    'llama-3.1-70b-versatile',
    'mixtral-8x7b-32768'
  ],
  PUSHER: {
    appId: "2130966",
    key: "0302a51d1ad8ee4a2dc6",
    secret: "c8372921907ecfc9c640",
    cluster: "ap1"
  },
  GOOGLE_CLIENT_SECRET: "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",
  VERCEL_BACKEND_URL: "https://myformulir.vercel.app", // Masukkan URL Vercel Anda di sini
  NOTIFY_API_KEY: "MYForm_Secure_Push_99" // Password rahasia untuk memanggil API Vercel
};
