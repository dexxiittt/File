const ACCOUNTS_SHEET = 'account';
const FORMS_SHEET = 'forms';
const PENDING_ACCOUNTS_SHEET = 'pending_accounts';
const SESSIONS_SHEET = 'sessions';

function getSpreadsheet() {
  return SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
}

// Phase 4: Activity Logging Helper
function logAction(username, action, status, details = "") {
  try {
    const ss = getSpreadsheet();
    let sheet = ss.getSheetByName('logs');
    if (!sheet) {
      sheet = ss.insertSheet('logs');
      sheet.appendRow(['timestamp', 'username', 'action', 'status', 'details']);
    }
    sheet.appendRow([new Date().toISOString(), username || "GHOST", action, status, details]);
  } catch (e) {
    console.error("Gagal logAction:", e);
  }
}

// =======================
// HELPER: HASHING (Keamanan)
// =======================
function computeSHA256(input) {
  var rawHash = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, input, Utilities.Charset.UTF_8);
  var txtHash = '';
  for (var i = 0; i < rawHash.length; i++) {
    var hashVal = rawHash[i];
    if (hashVal < 0) {
      hashVal += 256;
    }
    if (hashVal.toString(16).length == 1) {
      txtHash += '0';
    }
    txtHash += hashVal.toString(16);
  }
  return txtHash;
}

// Phase 1 Security: Verify Session Token (Multi-Device Support)
function verifyToken(username, token) {
  if (!username || !token) return false;
  
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(SESSIONS_SHEET);
  if (!sheet) return false;
  
  const data = sheet.getDataRange().getValues();
  const now = new Date();
  
  for (let i = 1; i < data.length; i++) {
    // String() casting to handle numeric usernames/tokens
    if (String(data[i][0]) === String(username) && String(data[i][1]) === String(token)) {
      const expiryStr = data[i][2];
      if (expiryStr) {
        const expiry = new Date(expiryStr);
        if (now < expiry) {
          // ROLLING SESSION: Jika sisa waktu kurang dari 5 hari, perpanjang jadi 30 hari lagi
          const diffDays = (expiry.getTime() - now.getTime()) / (1000 * 3600 * 24);
          if (diffDays < 365) {
            const newExpiry = new Date();
            newExpiry.setFullYear(newExpiry.getFullYear() + 100); // 100 Year Perpetual Session
            sheet.getRange(i + 1, 3).setValue(newExpiry.toISOString());
          }
          return true;
        }
      }
    }
  }
  return false;
}

// Helper: Cek apakah user adalah Admin berdasarkan Token
function checkAdmin(username, token) {
  if (!username || !token) return false;
  
  // 1. Verifikasi Sesi Terlebih Dahulu
  if (!verifyToken(username, token)) return false;
  
  // 2. Cek status Admin di tabel akun
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const dataRange = sheet.getDataRange().getValues();
  
  for (let i = 1; i < dataRange.length; i++) {
    if (String(dataRange[i][1]) === String(username)) {
      const isAdmin = dataRange[i][9]; 
      return isAdmin === true || String(isAdmin).toUpperCase() === "TRUE";
    }
  }
  return false;
}

// Phase 2 Security: Basic Input Sanitization (Prevensi XSS)
function sanitize(input) {
  if (Array.isArray(input)) return input.map(sanitize);
  if (input !== null && typeof input === 'object' && !input.base64) {
    const sanitizedObj = {};
    for (let key in input) {
      sanitizedObj[key] = sanitize(input[key]);
    }
    return sanitizedObj;
  }
  if (typeof input !== 'string') return input;
  return input.replace(/<[^>]*>?/gm, '');
}

function createJsonResponse(data) {
  return ContentService.createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

// Inisialisasi Sheet jika belum ada
function initSheets() {
  const ss = getSpreadsheet();
  if (!ss.getSheetByName(ACCOUNTS_SHEET)) {
    ss.insertSheet(ACCOUNTS_SHEET).appendRow(['id', 'username', 'passwordHash', 'salt', 'isVerified', 'token', 'tokenExpires', 'lastAiRequest', 'customGasUrl', 'isAdmin', 'storageUsed']);
  }
  if (!ss.getSheetByName(FORMS_SHEET)) {
    ss.insertSheet(FORMS_SHEET).appendRow([
      'formId', 'customSlug', 'username', 'title', 'description', 
      'fields_schema_json', 'theme', 'backgroundPattern', 'isActive', 
      'confirmationMessage', 'gformUrl', 'createdAt', 'userSpreadsheetId', 'userFolderId', 'isQuizMode',
      'requireLogin', 'limitOneResponse'
    ]);
  }
  if (!ss.getSheetByName('logs')) {
    ss.insertSheet('logs').appendRow(['timestamp', 'username', 'action', 'status', 'details']);
  }
  if (!ss.getSheetByName(PENDING_ACCOUNTS_SHEET)) {
    ss.insertSheet(PENDING_ACCOUNTS_SHEET).appendRow(['username', 'passwordHash', 'salt', 'status', 'createdAt']);
  }
  if (!ss.getSheetByName(SESSIONS_SHEET)) {
    ss.insertSheet(SESSIONS_SHEET).appendRow(['username', 'token', 'expires']);
  }
}

// =======================
// ROUTER: HTTP POST
// =======================
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const action = data.action;

    // Phase 1: PROTECTED ACTIONS (Require Token)
    const protectedActions = [
      'createForm', 'getResponses', 'generateForm', 'getCreatorForms', 
      'toggleFormStatus', 'deleteForm', 'deleteAccount', 'getSystemInfo', 'importGForm', 'updateProfile'
    ];

    if (protectedActions.includes(action)) {
      if (!verifyToken(data.username, data.token)) {
        return createJsonResponse({ 
          success: false, 
          error: 'Sesi kedaluwarsa atau tidak valid. Silakan logout dan login kembali.',
          isLoggedOut: true 
        });
      }
    }
    
    switch (action) {
      case 'register':
        return handleRegisterRequest(data);
      case 'getPendingUsers':
        if (!checkAdmin(data.username, data.token)) return createJsonResponse({ success: false, error: 'Unauthorized: Admin only' });
        return handleGetPendingUsers(data);
      case 'approveUser':
        if (!checkAdmin(data.username, data.token)) return createJsonResponse({ success: false, error: 'Unauthorized: Admin only' });
        return handleApproveUser(data);
      case 'rejectUser':
        if (!checkAdmin(data.username, data.token)) return createJsonResponse({ success: false, error: 'Unauthorized: Admin only' });
        return handleRejectUser(data);
      case 'login':
        return handleLogin(data);
      case 'createForm':
        return handleCreateForm(data);
      case 'submitResponse':
        return handleSubmitResponse(data);
      case 'getResponses':
        return handleGetResponses(data);
      case 'generateForm':
        return handleGenerateForm(data);
      case 'importGForm':
        return handleImportGForm(data);
      // Endpoint tambahan untuk Frontend UI
      case 'getFormBySlug':
        return handleGetFormBySlug(data);
      case 'getCreatorForms':
        return handleGetCreatorForms(data);
      case 'toggleFormStatus':
        return handleToggleFormStatus(data);
      case 'deleteForm':
        return handleDeleteForm(data);
      case 'deleteAccount':
        return handleDeleteAccount(data);
      case 'getSystemInfo':
        return handleGetSystemInfo();
      case 'updateProfile':
        return handleUpdateProfile(data);
      case 'updateCustomGasUrl':
        return handleUpdateCustomGasUrl(data);
      case 'getAllUsers':
        if (!checkAdmin(data.username, data.token)) return createJsonResponse({ success: false, error: 'Unauthorized: Admin only' });
        return handleGetAllUsers(data);
      case 'updateUserStatus':
        if (!checkAdmin(data.username, data.token)) return createJsonResponse({ success: false, error: 'Unauthorized: Admin only' });
        return handleUpdateUserStatus(data);
      case 'adminDeleteUser':
        if (!checkAdmin(data.username, data.token)) return createJsonResponse({ success: false, error: 'Unauthorized: Admin only' });
        return handleAdminDeleteUser(data);
      case 'init': // Menjalankan init
        if (!checkAdmin(data.username, data.token)) return createJsonResponse({ success: false, error: 'Unauthorized: Admin only' });
        initSheets();
        return createJsonResponse({ success: true, message: 'Initialized Setup' });
      default:
        return createJsonResponse({ error: 'Action tidak valid' });
    }
  } catch (error) {
    logAction("SYSTEM", "ERROR", "CRITICAL", error.message);
    return createJsonResponse({ 
      success: false, 
      error: error.message || "Internal Server Error"
    });
  }
}

// =======================
// HANDLERS
// =======================

function handleRegisterRequest(data) {
  const { username, password } = data;
  
  // Pastikan tabel ada sebelum lanjut
  initSheets();
  
  const ss = getSpreadsheet();
  const accountSheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const pendingSheet = ss.getSheetByName(PENDING_ACCOUNTS_SHEET);
  
  if (!accountSheet || !pendingSheet) {
    return createJsonResponse({ success: false, error: 'Tabel database tidak ditemukan atau belum diinisialisasi.' });
  }

  // 1. Cek pendaftar di akun utama
  const accountData = accountSheet.getDataRange().getValues();
  for (let i = 1; i < accountData.length; i++) {
    if (accountData[i][1] === username) {
      return createJsonResponse({ success: false, error: 'Username sudah digunakan.' });
    }
  }

  // 2. Hash & Salt
  const salt = Utilities.getUuid();
  const passwordHash = computeSHA256(password + salt);
  
  // 3. Bersihkan data pending lama
  const pendingData = pendingSheet.getDataRange().getValues();
  for (let i = pendingData.length - 1; i >= 0; i--) {
    if (pendingData[i][0] === 'username') continue;
    if (pendingData[i][0] === username) {
      pendingSheet.deleteRow(i + 1);
    }
  }

  // 4. Simpan ke Pending (Hanya Username & Data Utama)
  pendingSheet.appendRow([username, passwordHash, salt, "PENDING", new Date().toISOString()]);
  
  logAction(username, 'REGISTER_REQUESTED', 'SUCCESS', 'Menunggu Admin');

  // Kirim Sinyal Real-time ke Admin Panel via Pusher
  try {
    SpreadsheetApp.flush(); // WAJIB: flush data sebelum trigger real-time
    triggerPusher('admin-channel', 'new-registration', { username: username });
    
    // NEW: Trigger True Web Push (Pusher Beams)
    try {
      const beamsRes = UrlFetchApp.fetch(CONFIG.VERCEL_BACKEND_URL + '/api/beams-notify', {
        method: 'post',
        contentType: 'application/json',
        headers: { 'x-api-key': CONFIG.NOTIFY_API_KEY },
        payload: JSON.stringify({
          title: 'Pendaftar Baru!',
          body: `@${username} sedang menunggu persetujuan Anda.`,
          url: '/admin',
          actions: [
            { action: 'approve', title: 'Terima' },
            { action: 'reject', title: 'Tolak' }
          ],
          data: {
            targetUsername: username,
            gasUrl: ScriptApp.getService().getUrl()
          }
        }),
        muteHttpExceptions: true
      });
      const responseCode = beamsRes.getResponseCode();
      const responseBody = beamsRes.getContentText();
      logAction('SYSTEM', 'BEAMS_PUSH', responseCode === 200 ? 'SUCCESS' : 'ERROR', `Status: ${responseCode}, Res: ${responseBody}`);
    } catch (e) {
      logAction('SYSTEM', 'BEAMS_PUSH', 'EXCEPTION', e.message);
      console.error("Gagal trigger Beams:", e);
    }
  } catch (e) {
    console.error('Pusher trigger failed:', e);
  }

  return createJsonResponse({ success: true, message: 'Pendaftaran berhasil dikirim. Silakan tunggu persetujuan Admin.' });
}

function handleGetPendingUsers(data) {
  const lastSyncHash = data?.lastSyncHash;
  const ss = getSpreadsheet();
  const pendingSheet = ss.getSheetByName(PENDING_ACCOUNTS_SHEET);
  if (!pendingSheet) return createJsonResponse({ success: false, error: 'Database antrean tidak ditemukan.' });
  
  const values = pendingSheet.getDataRange().getValues();
  const users = [];
  
  for (let i = 0; i < values.length; i++) {
    if (values[i][0] === 'username') continue; 
    if (!values[i][0]) continue; 
    
    users.push({
      username: values[i][0],
      createdAt: values[i][4]
    });
  }

  // Efficient Sync (Hash)
  const currentHash = computeSHA256(JSON.stringify(users));
  if (lastSyncHash && lastSyncHash === currentHash) {
    return createJsonResponse({ success: true, changed: false, hash: currentHash });
  }
  
  return createJsonResponse({ success: true, changed: true, users: users, hash: currentHash });
}

function handleApproveUser(data) {
  const { targetUsername } = data;
  const ss = getSpreadsheet();
  const pendingSheet = ss.getSheetByName(PENDING_ACCOUNTS_SHEET);
  const accountSheet = ss.getSheetByName(ACCOUNTS_SHEET);
  
  const pendingData = pendingSheet.getDataRange().getValues();
  
  for (let i = 1; i < pendingData.length; i++) {
    if (String(pendingData[i][0]) === String(targetUsername)) {
      const passwordHash = pendingData[i][1];
      const salt = pendingData[i][2];
      
      const id = Utilities.getUuid();
      const isVerified = false; // Disetujui masuk tapi belum verifikasi Pro/AI
      
      // Pindahkan ke Akun Utama (Email dikosongkan) - Sesuaikan 11 Kolom
      // [id, username, passwordHash, salt, isVerified, token, tokenExpires, lastAiRequest, customGasUrl, isAdmin, storageUsed]
      accountSheet.appendRow([id, String(targetUsername), passwordHash, salt, isVerified, "", "", "", "", false, 0]);
      
      // Hapus dari pending
      pendingSheet.deleteRow(i + 1);
      
      logAction('admin', 'APPROVE_USER', 'SUCCESS', targetUsername);

      // Trigger Pusher untuk User (Real-time feedback)
      try {
        SpreadsheetApp.flush(); // WAJIB: flush data sebelum trigger real-time
        triggerPusher('user-channel-' + targetUsername, 'account-approved', { 
          success: true,
          message: 'Your account has been approved!' 
        });
      } catch (e) {
        console.error('Pusher trigger failed:', e);
      }

      return createJsonResponse({ success: true, message: `Akun ${targetUsername} telah disetujui.` });
    }
  }
  
  return createJsonResponse({ success: false, error: 'User tidak ditemukan di daftar antrean.' });
}

function handleRejectUser(data) {
  const { targetUsername } = data;
  const ss = getSpreadsheet();
  const pendingSheet = ss.getSheetByName(PENDING_ACCOUNTS_SHEET);
  
  const pendingData = pendingSheet.getDataRange().getValues();
  
  for (let i = 1; i < pendingData.length; i++) {
    if (String(pendingData[i][0]) === String(targetUsername)) {
      pendingSheet.deleteRow(i + 1);
      logAction('admin', 'REJECT_USER', 'SUCCESS', targetUsername);
      
      // Trigger Pusher untuk User (Real-time feedback)
      try {
        SpreadsheetApp.flush(); // WAJIB: flush data sebelum trigger real-time
        triggerPusher('user-channel-' + targetUsername, 'account-rejected', { 
          success: false,
          message: 'Your registration was rejected.' 
        });
      } catch (e) {
        console.error('Pusher trigger failed:', e);
      }

      return createJsonResponse({ success: true, message: `Pendaftaran ${targetUsername} telah ditolak dan dihapus.` });
    }
  }
  
  return createJsonResponse({ success: false, error: 'User tidak ditemukan.' });
}

function handleLogin(data) {
  const { username, password } = data;
  
  // Pastikan tabel ada (termasuk tabel sesi baru)
  initSheets();
  
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const dataRange = sheet.getDataRange().getValues();
  
  for (let i = 1; i < dataRange.length; i++) {
    if (String(dataRange[i][1]) === String(username)) {
      const storedHash = dataRange[i][2];
      const salt = dataRange[i][3];
      const isVerified = dataRange[i][4];
      const newHash = computeSHA256(password + salt);
      
      if (newHash === storedHash) {
        // Generate Session Token (UUID)
        const token = Utilities.getUuid();
        const expires = new Date();
        expires.setFullYear(expires.getFullYear() + 100); // Start with 100 Year Perpetual Session
        
        // Simpan ke Tabel Sesi (Multi-Device)
        const sessionSheet = ss.getSheetByName(SESSIONS_SHEET);
        if (sessionSheet) {
          const sData = sessionSheet.getDataRange().getValues();
          const nowTime = new Date().getTime();
          
          // Hapus sesi lama milik user ini yg sudah lewat 30 hari
          for (let k = sData.length - 1; k >= 1; k--) {
            if (String(sData[k][0]) === String(username)) {
              const sExp = new Date(sData[k][2]).getTime();
              if (nowTime > sExp) {
                sessionSheet.deleteRow(k + 1);
              }
            }
          }
          
          sessionSheet.appendRow([String(username), token, expires.toISOString()]);
        }
        
        logAction(username, 'LOGIN', 'SUCCESS');

        const isAdmin = dataRange[i][9] === true || dataRange[i][9] === "TRUE";

        return createJsonResponse({ 
          success: true, 
          username: username,
          token: token,
          isVerified: isVerified === true || isVerified === "TRUE",
          isAdmin: isAdmin,
          customGasUrl: dataRange[i][8] || "",
          expires: expires.toISOString()
        });
      } else {
        logAction(username, 'LOGIN', 'FAILURE', 'Password salah');
        return createJsonResponse({ success: false, error: 'Password salah' });
      }
    }
  }
  logAction(username, 'LOGIN', 'FAILURE', 'Username tidak ditemukan');
  return createJsonResponse({ success: false, error: 'Username tidak ditemukan' });
}

function handleCreateForm(data) {
  const { 
    customSlug, username, title, description, fields_schema_json, 
    theme, backgroundPattern, isActive, confirmationMessage, gformUrl,
    userSpreadsheetId, userFolderId, isQuizMode, requireLogin, limitOneResponse
  } = data;
  
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(FORMS_SHEET);
  
  // Phase 6: Penegakan Batas Kapasitas (Tiering)
  const allForms = sheet.getDataRange().getValues();
  let userFormCount = 0;
  for (let i = 1; i < allForms.length; i++) {
    if (allForms[i][2] === username) userFormCount++;
  }

  // Cek Status Verifikasi
  const accountSheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const accounts = accountSheet.getDataRange().getValues();
  let isVerified = false;
  for (let i = 1; i < accounts.length; i++) {
    if (String(accounts[i][1]) === String(username)) {
      const status = accounts[i][4];
      isVerified = (status === true || status === "TRUE");
      break;
    }
  }

  const isPersonalStorage = userSpreadsheetId && userSpreadsheetId.trim() !== "";
  const isLimitReached = userFormCount >= 10;

  if (isLimitReached && !isVerified && !isPersonalStorage) {
    return createJsonResponse({ 
      success: false, 
      error: 'Kapasitas formulir penuh (Batas: 10). Silakan verifikasi akun atau hubungkan ke Google Sheets pribadi untuk kapasitas tak terbatas.' 
    });
  }
  
  // Custom slug validation: huruf, angka, strip (backend verification)
  let validSlug = customSlug;
  if (validSlug) {
    const slugRegex = /^[a-zA-Z0-9\-]+$/;
    if (!slugRegex.test(validSlug)) {
      return createJsonResponse({ success: false, error: 'Slug hanya boleh berisi huruf, angka, dan strip' });
    }
    
    // Cek duplikasi slug
    const dataRange = sheet.getDataRange().getValues();
    for (let i = 1; i < dataRange.length; i++) {
      if (dataRange[i][1] === validSlug) {
        return createJsonResponse({ success: false, error: 'Slug sudah dipakai oleh form lain' });
      }
    }
  }
  
  const cleanTitle = sanitize(title);
  const cleanDescription = sanitize(description);
  const cleanConfirmationMessage = sanitize(confirmationMessage);
  
  const formData = [
    data.formId || Utilities.getUuid(), // Use existing ID or generate new
    validSlug || (data.formId || Utilities.getUuid()), 
    username, cleanTitle, cleanDescription, 
    fields_schema_json, theme, backgroundPattern, isActive, 
    cleanConfirmationMessage, gformUrl, 
    data.formId ? undefined : new Date().toISOString(), // Only set createdAt for new forms
    userSpreadsheetId, userFolderId, isQuizMode,
    requireLogin || false, limitOneResponse || false
  ];

  // Logic Update vs Create
  const sheetData = sheet.getDataRange().getValues();
  let rowToUpdate = -1;
  const currentFormId = data.formId;

  if (currentFormId) {
    for (let i = 1; i < sheetData.length; i++) {
        if (sheetData[i][0] === currentFormId) {
            rowToUpdate = i + 1;
            break;
        }
    }
  }

  if (rowToUpdate !== -1) {
    // UPDATE EXISTING
    const existingRow = sheetData[rowToUpdate - 1];
    // Keep original createdAt
    formData[11] = existingRow[11]; 
    // Perform update
    sheet.getRange(rowToUpdate, 1, 1, formData.length).setValues([formData]);
    logAction(username, 'UPDATE_FORM', 'SUCCESS', currentFormId);
  } else {
    // CREATE NEW
    const newFormId = formData[0];
    const newSlug = validSlug || newFormId;
    formData[1] = newSlug;
    formData[11] = new Date().toISOString();
    sheet.appendRow(formData);
    
    // Pembuatan Tab Baru Otomatis HANYA apabila BUKAN link GForm (builder bawaan)
    if (!gformUrl || gformUrl.trim() === "") {
        const tabName = `res_${newFormId}`;
        let newSheet = ss.getSheetByName(tabName);
        if (!newSheet) {
            newSheet = ss.insertSheet(tabName);
        }
        
        // Tulis Header berdasarkan fields schema
        let headers = ['Timestamp'];
        if (requireLogin) headers.push('Respondent Username');
        try {
            if (fields_schema_json) {
                const fields = JSON.parse(fields_schema_json);
                headers = headers.concat(fields.map(f => f.label || f.id));
            }
        } catch(e) {}
        newSheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    }
    logAction(username, 'CREATE_FORM', 'SUCCESS', newFormId);
  }
  
  return createJsonResponse({ 
    success: true, 
    formId: currentFormId || formData[0], 
    customSlug: validSlug || formData[1] 
  });
}

function handleSubmitResponse(data) {
  const { formId, responses, submitterUsername, submitterToken } = data; // responses = { "Nama": "Budi", "KTP": ... }
  
  const centralSs = getSpreadsheet();
  const formsSheet = centralSs.getSheetByName(FORMS_SHEET);
  const formsData = formsSheet.getDataRange().getValues();

  let form = null;
  // Find the form by formId (assuming formId is in the first column)
  for (let i = 1; i < formsData.length; i++) {
    if (formsData[i][0] === formId) {
      form = {
        formId: formsData[i][0],
        customSlug: formsData[i][1],
        username: formsData[i][2],
        title: formsData[i][3],
        description: formsData[i][4],
        fields_schema_json: formsData[i][5],
        theme: formsData[i][6],
        backgroundPattern: formsData[i][7],
        isActive: formsData[i][8],
        confirmationMessage: formsData[i][9],
        gformUrl: formsData[i][10],
        createdAt: formsData[i][11],
        userSpreadsheetId: formsData[i][12],
        userFolderId: formsData[i][13],
        isQuizMode: formsData[i][14],
        requireLogin: formsData[i][15] === true || formsData[i][15] === "TRUE",
        limitOneResponse: formsData[i][16] === true || formsData[i][16] === "TRUE"
      };
      break;
    }
  }

  if (!form) {
    return createJsonResponse({ success: false, error: 'Form tidak ditemukan.' });
  }

  // Security Check: Wajib Login
  if (form.requireLogin) {
    if (!submitterUsername || !submitterToken || !verifyToken(submitterUsername, submitterToken)) {
      return createJsonResponse({ success: false, error: 'Formulir ini mewajibkan Anda untuk Login terlebih dahulu. Sesi Anda tidak sah atau kadaluarsa.' });
    }
  }

  // Cek Status Akun dan Kuota Storage per User (Batas: 100MB)
  let isVerified = false;
  let storageUsed = 0;
  let accountRowIndex = -1;
  const accountSheet = centralSs.getSheetByName(ACCOUNTS_SHEET);
  const accountsData = accountSheet.getDataRange().getValues();
  for (let i = 1; i < accountsData.length; i++) {
    if (accountsData[i][1] === form.username) {
      isVerified = (accountsData[i][4] === true || accountsData[i][4] === "TRUE");
      storageUsed = parseInt(accountsData[i][10]) || 0; // Kolom 11 (Index 10)
      accountRowIndex = i + 1;
      break;
    }
  }

  const isPersonalStorage = form.userFolderId && form.userFolderId.trim() !== "";
  const isExempt = isVerified || isPersonalStorage;
  let newFileSize = 0;

  if (!isExempt) {
    for (const key in responses) {
      const val = responses[key];
      if (val && typeof val === 'object' && val.base64) {
        const parts = val.base64.split(',');
        const base64Data = parts.length > 1 ? parts[1] : parts[0];
        newFileSize += Math.ceil(base64Data.length * 0.75);
      }
    }
    if (newFileSize > 0 && (storageUsed + newFileSize > 104857600)) { // 100 MB = 104,857,600 Bytes
      return createJsonResponse({ 
        success: false, 
        error: 'Kapasitas penyimpanan file kreator penuh (Maks: 100 MB). Kreator formulir ini telah melampaui batas wajar. Hubungi kreator formulir.' 
      });
    }
  }

  let ss;
  let sheet;
  
  if (form.userSpreadsheetId) {
    try {
      ss = SpreadsheetApp.openById(form.userSpreadsheetId);
      sheet = ss.getSheets()[0]; // Ambil sheet pertama
      
      // Jika sheet kosong (baru dibuat), tambahkan header
      if (sheet.getLastRow() === 0) {
        const initHeaders = ['Timestamp'];
        const fields = JSON.parse(form.fields_schema_json || '[]');
        fields.forEach(f => initHeaders.push(f.label));
        if (form.isQuizMode === true || form.isQuizMode === "TRUE") initHeaders.push('Total Skor');
        if (form.requireLogin) initHeaders.push('Respondent Username');
        sheet.appendRow(initHeaders);
      }
    } catch (e) {
      console.error("Gagal menulis ke Spreadsheet Personal:", e);
      // Fallback ke central storage jika gagal? 
      // User mungkin belum share sheet nya ke email script.
      ss = getSpreadsheet();
      sheet = ss.getSheetByName(`res_${form.formId}`);
    }
  } else {
    ss = getSpreadsheet();
    sheet = ss.getSheetByName(`res_${form.formId}`);
  }

  if (!sheet) {
    return createJsonResponse({ success: false, error: 'Database formulir tidak ditemukan (Tab ditutup atau invalid).' });
  }
  
  let headers;
  try {
     headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  } catch(e) {
     headers = [];
  }
  
  if (form.requireLogin && !headers.includes('Respondent Username')) {
    const newCol = headers.length + 1;
    sheet.getRange(1, newCol).setValue('Respondent Username');
    headers.push('Respondent Username');
  }

  // Tambahkan kolom Device ID jika belum ada (untuk fingerprinting)
  if (!headers.includes('Device ID')) {
    const newCol = headers.length + 1;
    sheet.getRange(1, newCol).setValue('Device ID');
    headers.push('Device ID');
  }

  // Security Check: Limit 1 Response
  if (form.limitOneResponse) {
    const respondentIndex = headers.indexOf('Respondent Username');
    const fingerprintIndex = headers.indexOf('Device ID');
    const existingData = sheet.getDataRange().getValues();
    
    for (let r = 1; r < existingData.length; r++) {
      // 1. Cek duplikasi berdasarkan Username (Sangat Kuat)
      if (form.requireLogin && submitterUsername && respondentIndex !== -1) {
        if (existingData[r][respondentIndex] === submitterUsername) {
          return createJsonResponse({ success: false, error: 'Anda sudah pernah mengisi formulir ini. Batas pengisian adalah 1 kali per akun.' });
        }
      }
      // 2. Cek duplikasi berdasarkan Fingerprint Perangkat (Cukup Kuat untuk Tamu)
      if (data.fingerprint && fingerprintIndex !== -1) {
        if (existingData[r][fingerprintIndex] === data.fingerprint) {
          return createJsonResponse({ success: false, error: 'Anda sudah pernah mengisi formulir ini sebelumnya. Formulir ini membatasi 1 tanggapan per responden.' });
        }
      }
    }
  }

  const sanitizedResponses = sanitize(responses);
  const isQuiz = form.isQuizMode === true || form.isQuizMode === "TRUE";
  let totalScore = 0;
  let maxPossibleScore = 0;

  if (isQuiz) {
    const fields = JSON.parse(form.fields_schema_json || '[]');
    fields.forEach(f => {
      const userAnswer = sanitizedResponses[f.label];
      const correctAnswer = f.correctAnswer;
      const points = parseInt(f.points || 0);
      
      if (points > 0) {
        maxPossibleScore += points;
        if (correctAnswer !== undefined) {
          if (Array.isArray(correctAnswer)) {
            if (Array.isArray(userAnswer) && 
                correctAnswer.length === userAnswer.length && 
                correctAnswer.every(val => userAnswer.includes(val))) {
              totalScore += points;
            }
          } else if (userAnswer !== undefined && String(userAnswer).trim().toLowerCase() === String(correctAnswer).trim().toLowerCase()) {
            totalScore += points;
          }
        }
      }
    });

    if (!headers.includes('Total Skor')) {
      sheet.getRange(1, headers.length + 1).setValue('Total Skor');
      headers.push('Total Skor');
    }
  }

  const rowData = [new Date().toISOString()];
  for (let i = 1; i < headers.length; i++) {
    const hName = headers[i];
    if (hName === 'Total Skor') {
      rowData.push(totalScore);
      continue;
    }
    if (hName === 'Respondent Username') {
      rowData.push(submitterUsername || 'Guest');
      continue;
    }
    if (hName === 'Device ID') {
      rowData.push(data.fingerprint || 'N/A');
      continue;
    }
    let value = sanitizedResponses[hName];
    
    // Handle File Upload ke Google Drive
    if (value && typeof value === 'object' && value.base64) {
      try {
        let targetFolder;
        if (form.userFolderId) {
          targetFolder = DriveApp.getFolderById(form.userFolderId);
        } else {
          // Central Storage: Cari atau buat struktur /username/formTitle
          const rootFolder = DriveApp.getFolderById(CONFIG.GDRIVE_FOLDER_ID);
          
          let accountFolder;
          const accountFolders = rootFolder.getFoldersByName(form.username);
          if (accountFolders.hasNext()) {
            accountFolder = accountFolders.next();
          } else {
            accountFolder = rootFolder.createFolder(form.username);
          }
          
          const formFolderName = form.title ? form.title.trim() : form.formId;
          const formFolders = accountFolder.getFoldersByName(formFolderName);
          if (formFolders.hasNext()) {
            targetFolder = formFolders.next();
          } else {
            targetFolder = accountFolder.createFolder(formFolderName);
          }
        }
        
        const folder = targetFolder;
        const parts = value.base64.split(',');
        const base64Data = parts.length > 1 ? parts[1] : parts[0];
        
        const decoded = Utilities.base64Decode(base64Data);
        const blob = Utilities.newBlob(decoded, value.mimeType, value.fileName);
        const file = folder.createFile(blob);
        
        // Buat file publik view
        file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
        value = file.getUrl();
      } catch (err) {
        console.error("Gagal upload file:", err); // Added console.error
        value = `Error upload file: ${err.message}`;
      }
    }
    rowData.push(value || "");
  }
  
  sheet.appendRow(rowData);

  // 3. Trigger real-time notif ke kreator (Foreground)
  triggerPusher(form.username, 'new-response', { 
    formId: form.formId, 
    formTitle: form.title
  });

  // 4. Trigger True Web Push (Background)
  try {
    UrlFetchApp.fetch(CONFIG.VERCEL_BACKEND_URL + '/api/beams-notify', {
      method: 'post',
      contentType: 'application/json',
      headers: { 'x-api-key': CONFIG.NOTIFY_API_KEY },
      payload: JSON.stringify({
        title: 'Respons Baru!',
        body: `Seseorang mengisi: ${form.title}`,
        url: '/admin'
      }),
      muteHttpExceptions: true
    });
  } catch (e) {
    console.error("Gagal trigger Beams untuk respon baru:", e);
  }

  // Update storage jika ada upload file
  if (!isExempt && newFileSize > 0 && accountRowIndex !== -1) {
    accountSheet.getRange(accountRowIndex, 11).setValue(storageUsed + newFileSize);
  }

  return createJsonResponse({ 
    success: true, 
    message: 'Tanggapan berhasil disimpan.',
    score: isQuiz ? totalScore : null,
    maxScore: isQuiz ? maxPossibleScore : null
  });
}

function handleGetSystemInfo() {
  return createJsonResponse({ 
    success: true, 
    serviceEmail: Session.getEffectiveUser().getEmail() 
  });
}

function handleGetResponses(data) {
  const { formId, lastSyncHash } = data;
  
  const centralSs = getSpreadsheet();
  const formsSheet = centralSs.getSheetByName(FORMS_SHEET);
  const formsData = formsSheet.getDataRange().getValues();

  let form = null;
  for (let i = 1; i < formsData.length; i++) {
    if (formsData[i][0] === formId) {
      form = {
        formId: formsData[i][0],
        userSpreadsheetId: formsData[i][12],
        fields_schema_json: formsData[i][5]
      };
      break;
    }
  }

  if (!form) return createJsonResponse({ success: false, error: 'Form tidak ditemukan.' });

  let ss;
  let sheet;

  if (form.userSpreadsheetId) {
    try {
      ss = SpreadsheetApp.openById(form.userSpreadsheetId);
      sheet = ss.getSheets()[0];
    } catch (e) {
      console.error("Gagal baca sheet personal:", e);
      ss = getSpreadsheet();
      sheet = ss.getSheetByName(`res_${formId}`);
    }
  } else {
    ss = getSpreadsheet();
    sheet = ss.getSheetByName(`res_${formId}`);
  }

  if (!sheet || sheet.getLastRow() < 1) {
    return createJsonResponse({ success: true, responses: [], headers: [] });
  }

  const values = sheet.getDataRange().getValues();
  const headers = values[0];
  const responses = [];

  for (let i = 1; i < values.length; i++) {
    const resp = {};
    headers.forEach((h, idx) => {
      resp[h] = values[i][idx];
    });
    responses.push(resp);
  }

  // Phase 10: Efficient Sync (Hash)
  const currentHash = computeSHA256(JSON.stringify(responses));
  if (lastSyncHash && lastSyncHash === currentHash) {
    return createJsonResponse({ success: true, changed: false, hash: currentHash });
  }

  return createJsonResponse({ 
    success: true, 
    changed: true,
    headers: headers, 
    responses: responses,
    hash: currentHash
  });
}

// =======================
// INTEGRASI AI (MAGIC BUILDER)
// =======================
function handleGenerateForm(data) {
  const { prompt, currentForm, username } = data;
  
  // Security Check: Verify User Status from Sheet
  const ss = getSpreadsheet();
  const accountSheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const accounts = accountSheet.getDataRange().getValues();
  let userVerified = false;
  let userRowIndex = -1;
  let lastAiRequestStr = "";
  
  for (let i = 1; i < accounts.length; i++) {
    if (String(accounts[i][1]) === String(username)) {
      const status = accounts[i][4];
      if (status === true || status === "TRUE") {
        userVerified = true;
      }
      userRowIndex = i + 1;
      lastAiRequestStr = accounts[i][7]; // Kolom ke-8 (index 7)
      break;
    }
  }
  
  if (!userVerified) {
    return createJsonResponse({ 
      success: false, 
      error: 'Fitur AI hanya tersedia untuk akun yang sudah Terverifikasi. Silakan hubungi admin di Settings.' 
    });
  }

  // Phase 3: Rate Limiting (30s Cooldown)
  if (lastAiRequestStr) {
    const lastTime = new Date(lastAiRequestStr).getTime();
    const now = new Date().getTime();
    const diffSeconds = (now - lastTime) / 1000;
    if (diffSeconds < 30) {
      return createJsonResponse({ 
        success: false, 
        error: `Mohon tunggu ${Math.ceil(30 - diffSeconds)} detik lagi untuk menggunakan AI.` 
      });
    }
  }

  // Update lastAiRequest sebelum memproses
  if (userRowIndex !== -1) {
    accountSheet.getRange(userRowIndex, 8).setValue(new Date().toISOString());
  }

  logAction(username, 'GENERATE_AI', 'START', prompt.substring(0, 50));
  
  let success = false;
  let result = null;
  let lastError = null;
  
  // Sistem Rotasi API Key (3 Token Fallback)
  for (let i = 0; i < CONFIG.GROQ_API_KEYS.length; i++) {
    try {
      const token = CONFIG.GROQ_API_KEYS[i];
      const selectedModel = CONFIG.GROQ_MODELS[i] || 'llama-3.3-70b-versatile';
      if (!token || token.trim() === '') continue;
      
      const payload = {
        messages: [
          { 
            role: 'system', 
            content: 'Anda adalah AI Asisten pembuat skema formulir. Output Anda HANYA berupa JSON valid. Struktur: { title, description, theme (blue/purple/green/rose/orange/dark), backgroundPattern (none/dots/grid/waves/zigzag), successMessage, fields: [] }. \n\nField Types yang diperbolehkan: "Short Text", "Paragraph", "Email", "Number", "Multiple Choice", "Checkboxes", "Dropdown", "Linear Scale", "Date", "Time", "File Upload". \nSetiap field HARUS memiliki id (string unik), type (pilih dari list), label (string), required (boolean), dan helpText (string). Untuk type pilihan (Multiple Choice/Dropdown/Checkboxes), HARUS ada "options" (array string). \nJika sedang dalam Mode Kuis (isQuizMode: true), setiap field juga harus memiliki "points" (number) dan "correctAnswer" (string/array). \n\nJangan beri penjelasan, jangan beri markdown blok.'
          },
          { 
            role: 'user', 
            content: currentForm 
              ? `Konteks Form Saat Ini: ${JSON.stringify(currentForm)}\n\nPermintaan User: ${prompt}`
              : prompt 
          }
        ],
        model: selectedModel,
        temperature: 0.2
      };
      
      const options = {
        method: 'post',
        contentType: 'application/json',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        payload: JSON.stringify(payload),
        muteHttpExceptions: true
      };
      
      const response = UrlFetchApp.fetch('https://api.groq.com/openai/v1/chat/completions', options);
      const responseCode = response.getResponseCode();
      
      if (responseCode === 200) {
        const jsonResponse = JSON.parse(response.getContentText());
        let content = jsonResponse.choices[0].message.content;
        
        // Ekstrak objek/array JSON secara robust
        content = content.replace(/```json/g, "").replace(/```/g, "").trim();
        const startIdx = Math.min(
          content.indexOf('{') === -1 ? Infinity : content.indexOf('{'),
          content.indexOf('[') === -1 ? Infinity : content.indexOf('[')
        );
        const endChar = content.indexOf('{') === startIdx ? '}' : ']';
        const endIdx = content.lastIndexOf(endChar);
        
        if (startIdx !== Infinity && endIdx !== -1) {
           result = JSON.parse(content.substring(startIdx, endIdx + 1));
           success = true;
           break; 
        } else {
           throw new Error('AI tidak mengembalikan JSON yang valid.');
        }
      } else {
        throw new Error(`API Error ${responseCode}: ${response.getContentText()}`);
      }
    } catch (e) {
      lastError = e.message;
      // Jika error, iterasi lanjut mencoba token fallback selanjutnya
    }
  }
  
  if (success) {
    return createJsonResponse({ success: true, schema: result });
  } else {
    return createJsonResponse({ success: false, error: lastError || 'Semua token API percobaan gagal.' });
  }
}

// Fitur Impor Google Form Native
function handleImportGForm(data) {
  const { url } = data;
  try {
    const html = UrlFetchApp.fetch(url).getContentText();
    const match = html.match(/var FB_PUBLIC_LOAD_DATA_ = (\[.*?\]);\n/);
    if (!match) return createJsonResponse({ success: false, error: "Bukan URL Google Form yang valid." });
    
    const parsed = JSON.parse(match[1]);
    const items = parsed[1][1];
    
    const actionUrl = url.replace(/\/viewform.*/, '/formResponse');
    
    const fields = [];
    let hasFileUpload = false;
    
    (items || []).forEach(item => {
      const typeNum = item[3];
      if (typeNum === 13) hasFileUpload = true;
      
      const title = item[1] || 'Pertanyaan';
      const helpText = item[2] || '';
      const qParams = item[4] && item[4][0];
      if (!qParams || !qParams[0]) return; // Lompati header section
      
      const entryId = 'entry.' + qParams[0];
      const isRequired = qParams[2] === 1;
      
      let type = 'Short Text';
      let options = [];
      
      switch(typeNum) {
        case 0: type = 'Short Text'; break;
        case 1: type = 'Paragraph'; break;
        case 2: type = 'Multiple Choice'; options = qParams[1] ? qParams[1].map(o => o[0]) : []; break;
        case 3: type = 'Dropdown'; options = qParams[1] ? qParams[1].map(o => o[0]) : []; break;
        case 4: type = 'Checkboxes'; options = qParams[1] ? qParams[1].map(o => o[0]) : []; break;
        case 9: type = 'Date'; break;
        case 10: type = 'Time'; break;
        default: break;
      }
      
      if (typeNum !== 13) {
        fields.push({
          id: entryId,
          type: type,
          label: title,
          required: isRequired,
          helpText: helpText,
          options: options
        });
      }
    });
    
    if (hasFileUpload) {
      return createJsonResponse({ success: true, hasFileUpload: true });
    }
    
    return createJsonResponse({ success: true, hasFileUpload: false, actionUrl, fields });
  } catch(e) {
    return createJsonResponse({ success: false, error: e.message });
  }
}

// =======================
// HANDLERS TAMBAHAN
// =======================

function handleGetFormBySlug(data) {
   const { customSlug } = data;
   const ss = getSpreadsheet();
   const sheet = ss.getSheetByName(FORMS_SHEET);
   if(!sheet) return createJsonResponse({ success: false, error: 'Database Forms tidak ditemukan' });
   
   const dataRange = sheet.getDataRange().getValues();
   for (let i = 1; i < dataRange.length; i++) {
     if (dataRange[i][1] === customSlug || dataRange[i][0] === customSlug) {
        return createJsonResponse({
           success: true,
           form: {
             formId: dataRange[i][0],
             customSlug: dataRange[i][1],
             username: dataRange[i][2],
             title: dataRange[i][3],
             description: dataRange[i][4],
             fields_schema_json: dataRange[i][5],
             theme: dataRange[i][6],
             backgroundPattern: dataRange[i][7],
             isActive: dataRange[i][8],
              confirmationMessage: dataRange[i][9],
              gformUrl: dataRange[i][10],
              userSpreadsheetId: dataRange[i][12],
              userFolderId: dataRange[i][13],
              isQuizMode: dataRange[i][14],
              requireLogin: dataRange[i][15] === true || dataRange[i][15] === "TRUE",
              limitOneResponse: dataRange[i][16] === true || dataRange[i][16] === "TRUE"
            }
         });
     }
   }
   return createJsonResponse({ success: false, error: 'Form tidak ditemukan' });
}

function handleGetCreatorForms(data) {
   const { username, lastSyncHash } = data;
   const ss = getSpreadsheet();
   const sheet = ss.getSheetByName(FORMS_SHEET);
   if(!sheet) return createJsonResponse({ success: true, forms: [] });
   
   const dataRange = sheet.getDataRange().getValues();
   const forms = [];
   
   for (let i = 1; i < dataRange.length; i++) {
     if (dataRange[i][2] === username) {
        forms.push({
             formId: dataRange[i][0],
             customSlug: dataRange[i][1],
             title: dataRange[i][3],
             isActive: dataRange[i][8],
             createdAt: dataRange[i][11]
        });
     }
   }
   
   // Urutkan dari yg terbaru
   forms.sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));

   // Tarik data storage
   const accountSheet = ss.getSheetByName(ACCOUNTS_SHEET);
   const accounts = accountSheet.getDataRange().getValues();
   let storageUsed = 0;
   let isVerified = false;
   for (let i = 1; i < accounts.length; i++) {
     if (String(accounts[i][1]) === String(username)) {
        isVerified = (accounts[i][4] === true || accounts[i][4] === "TRUE");
        storageUsed = parseInt(accounts[i][10]) || 0;
        break;
     }
   }
   
   // Phase 10: Efficient Sync (Hash)
   // Tambahkan data akun ke objek hash agar kalau storage berubah, klien juga refetch
   const currentHash = computeSHA256(JSON.stringify({forms, storageUsed, isVerified}));
   if (lastSyncHash && lastSyncHash === currentHash) {
     return createJsonResponse({ success: true, changed: false, hash: currentHash, storageUsed, isVerified });
   }

   return createJsonResponse({ 
     success: true, 
     changed: true,
     forms: forms,
     storageUsed: storageUsed,
     isVerified: isVerified,
     hash: currentHash 
   });
}

function handleToggleFormStatus(data) {
   const { formId, isActive } = data;
   const ss = getSpreadsheet();
   const sheet = ss.getSheetByName(FORMS_SHEET);
   const dataRange = sheet.getDataRange().getValues();
   
   for (let i = 1; i < dataRange.length; i++) {
     if (dataRange[i][0] === formId) {
        sheet.getRange(i + 1, 9).setValue(isActive); // Kolom ke-9 (isActive) 1-based index
        return createJsonResponse({ success: true });
     }
   }
   return createJsonResponse({ success: false, error: 'Form tidak ditemukan' });
}
function handleDeleteForm(data) {
   const { formId } = data;
   const ss = getSpreadsheet();
   const sheet = ss.getSheetByName(FORMS_SHEET);
   const dataRange = sheet.getDataRange().getValues();
   
   for (let i = 1; i < dataRange.length; i++) {
     if (dataRange[i][0] === formId) {
        // 1. Hapus row di sheet forms
        sheet.deleteRow(i + 1);
        
        // 2. Hapus tab respon jika ada
        const resSheet = ss.getSheetByName(`res_${formId}`);
        if (resSheet) {
          ss.deleteSheet(resSheet);
        }
        
        logAction(data.username, 'DELETE_FORM', 'SUCCESS', formId);
        return createJsonResponse({ success: true, message: 'Form berhasil dihapus' });
     }
   }
   logAction(data.username, 'DELETE_FORM', 'FAILURE', 'Form tidak ditemukan: ' + formId);
   return createJsonResponse({ success: false, error: 'Form tidak ditemukan' });
}
function handleDeleteAccount(data) {
  const { username } = data;
  const ss = getSpreadsheet();
  
  // 1. Amankan nama tab respon & hapus row di FORMS_SHEET
  const formsSheet = ss.getSheetByName(FORMS_SHEET);
  const formsData = formsSheet.getDataRange().getValues();
  const formIdsToDelete = [];
  
  // Hapus row forms dari bawah ke atas agar index tidak berantakan
  for (let i = formsData.length - 1; i >= 1; i--) {
    if (formsData[i][2] === username) {
      formIdsToDelete.push(formsData[i][0]);
      formsSheet.deleteRow(i + 1);
    }
  }
  
  // 2. Hapus tab respon untuk setiap formId
  formIdsToDelete.forEach(id => {
    const resSheet = ss.getSheetByName(`res_${id}`);
    if (resSheet) {
      ss.deleteSheet(resSheet);
    }
  });
  
  // 3. Hapus Akun dari ACCOUNTS_SHEET
  const accountsSheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const accountsData = accountsSheet.getDataRange().getValues();
  for (let i = accountsData.length - 1; i >= 1; i--) {
    if (accountsData[i][1] === username) {
      accountsSheet.deleteRow(i + 1);
      break; // Username unik
    }
  }
  
  logAction(username, 'DELETE_ACCOUNT', 'SUCCESS', 'Account and data purged');
  return createJsonResponse({ success: true, message: 'Akun dan seluruh data berhasil dihapus permanen' });
}

function handleGetAllUsers(data) {
    const lastSyncHash = data?.lastSyncHash;
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName(ACCOUNTS_SHEET);
    if (!sheet) return createJsonResponse({ success: false, error: 'Tabel akun tidak ditemukan' });
    
    const rawData = sheet.getDataRange().getValues();
    const users = [];
    
    for (let i = 1; i < rawData.length; i++) {
        users.push({
            id: rawData[i][0],
            username: rawData[i][1],
            isVerified: rawData[i][4] === true || rawData[i][4] === "TRUE",
            isAdmin: rawData[i][9] === true || rawData[i][9] === "TRUE",
            storageUsed: rawData[i][10] || 0
        });
    }

    // Efficient Sync (Hash)
    const currentHash = computeSHA256(JSON.stringify(users));
    if (lastSyncHash && lastSyncHash === currentHash) {
        return createJsonResponse({ success: true, changed: false, hash: currentHash });
    }
    
    return createJsonResponse({ success: true, changed: true, users, hash: currentHash });
}

function handleUpdateUserStatus(data) {
    const { targetUsername, field, value } = data; // field: 'isVerified' or 'isAdmin'
    const ss = getSpreadsheet();
    const sheet = ss.getSheetByName(ACCOUNTS_SHEET);
    const dataRange = sheet.getDataRange().getValues();
    
    // Mapping kolom: isVerified (E/Kolom 5), isAdmin (J/Kolom 10)
    const colIndex = field === 'isAdmin' ? 10 : 5;
    
    for (let i = 1; i < dataRange.length; i++) {
        if (String(dataRange[i][1]) === String(targetUsername)) {
            sheet.getRange(i + 1, colIndex).setValue(value);
            logAction("ADMIN", "UPDATE_USER_STATUS", "SUCCESS", `${targetUsername} -> ${field}: ${value}`);
            return createJsonResponse({ success: true, message: `Status ${targetUsername} diperbarui.` });
        }
    }
    return createJsonResponse({ success: false, error: 'User tidak ditemukan' });
}

function handleAdminDeleteUser(data) {
    const { targetUsername } = data;
    logAction("ADMIN", "DELETE_USER", "START", targetUsername);
    // Masukkan username ke handleDeleteAccount yang sudah ada
    return handleDeleteAccount({ username: targetUsername });
}

function handleUpdateProfile(data) {
  const { username, currentPassword, newPassword, newUsername } = data;
  
  if (!currentPassword) {
    return createJsonResponse({ success: false, error: 'Kata sandi saat ini diperlukan untuk otorisasi' });
  }

  if (!newPassword && !newUsername) {
    return createJsonResponse({ success: false, error: 'Tidak ada data yang diubah' });
  }

  const ss = getSpreadsheet();
  const accountsSheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const accountsData = accountsSheet.getDataRange().getValues();
  
  // Temukan Akun & Validasi Password Lama
  let userFoundIndex = -1;
  for (let i = 1; i < accountsData.length; i++) {
    if (accountsData[i][1] === username) {
      userFoundIndex = i;
      break;
    }
  }

  if (userFoundIndex === -1) {
    return createJsonResponse({ success: false, error: 'User tidak ditemukan' });
  }
  
  const storedPasswordHash = accountsData[userFoundIndex][2];
  const storedSalt = accountsData[userFoundIndex][3];
  const inputHash = computeSHA256(currentPassword + storedSalt);
  
  if (inputHash !== storedPasswordHash) {
    return createJsonResponse({ success: false, error: 'Kata sandi saat ini salah' });
  }

  if (newUsername) {
    // Cek apakah username sudah ada
    for (let i = 1; i < accountsData.length; i++) {
        if (accountsData[i][1] === newUsername) {
            return createJsonResponse({ success: false, error: 'Username sudah digunakan oleh pengguna lain' });
        }
    }
  }



  const rowIndex = userFoundIndex + 1; // 1-based indexing for sheets Apps Script
  let updatedUsername = accountsData[userFoundIndex][1];

  if (newPassword) {
      const newSalt = Utilities.getUuid();
      const newPasswordHash = computeSHA256(newPassword + newSalt);
      accountsSheet.getRange(rowIndex, 3).setValue(newPasswordHash);
      accountsSheet.getRange(rowIndex, 4).setValue(newSalt);
      logAction(username, 'UPDATE_PASSWORD', 'SUCCESS');
  }

  if (newUsername) {
      // 1. Update Username di Tabel User
      accountsSheet.getRange(rowIndex, 2).setValue(newUsername);
      updatedUsername = newUsername;
      
      // 2. Update Username pemilik di Tabel Forms
      const formsSheet = ss.getSheetByName(FORMS_SHEET);
      if (formsSheet) {
          const formsData = formsSheet.getDataRange().getValues();
          for (let j = 1; j < formsData.length; j++) {
              if (formsData[j][2] === username) {
                  formsSheet.getRange(j + 1, 3).setValue(newUsername);
              }
          }
      }
      
      // 3. Update Username di tabel Pending Accounts (jika ada)
      const pendingSheet = ss.getSheetByName(PENDING_ACCOUNTS_SHEET);
      if (pendingSheet) {
          const pendingData = pendingSheet.getDataRange().getValues();
          for (let k = 1; k < pendingData.length; k++) {
              if (pendingData[k][0] === username) {
                  pendingSheet.getRange(k + 1, 1).setValue(newUsername);
              }
          }
      }
      logAction(username, 'UPDATE_USERNAME', 'SUCCESS', 'New: ' + newUsername);
  }

  return createJsonResponse({ success: true, message: 'Profil berhasil diperbarui', newUsername: updatedUsername });
}

function handleUpdateCustomGasUrl(data) {
  const { username, customGasUrl } = data;
  const ss = getSpreadsheet();
  const sheet = ss.getSheetByName(ACCOUNTS_SHEET);
  const dataRange = sheet.getDataRange().getValues();
  
  for (let i = 1; i < dataRange.length; i++) {
    if (dataRange[i][1] === username) {
      sheet.getRange(i + 1, 9).setValue(customGasUrl);       // Column I: customGasUrl
      // Auto-verifikasi: punya backend sendiri = trusted user
      const isNowVerified = customGasUrl && customGasUrl.trim() !== '';
      sheet.getRange(i + 1, 5).setValue(isNowVerified);      // Column E: isVerified
      logAction(username, 'UPDATE_GAS_URL', 'SUCCESS', `url=${customGasUrl}, verified=${isNowVerified}`);
      return createJsonResponse({ success: true, isVerified: isNowVerified });
    }
  }
  return createJsonResponse({ success: false, error: 'User tidak ditemukan' });
}
// Helper: Kirim Sinyal Real-time via Pusher
function triggerPusher(channel, event, data) {
  const { appId, key, secret, cluster } = CONFIG.PUSHER;
  const path = `/apps/${appId}/events`;
  const body = JSON.stringify({
    name: event,
    channels: [channel],
    data: JSON.stringify(data)
  });

  // 1. Hitung MD5 Body
  const bodyMd5 = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, body)
    .map(function(num) {
      return (num < 0 ? num + 256 : num).toString(16).padStart(2, '0');
    }).join('');

  const timestamp = Math.floor(new Date().getTime() / 1000);
  const authVersion = "1.0";

  // 2. Susun Query String untuk Signature
  const queryString = `auth_key=${key}&auth_timestamp=${timestamp}&auth_version=${authVersion}&body_md5=${bodyMd5}`;
  const stringToSign = `POST\n${path}\n${queryString}`;

  // 3. Hitung HMAC-SHA256 Signature
  const signature = Utilities.computeHmacSha256Signature(stringToSign, secret)
    .map(function(num) {
      return (num < 0 ? num + 256 : num).toString(16).padStart(2, '0');
    }).join('');

  const url = `https://api-${cluster}.pusher.com${path}?${queryString}&auth_signature=${signature}`;

  const options = {
    method: 'post',
    contentType: 'application/json',
    payload: body,
    muteHttpExceptions: true
  };

  try {
    UrlFetchApp.fetch(url, options);
    logAction('SYSTEM', 'PUSHER_TRIGGER', 'SUCCESS', `Event ${event} sent to ${channel}`);
  } catch (e) {
    logAction('SYSTEM', 'PUSHER_TRIGGER', 'ERROR', e.message);
  }
}
